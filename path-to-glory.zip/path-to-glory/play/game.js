// ---- globals.js ----
let w = window;

let can;
let ctx;

let GAME_PAUSED;
let BEATEN;

// Kept for prop/sky tinting compatibility; the arena is not wintery.
WINTER = 0;

// Screen shake, decayed by the camera.
SHAKE = 0;
shake = (amount) => {
    if (OPT_SHAKE) SHAKE = max(SHAKE, amount);
};

// Haptics on hits/strikes (mobile).
vibrate = (ms) => {
    if (OPT_VIBRATE && navigator.vibrate) navigator.vibrate(ms);
};

// Camera zoom controlled by the player (wheel / +- / on-screen buttons).
ZOOM_USER = 1;
setZoom = (factor) => ZOOM_USER = between(0.55, ZOOM_USER * factor, 3);

// Peaceful world: enemies wander around and never attack.
PEACEFUL = 1;

// Options ([O] in game)
OPTIONS_OPEN = 0;
OPT_WEATHER = 1;
OPT_BLOOD = 1;
OPT_SHAKE = 1;
OPT_SLOWMO = 1;
OPT_VIBRATE = 1;

// How many gangsters roam the arena at once.
ENEMY_COUNTS = [1, 2, 3, 5, 8, 12];
ENEMY_COUNT_INDEX = 1;
ENEMY_COUNT = 2;

// Mobile button layouts: 0 = cluster, 1 = spread, 2 = corner arc
TOUCH_LAYOUT = 0;

// Chosen hero: 0 = knight, 1 = ninja, 2 = rigged swordsman, 3 = rigged fighter.
HERO = [0, 1, 2, 3].indexOf(w.__hero) >= 0 ? w.__hero : 1;

// The rigged 3D characters are pose labs: no enemies at all.
NO_ENEMIES = HERO >= 2;

// Back to the character select screen.
backToMenu = () => location.reload();


canvasPrototype = CanvasRenderingContext2D.prototype;

DPR = Math.min(devicePixelRatio, 2);
MOBILE = /andro|ipho|ipa|ipo|mobi/i.test(navigator.userAgent) || navigator.maxTouchPoints > 0;

inputMode = (navigator.userAgent.match((/andro|ipho|ipa|ipo|mobi/i)) || navigator.maxTouchPoints > 0) ? 1 : 0;

toggleFullscreen = () => {
    if (document.fullscreenElement) {
        document.exitFullscreen();
    } else if (document.documentElement.requestFullscreen) {
        document.documentElement.requestFullscreen();
    }
};


// ---- math.js ----
between = (a, b, c) => b < a ? a : (b > c ? c : b);
isBetween = (a, b, c) => a <= b && b <= c || a >= b && b >= c;
rnd = (min, max) => random() * (max - min) + min;
distP = (x1, y1, x2, y2) => hypot(x1 - x2, y1 - y2);
dist = (a, b) => distP(a.x, a.y, b.x, b.y);
normalize = x => moduloWithNegative(x, PI);
angleBetween = (a, b) => atan2(b.y - a.y, b.x - a.x);
roundToNearest = (x, precision) => round(x / precision) * precision;
pick = a => a[~~(random() * a.length)];
interpolate = (from, to, ratio) => between(0, ratio, 1) * (to - from) + from;

// Easing
linear = x => x;
easeOutQuint = x => 1 - pow(1 - x, 5);

// Modulo centered around zero: the result will be between -y and +y
moduloWithNegative = (x, y) => {
    x = x % (y * 2);
    if (x > y) {
        x -= y * 2;
    }
    if (x < -y) {
        x += y * 2;
    }
    return x;
};

// Make Math global
Object.getOwnPropertyNames(Math).forEach(n => w[n] = w[n] || Math[n]);

TWO_PI = PI * 2;


// ---- state-machine.js ----
class StateMachine {
    transitionToState(state) {
        state.stateMachine = this;
        state.previous = this.state || new State();
        state.onEnter();
        this.state = state;
    }

    cycle(elapsed) {
        this.state.cycle(elapsed);
    }
}

class State {

    constructor() {
        this.age = 0;
    }

    get swordRaiseRatio() { return 0; }
    get shieldRaiseRatio() { return 0; }
    get speedRatio() { return 1; }
    get attackPreparationRatio() { return 0; }

    onEnter() {

    }

    cycle(elapsed) {
        this.age += elapsed;
    }
}

characterStateMachine = ({
    entity,
    chargeTime,
    perfectParryTime,
    releaseAttackBetweenStrikes,
    staggerTime,
}) => {
    let { controls } = entity;
    let stateMachine = new StateMachine();

    let attackDamagePattern = [
        0.7,
        0.8,
        0.9,
        1,
        3,
    ];

    chargeTime = chargeTime || 1;
    perfectParryTime = perfectParryTime || 0;
    staggerTime = staggerTime || 0;

    class MaybeExhaustedState extends State {
        cycle(elapsed) {
            super.cycle(elapsed);
            if (entity.stamina === 0) {
                stateMachine.transitionToState(new Exhausted());
            }
            if (entity.age - entity.lastDamage < staggerTime) {
                stateMachine.transitionToState(new Staggered());
            }
        }
    }
    
    class Idle extends MaybeExhaustedState {
        get swordRaiseRatio() { return interpolate(this.previous.swordRaiseRatio, 0, this.age / 0.1); }
        get shieldRaiseRatio() { return interpolate(this.previous.shieldRaiseRatio, 0, this.age / 0.1); }

        get speedRatio() { 
            return entity.inWater ? 0.5 : 1; 
        }

        cycle(elapsed) {
            super.cycle(elapsed);
            if (controls.shield) {
                stateMachine.transitionToState(new Shielding());
            } else if (controls.attack) {
                stateMachine.transitionToState(new Charging());
            } else if (controls.dash) {
                stateMachine.transitionToState(new Dashing());
            }
        }
    }

    class Shielding extends MaybeExhaustedState {
        get speedRatio() { 
            return 0.5; 
        }

        get shieldRaiseRatio() { return interpolate(0, 1, this.age / 0.1); }
        get swordRaiseRatio() { return interpolate(0, -1, this.age / 0.1); }
        get shielded() { return true; }
        get perfectParry() { return this.age < perfectParryTime; }

        cycle(elapsed) {
            super.cycle(elapsed);
            if (!controls.shield) {
                stateMachine.transitionToState(new Idle());
            }
        }
    }

    class Dashing extends State {

        get swordRaiseRatio() { 
            return interpolate(this.previous.swordRaiseRatio, -1, this.age / (0.3 / 2)); 
        }

        onEnter() {
            this.dashAngle = entity.controls.angle;

            entity.dash(entity.controls.angle, 200, 0.3);
            sound(...[1.99,,427,.01,,.07,,.62,6.7,-0.7,,,,.2,,,.11,.76,.05]);

            entity.loseStamina(0.15);
        }

        cycle(elapsed) {
            super.cycle(elapsed);

            if (this.age > 0.3) {
                stateMachine.transitionToState(new Idle());
            }
        }
    }

    class Charging extends MaybeExhaustedState {
        constructor(counter = 0) {
            super();
            this.counter = counter;
        }

        get speedRatio() { 
            return 0.5; 
        }

        get attackPreparationRatio() {
            return this.age / chargeTime;
        }

        get swordRaiseRatio() { 
            return interpolate(this.previous.swordRaiseRatio, -1, this.attackPreparationRatio); 
        }

        cycle(elapsed) {
            let { attackPreparationRatio } = this;

            super.cycle(elapsed);

            if (!controls.attack) {
                let counter = this.age >= 1 ? attackDamagePattern.length - 1 : this.counter;
                stateMachine.transitionToState(new Strike(counter));
            }

            if (attackPreparationRatio < 1 && this.attackPreparationRatio >= 1) {
                let animation = entity.scene.add(new FullCharge());
                animation.x = entity.x - entity.facing * 20;
                animation.y = entity.y - 60;
            }
        }
    }

    class Strike extends MaybeExhaustedState {
        constructor(counter = 0) {
            super();
            this.counter = counter;
            this.prepareRatio = -min(3, this.counter + 1) * 0.4;
        }

        get swordRaiseRatio() { 
            return this.age < 0.05 
                ? interpolate(
                    this.previous.swordRaiseRatio, 
                    this.prepareRatio, 
                    this.age / 0.05,
                )
                : interpolate(
                    this.prepareRatio, 
                    1, 
                    (this.age - 0.05) / (0.15 - 0.05),
                );   
        }

        onEnter() {
            entity.lunge();

            this.anim = new SwingEffect(
                entity, 
                this.counter == attackDamagePattern.length - 1 ? '#ff0' : '#fff', 
                this.prepareRatio, 
                0,
            );
        }

        cycle(elapsed) {
            super.cycle(elapsed);

            if (this.age >= 0.05) {
                entity.scene.add(this.anim);
                this.anim.toAngle = this.swordRaiseRatio;
            }

            if (controls.attack) this.didTryToAttackAgain = true;
            if (controls.dash) this.didTryToDash = true;

            if (this.age > 0.15) {
                entity.strike(attackDamagePattern[this.counter]);

                if (this.didTryToDash) {
                    stateMachine.transitionToState(new Dashing());   
                    return; 
                }

                stateMachine.transitionToState(
                    this.counter < 3
                        ? this.didTryToAttackAgain
                            ? new Charging(this.counter + 1)
                            : new LightRecover(this.counter)
                        : new HeavyRecover()
                );
            }
        }
    }

    class LightRecover extends MaybeExhaustedState {
        constructor(counter) {
            super();
            this.counter = counter;
        }

        get swordRaiseRatio() { 
            let start = 1;
            let end = 0;

            let ratio = min(1, this.age / 0.05); 
            return ratio * (end - start) + start;
        }

        cycle(elapsed) {
            super.cycle(elapsed);

            if (!controls.attack || !releaseAttackBetweenStrikes) {
                this.readyToAttack = true;
            }

            if (this.age > 0.3) {
                stateMachine.transitionToState(new Idle());
            } else if (controls.attack && this.readyToAttack) {
                stateMachine.transitionToState(new Charging(this.counter + 1));
            } else if (controls.shield) {
                stateMachine.transitionToState(new Shielding());
            } else if (controls.dash) {
                stateMachine.transitionToState(new Dashing());
            }
        }
    }

    class HeavyRecover extends MaybeExhaustedState {

        get swordRaiseRatio() { 
            let start = 1;
            let end = 0;

            let ratio = min(this.age / 0.5, 1); 
            return ratio * (end - start) + start;
        }

        cycle(elapsed) {
            super.cycle(elapsed);

            if (this.age > 0.5) {
                stateMachine.transitionToState(new Idle());
            } else if (controls.dash) {
                stateMachine.transitionToState(new Dashing());
            }
        }
    }

    class Exhausted extends State {
        get swordRaiseRatio() { 
            return interpolate(this.previous.swordRaiseRatio, 1, this.age / 0.2); 
        }

        get exhausted() {
            return true;
        }
        
        get speedRatio() { 
            return 0.5; 
        }

        onEnter() {
            if (!entity.perfectlyBlocked) entity.displayLabel(('Exhausted'));
            entity.perfectBlocked = false;
        }

        cycle(elapsed) {
            super.cycle(elapsed);

            if (entity.stamina >= 1) {
                stateMachine.transitionToState(new Idle());
            }
        }
    }

    class Staggered extends State {
        get swordRaiseRatio() { 
            return this.previous.swordRaiseRatio; 
        }
        
        get speedRatio() { 
            return 0.5; 
        }

        cycle(elapsed) {
            super.cycle(elapsed);

            if (this.age >= staggerTime) {
                stateMachine.transitionToState(new Idle());
            }
        }
    }

    stateMachine.transitionToState(new Idle());

    return stateMachine;
}


// ---- graphics/create-canvas.js ----
createCanvas = (w, h, render) => {
    let can = document.createElement('canvas');
    can.width = w;
    can.height = h;

    let ctx = can.getContext('2d');

    return render(ctx, can) || can;
};

canvasPrototype.slice = (radius, sliceUp, ratio) => {
    ctx.beginPath();
    if (sliceUp) {
        ctx.moveTo(-radius, -radius);
        ctx.lineTo(radius, -radius);
    } else {
        ctx.lineTo(-radius, radius);
        ctx.lineTo(radius, radius);
    }

    ctx.lineTo(radius, -radius * ratio);
    ctx.lineTo(-radius, radius * ratio);
    ctx.clip();
};


// ---- graphics/wrap.js ----
canvasPrototype.wrap = function(f) {
    let { resolveColor } = this;
    this.save();
    f();
    this.restore();
    this.resolveColor = resolveColor || (x => x);
};


// ---- graphics/with-shadow.js ----
canvasPrototype.resolveColor = x => x;

canvasPrototype.withShadow = function(render) {
    this.wrap(() => {
        this.isShadow = true;
        this.resolveColor = () => 'rgba(0,0,0,.2)';

        ctx.scale(1, 0.5);
        ctx.transform(1, 0, 0.5, 1, 0, 0); // shear the context
        render();
    });

    this.wrap(() => {
        this.isShadow = false;
        render();
    });
};


// ---- graphics/characters/exclamation.js ----
exclamation = createCanvas(50, 50, (ctx, can) => {
    ctx.fillStyle = '#fff';
    ctx.translate(can.width / 2, can.width / 2);
    for (let r = 0, i = 0 ; r < 1 ; r += 0.05, i++) {
        let distance = i % 2 ? can.width / 2 : can.width / 3;
        ctx.lineTo(
            cos(r * TWO_PI) * distance,
            sin(r * TWO_PI) * distance,
        )
    }
    ctx.fill();

    ctx.font = ('bold 18pt Arial');
    ctx.fillStyle = '#f00';
    ctx.textAlign = ('center');
    ctx.textBaseline = ('middle');
    ctx.fillText('!!!', 0, 0);
});


// ---- graphics/characters/body.js ----
canvasPrototype.renderSword = function() {
    with (this) wrap(() => {
        fillStyle = resolveColor('#444');
        fillRect(-10, -2, 20, 4);
        fillRect(-3, 0, 6, 12);

        fillStyle = resolveColor('#fff');
        beginPath();
        moveTo(-3, 0);
        lineTo(-5, -35);
        lineTo(0, -40);
        lineTo(5, -35);
        lineTo(3, 0);
        fill();
    });
};

canvasPrototype.renderAxe = function() {
    with (this) wrap(() => {
        fillStyle = resolveColor('#634');
        fillRect(-2, 12, 4, -40);

        translate(0, -20);

        let radius = 10;

        fillStyle = resolveColor('#eee');

        beginPath();
        arc(0, 0, radius, -PI / 4, PI / 4);
        arc(0, radius * hypot(1, 1), radius, -PI / 4, -PI * 3 / 4, true);
        arc(0, 0, radius, PI * 3 / 4, -PI * 3 / 4);
        arc(0, -radius * hypot(1, 1), radius, PI * 3 / 4, PI / 4, true);
        fill();
    });
};

canvasPrototype.renderShield = function() {
    with (this) wrap(() => {
        fillStyle = resolveColor('#fff');

        for (let [bitScale, col] of [[0.8, resolveColor('#fff')], [0.6, resolveColor('#888')]]) {
            fillStyle = col;
            scale(bitScale, bitScale);
            beginPath();
            moveTo(0, -15);
            lineTo(15, -10);
            lineTo(12, 10);
            lineTo(0, 25);
            lineTo(-12, 10);
            lineTo(-15, -10);
            fill();
        }
    });
};

canvasPrototype.renderLegs = function(entity, color) {
    with (this) wrap(() => {
        let { age } = entity;

        translate(0, -32);

        // Left leg
        wrap(() => {
            fillStyle = resolveColor(color);
            translate(-6, 12);
            if (entity.controls.force) rotate(-sin(age * TWO_PI * 4) * PI / 16);
            fillRect(-4, 0, 8, 20);
        });

        // Right leg
        wrap(() => {
            fillStyle = resolveColor(color);
            translate(6, 12);
            if (entity.controls.force) rotate(sin(age * TWO_PI * 4) * PI / 16);
            fillRect(-4, 0, 8, 20);
        });
    });
};

canvasPrototype.renderChest = function(entity, color, width = 25) {
    with (this) wrap(() => {
        let { renderAge } = entity;

        translate(0, -32);

        // Breathing
        translate(0, sin(renderAge * TWO_PI / 5) * 0.5);
        rotate(sin(renderAge * TWO_PI / 5) * PI / 128);

        fillStyle = resolveColor(color);
        if (entity.controls.force) rotate(-sin(renderAge * TWO_PI * 4) * PI / 64);
        fillRect(-width / 2, -15, width, 30);
    });
}

canvasPrototype.renderHead = function(entity, color, slitColor = null) {
    with (this) wrap(() => {
        let { renderAge } = entity;

        fillStyle = resolveColor(color);
        translate(0, -54);
        if (entity.controls.force) rotate(-sin(renderAge * TWO_PI * 4) * PI / 32);
        fillRect(-6, -7, 12, 15);

        fillStyle = resolveColor(slitColor);
        if (slitColor) fillRect(4, -5, -6, 4);
    });
}

canvasPrototype.renderCrown = function(entity) {
    with (this) wrap(() => {
        fillStyle = resolveColor('#ff0');
        translate(0, -70);

        beginPath();
        lineTo(-8, 0);
        lineTo(-4, 6);
        lineTo(0, 0);
        lineTo(4, 6);
        lineTo(8, 0);
        lineTo(8, 12);
        lineTo(-8, 12);
        fill();
    });
}

canvasPrototype.renderStick = function() {
    this.fillStyle = this.resolveColor('#444');
    this.fillRect(-3, 10, 6, -40);
}

canvasPrototype.renderArm = function(entity, color, renderTool) {
    with (this) wrap(() => {
        if (!entity.health) return;

        let { renderAge } = entity;

        translate(11, -42);
        
        fillStyle = resolveColor(color);
        if (entity.controls.force) rotate(-sin(renderAge * TWO_PI * 4) * PI / 32);
        rotate(entity.stateMachine.state.swordRaiseRatio * PI / 2);

        // Breathing
        rotate(sin(renderAge * TWO_PI / 5) * PI / 32);

        fillRect(0, -3, 20, 6);

        translate(18, -6);
        renderTool();
    });
}

canvasPrototype.renderArmAndShield = function(entity, armColor) {
    with (this) wrap(() => {
        let { renderAge } = entity;

        translate(0, -32);

        fillStyle = resolveColor(armColor);
        translate(-10, -8);
        if (entity.controls.force) rotate(-sin(renderAge * TWO_PI * 4) * PI / 32);
        rotate(PI / 3);
        rotate(entity.stateMachine.state.shieldRaiseRatio * -PI / 3);

        // Breathing
        rotate(sin(renderAge * TWO_PI / 5) * PI / 64);

        let armLength = 10 + 15 * entity.stateMachine.state.shieldRaiseRatio;
        fillRect(0, -3, armLength, 6);

        // Shield
        wrap(() => {
            translate(armLength, 0);
            renderShield();
        });
    });
};

canvasPrototype.renderExhaustion = function(entity, y) {
    if (!entity.health) return;

    if (entity.stateMachine.state.exhausted) {
        this.wrap(() => {
            this.translate(0, y);
            this.fillStyle = this.resolveColor('#ff0');
            for (let r = 0 ; r < 1 ; r += 0.15) {
                let angle = r * TWO_PI + entity.age * PI;
                this.fillRect(cos(angle) * 15, sin(angle) * 15 * 0.5, 4, 4);
            }
        });
    }
};

canvasPrototype.renderAttackIndicator = function(entity) {
    if (0) return;

    with (this) wrap(() => {
        if (!entity.health) return;

        let progress = entity.stateMachine.state.attackPreparationRatio;
        if (progress > 0 && !this.isShadow) {
            strokeStyle = 'rgba(255,0,0,1)';
            fillStyle = 'rgba(255,0,0,.5)';
            globalAlpha = interpolate(0.5, 0, progress);
            lineWidth = 10;
            beginPath();
            scale(1 - progress, 1 - progress);
            ellipse(0, 0, entity.strikeRadiusX, entity.strikeRadiusY, 0, 0, TWO_PI);
            fill();
            stroke();
        }
    });
};

canvasPrototype.renderExclamation = function(entity) {
    with (this) wrap(() => {
        if (!entity.health) return;

        translate(0, -100 + pick([-2, 2]));

        if (entity.stateMachine.state.attackPreparationRatio > 0 && !isShadow) {
            let progress = min(1, 2 * entity.stateMachine.state.age / 0.25);
            scale(progress, progress);
            drawImage(exclamation, -exclamation.width / 2, -exclamation.height / 2);
        }
    });
};

canvasPrototype.renderKatana = function() {
    with (this) wrap(() => {
        // Wrapped handle
        fillStyle = resolveColor('#210');
        fillRect(-3, 0, 6, 16);

        // Circular guard
        fillStyle = resolveColor('#c92');
        beginPath();
        arc(0, 0, 6, 0, TWO_PI);
        fill();

        // Slightly curved single-edged blade
        fillStyle = resolveColor('#eff');
        beginPath();
        moveTo(-3, -2);
        quadraticCurveTo(-6, -30, -1, -52);
        lineTo(3, -48);
        quadraticCurveTo(3, -26, 3, -2);
        fill();

        // Edge highlight
        fillStyle = resolveColor('#fff');
        fillRect(1, -46, 1.5, 42);
    });
};

canvasPrototype.renderScarf = function(entity, renderAge) {
    with (this) wrap(() => {
        let t = renderAge || entity.age;
        fillStyle = resolveColor('#b22');
        translate(0, -52);
        beginPath();
        moveTo(0, 0);
        quadraticCurveTo(
            -20 - sin(t * 6) * 6, -6 + cos(t * 5) * 6,
            -44 - sin(t * 4) * 10, 4 + sin(t * 7) * 12,
        );
        quadraticCurveTo(-20, 10, 0, 8);
        fill();
    });
};


// ---- graphics/characters/fighter.js ----
// Shared "real body" renderer: rounded capsule limbs, oval head, pose system.
// Used by the ninja hero and every gangster enemy so anatomy stays consistent.

capsule = (x1, y1, x2, y2, w, color) => {
    ctx.strokeStyle = ctx.resolveColor ? ctx.resolveColor(color) : color;
    ctx.lineWidth = w;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
};

blob = (x, y, rx, ry, color, rot) => {
    ctx.fillStyle = ctx.resolveColor ? ctx.resolveColor(color) : color;
    ctx.beginPath();
    ctx.ellipse(x, y, rx, ry, rot || 0, 0, TWO_PI);
    ctx.fill();
};

// [armStart, armEnd, torsoStart, torsoEnd, offArm, weaponSpin]
STRIKE_POSES = [
    [-2.5, 1.1, -0.22, 0.3, -0.7, 0],       // Overhead cleave
    [-1.9, 1.9, 0.3, -0.35, 0.9, 0],        // Horizontal sweep
    [1.6, -1.9, 0.25, -0.2, -0.3, 0],       // Rising uppercut
    [-0.2, 0.1, 0.1, -0.1, -0.2, 0],        // Straight thrust
    [-2.2, 2.2, -0.4, 0.45, 1.2, 1],        // Spinning drop-slash
];
STRIKE_NAMES = ['Cleave!', 'Sweep!', 'Rising Fang!', 'Thrust!', 'Tornado Slash!'];

canvasPrototype.renderKnife = function() {
    ctx.wrap(() => {
        ctx.fillStyle = ctx.resolveColor('#222');
        ctx.fillRect(-2, 0, 4, 10);
        ctx.fillStyle = ctx.resolveColor('#dee');
        ctx.beginPath();
        ctx.moveTo(-2.5, 0);
        ctx.lineTo(-1, -20);
        ctx.lineTo(2.5, -16);
        ctx.lineTo(2.5, 0);
        ctx.fill();
    });
};

canvasPrototype.renderPistol = function() {
    ctx.wrap(() => {
        ctx.fillStyle = ctx.resolveColor('#333');
        ctx.fillRect(-3, -2, 6, 10);
        ctx.fillStyle = ctx.resolveColor('#555');
        ctx.rotate(-PI / 2);
        ctx.fillRect(-4, -3, 22, 6);
        ctx.fillStyle = ctx.resolveColor('#222');
        ctx.fillRect(14, -2, 6, 4);
    });
};

canvasPrototype.renderBat = function() {
    ctx.wrap(() => {
        ctx.fillStyle = ctx.resolveColor('#963');
        ctx.beginPath();
        ctx.moveTo(-2, 8);
        ctx.lineTo(-5, -30);
        ctx.lineTo(5, -30);
        ctx.lineTo(2, 8);
        ctx.fill();
    });
};

canvasPrototype.renderNunchaku = function(t) {
    ctx.wrap(() => {
        ctx.rotate(sin(t * 12) * 1.2);
        capsule(0, 0, 0, -16, 4, '#421');
        capsule(0, -16, 10, -26, 3, '#421');
    });
};

renderWeapon = (weapon, t) => {
    if (weapon == 'katana') ctx.renderKatana();
    if (weapon == 'knife') ctx.renderKnife();
    if (weapon == 'gun') ctx.renderPistol();
    if (weapon == 'bat') ctx.renderBat();
    if (weapon == 'chuck') ctx.renderNunchaku(t);
};

// o: { suit, skin, accent, weapon, mask, bulk, scarf }
canvasPrototype.renderFighter = function(entity, o) {
    let t = entity.renderAge === undefined ? entity.age : entity.renderAge;
    let state = entity.stateMachine ? entity.stateMachine.state : {};
    let moving = entity.controls.force;
    let bulk = o.bulk || 1;

    let p = t * (moving ? (entity.sprinting ? 17 : 11) : 1.4);
    let stride = moving ? sin(p) : 0;
    // Natural bob: hopping while running, soft breathing while idle
    let bounce = moving ? abs(sin(p)) * 3.5 : sin(t * 1.4) * 1.3;
    let guard = state.shielded ? 1 : 0;
    let crouchIdle = entity.health > 0 ? (sin(t * 0.7) > 0.93 ? 6 : 0) : 0;
    let crouch = (entity.crouch || 0) + guard * 5 + crouchIdle - bounce;

    let hipY = -32 + crouch;
    let shoulderY = hipY - 22 * bulk;
    let headY = shoulderY - 13 * bulk;

    let charge = state.attackPreparationRatio || 0;
    let st = entity.strikeT === undefined ? 1 : entity.strikeT;

    let armA = -0.5 + sin(t * 1.2) * 0.07;
    let armB = 0.45 - sin(t * 1.1) * 0.07;
    let torso = moving ? 0.1 : 0;

    if (charge > 0) {
        armA = interpolate(-0.5, -2.3, charge);
        torso = -0.25 * charge;
    }

    if (st < 1) {
        let pose = STRIKE_POSES[(entity.strikeStyle || 0) % STRIKE_POSES.length];
        let e = min(1, st * 1.5);
        armA = interpolate(pose[0], pose[1], e);
        torso = interpolate(pose[2], pose[3], e);
        armB = pose[4];
    }

    if (guard) armB = -1.15;

    if (o.weapon == 'gun') {
        let aimAngle = angleBetween(entity, entity.controls.aim);
        armA = -sin(aimAngle) * 0.9 * (entity.facing || 1);
        if (entity.muzzle > 0) armA -= 0.25;
    }

    ctx.wrap(() => {
        ctx.rotate(torso * 0.35);

        // Shadowed under-leg first
        capsule(-2, hipY, -3 - stride * 9, -2 + abs(stride) * 5, 9 * bulk, o.suit);
        capsule(-3 - stride * 9, -2 + abs(stride) * 5, -5 - stride * 11, 0, 7 * bulk, '#111');

        // Front leg
        capsule(2, hipY, 3 + stride * 9, -2 + abs(stride) * 5, 9.5 * bulk, o.suit);
        capsule(3 + stride * 9, -2 + abs(stride) * 5, 5 + stride * 11, 0, 7 * bulk, '#111');

        // Torso: tapered chest + waist
        blob(0, (hipY + shoulderY) / 2, 11 * bulk, 15 * bulk, o.suit, torso * 0.2);
        blob(0, shoulderY + 2, 12 * bulk, 8 * bulk, o.accent || o.suit);

        if (o.scarf) ctx.renderScarf(entity, t);

        // Off arm (behind)
        ctx.wrap(() => {
            ctx.translate(-4, shoulderY + 2);
            ctx.rotate(armB - stride * 0.5);
            capsule(0, 0, 13 * bulk, 0, 7 * bulk, o.accent || o.suit);
            ctx.translate(13 * bulk, 0);
            ctx.rotate(0.7);
            capsule(0, 0, 11 * bulk, 0, 6 * bulk, o.skin);
        });

        // Head: oval skull, mask wrap, eye slit
        ctx.wrap(() => {
            ctx.translate(0, headY);
            ctx.rotate(torso * 0.5 + sin(t * 1.4) * 0.03);
            blob(0, 0, 8.5 * bulk, 10.5 * bulk, o.mask || o.skin);
            if (entity.backView) {
                // Back of the head: knot / ponytail
                blob(0, 2, 5 * bulk, 6 * bulk, '#0000002a');
                capsule(0, 4, -2, 16, 5, o.mask || o.skin);
            } else {
                blob(2.5, -1.5, 5.5 * bulk, 2.6 * bulk, o.skin);
                blob(4.5, -1.5, 1.6, 1.9, '#111');
            }
            if (o.hair) blob(-1, -8, 8 * bulk, 5 * bulk, o.hair);
        });

        // Weapon arm (front)
        ctx.wrap(() => {
            if (entity.health <= 0) return;
            ctx.translate(4, shoulderY + 3);
            ctx.rotate(armA + stride * 0.5);
            capsule(0, 0, 13 * bulk, 0, 7.5 * bulk, o.accent || o.suit);
            ctx.translate(13 * bulk, 0);
            ctx.rotate(st < 1 ? -0.2 : 0.45);
            capsule(0, 0, 11 * bulk, 0, 6.5 * bulk, o.skin);
            ctx.translate(11 * bulk, 0);
            ctx.rotate(-PI / 2 + 0.2);
            renderWeapon(o.weapon, t);
        });
    });

    ctx.renderExhaustion(entity, -78);
};


// ---- graphics/gauge.js ----
healthGradient = createCanvas(400, 1, (ctx) => {
    let grad = ctx.createLinearGradient(-200, 0, 200, 0);
    grad.addColorStop(0, '#900');
    grad.addColorStop(1, '#f44');
    return grad;
});

staminaGradient = createCanvas(400, 1, (ctx) => {
    let grad = ctx.createLinearGradient(-200, 0, 200, 0);
    grad.addColorStop(0, '#07f');
    grad.addColorStop(1, '#0ef');
    return grad;
});

class Gauge {
    constructor(getValue) {
        this.getValue = getValue;
        this.value = this.displayedValue = 1;
        this.regenRate = 0.5;
    }

    cycle(elapsed) {
        this.displayedValue += between(
            -elapsed * 0.5, 
            this.getValue() - this.displayedValue, 
            elapsed * this.regenRate,
        );
    }

    render(width, height, color, half, ridgeCount) {
        function renderGauge(
            width,
            height, 
            value,
            color,
        ) {
            ctx.wrap(() => {
                let displayedMaxX = interpolate(height / 2, width, value);
                if (value === 0) return;

                ctx.translate(-width / 2, 0);

                ctx.fillStyle = color;
                ctx.beginPath();
                ctx.lineTo(0, height / 2);

                if (!half) {
                    ctx.lineTo(height / 2, 0);
                    ctx.lineTo(displayedMaxX - height / 2, 0);
                }

                ctx.lineTo(displayedMaxX, height / 2);
                ctx.lineTo(displayedMaxX - height / 2, height);
                ctx.lineTo(height / 2, height);
                ctx.fill();
            })
        }

        ctx.wrap(() => {
            ctx.wrap(() => {
                ctx.globalAlpha *= 0.5;
                renderGauge(width + 8, height + 4, 1, '#000');
            });

            ctx.translate(0, 2);
            renderGauge(width, height, this.displayedValue, '#fff');
            renderGauge(width, height, min(this.displayedValue, this.getValue()), color);

            ctx.globalAlpha *= 0.5;
            ctx.fillStyle = '#000';
            for (let r = 1 / ridgeCount ; r < 1 ; r += 1 / ridgeCount) {
                ctx.fillRect(r * width - width / 2, 0, 1, height);
            }
        });
    }
}


// ---- graphics/text.js ----
LOGO_GRADIENT = createCanvas(1, 1, (ctx) => {
    let grad = ctx.createLinearGradient(0, 0, 0, -150);
    grad.addColorStop(0, '#888');
    grad.addColorStop(0.7, '#eee');
    grad.addColorStop(1, '#888');
    return grad;
});

canvasPrototype.renderLargeText = function (bits) {
    with (this) {
        textBaseline = ('alphabetic');
        textAlign = ('left');
        fillStyle = LOGO_GRADIENT;
        strokeStyle = '#000';
        lineWidth = 4;
        shadowColor = '#000';

        let x = 0;
        for (let [text, size, offsetWidth] of bits) {
            font = size + ('px Times New Roman');
            x += measureText(text).width + (offsetWidth || 0);
        }

        translate(-x / 2, 0);

        x = 0;
        for (let [text, size, offsetWidth] of bits) {
            font = size + ('px Times New Roman');

            shadowBlur = 5;
            strokeText(text, x, 0);

            shadowBlur = 0;
            fillText(text, x, 0);

            x += measureText(text).width + (offsetWidth || 0);
        }

        return x;
    }
};

canvasPrototype.renderInstruction = function(text) {
    with (this) {
        textBaseline = ('middle');
        textAlign = ('center');
        strokeStyle = '#000';
        lineWidth = 4;
        font = ('18pt Times New Roman');

        let width = measureText(text).width + 20;
        fillStyle = 'rgba(0,0,0,.5)';
        fillRect(-width / 2, 0, width, 40);

        fillStyle = '#fff';
        strokeText(text, 0, 20);
        fillText(text, 0, 20);
    }
};


// ---- input/keyboard.js ----
let DOWN = {};

toggleOption = (n) => {
    if (n == 1) OPT_WEATHER = !OPT_WEATHER;
    if (n == 2) OPT_BLOOD = !OPT_BLOOD;
    if (n == 3) OPT_SHAKE = !OPT_SHAKE;
    if (n == 4) OPT_SLOWMO = !OPT_SLOWMO;
    if (n == 5) OPT_VIBRATE = !OPT_VIBRATE;
    if (n == 6) {
        ENEMY_COUNT_INDEX = (ENEMY_COUNT_INDEX + 1) % ENEMY_COUNTS.length;
        ENEMY_COUNT = ENEMY_COUNTS[ENEMY_COUNT_INDEX];
    }
    if (n == 9) PEACEFUL = !PEACEFUL;
    if (n == 7) TOUCH_LAYOUT = (TOUCH_LAYOUT + 1) % 3;
    if (n == 8) toggleFullscreen();
};

onkeydown = e => {
    let key = e.keyCode;

    if (key == 27 || key == 80) GAME_PAUSED = !GAME_PAUSED;

    // Back to the character select menu
    if (key == 77) backToMenu();

    // Options menu
    if (key == 79) {
        OPTIONS_OPEN = !OPTIONS_OPEN;
        GAME_PAUSED = !!OPTIONS_OPEN;
    }

    if (OPTIONS_OPEN && key >= 49 && key <= 57) toggleOption(key - 48);

    if (!OPTIONS_OPEN) {
        // Zoom
        if (key == 187 || key == 107) setZoom(1.15);
        if (key == 189 || key == 109) setZoom(1 / 1.15);
        if (key == 48) ZOOM_USER = 1;

        // Rig test moves
        if (key >= 49 && key <= 54) {
            let player = firstItem(level.scene.category('player'));
            if (player) player.testMove(key - 48);
        }
    }

    DOWN[key] = true;
};

onwheel = e => {
    if (OPTIONS_OPEN) return;
    let dy = e.deltaY * (e.deltaMode == 1 ? 16 : e.deltaMode == 2 ? 100 : 1);
    setZoom(exp(-dy * 0.0015));
};

onkeyup = e => DOWN[e.keyCode] = false;

// Reset inputs when window loses focus
onblur = onfocus = () => {
    DOWN = {};
    MOUSE_RIGHT_DOWN = MOUSE_DOWN = false;
};


// ---- input/mouse.js ----
MOUSE_DOWN = false;
MOUSE_RIGHT_DOWN = false;
MOUSE_POSITION = {x: 0, y: 0};

onmousedown = (evt) => evt.button == 2 ? MOUSE_RIGHT_DOWN = true : MOUSE_DOWN = true;
onmouseup = (evt) => evt.button == 2 ? MOUSE_RIGHT_DOWN = false : MOUSE_DOWN = false;
onmousemove = (evt) => getEventPosition(evt, can, MOUSE_POSITION);

oncontextmenu = (evt) => evt.preventDefault();

getEventPosition = (event, can, out) => {
    if (!can) return;
    let canvasRect = can.getBoundingClientRect();
    out.x = (event.pageX - canvasRect.left) / canvasRect.width * can.width;
    out.y = (event.pageY - canvasRect.top) / canvasRect.height * can.height;
}


// ---- input/touch.js ----
PINCH_DIST = 0;

class MobileJoystick {

    constructor() {
        this.x = this.y = 0;
        this.touch = {'x': 0, 'y': 0};
        this.touchIdentifier = -1;
    }

    render() {
        if (this.touchIdentifier < 0) return;

        let extraForceRatio = between(0, (dist(this, this.touch) - 50) / (150 - 50), 1);
        let radius = (1 - extraForceRatio) * 50;

        TOUCH_CONTROLS_CTX.globalAlpha = interpolate(0.5, 0, extraForceRatio);
        TOUCH_CONTROLS_CTX.strokeStyle = '#fff';
        TOUCH_CONTROLS_CTX.lineWidth = 2;
        TOUCH_CONTROLS_CTX.fillStyle = 'rgba(0,0,0,0.5)';
        TOUCH_CONTROLS_CTX.beginPath();
        TOUCH_CONTROLS_CTX.arc(this.x, this.y, radius * DPR, 0, TWO_PI);
        TOUCH_CONTROLS_CTX.fill();
        TOUCH_CONTROLS_CTX.stroke();

        TOUCH_CONTROLS_CTX.globalAlpha = 0.5;
        TOUCH_CONTROLS_CTX.fillStyle = '#fff';
        TOUCH_CONTROLS_CTX.beginPath();
        TOUCH_CONTROLS_CTX.arc(this.touch.x, this.touch.y, 30 * DPR, 0, TWO_PI);
        TOUCH_CONTROLS_CTX.fill();
    }
}

// Each button knows its position in the 3 selectable layouts, as an offset
// from an anchor corner: [dxFromRight, dyFromBottom, scale].
class MobileButton {
    constructor(label, layouts, tap) {
        this.label = label;
        this.layouts = layouts;
        this.tap = tap;
    }

    get slot() {
        return this.layouts[TOUCH_LAYOUT] || this.layouts[0];
    }

    get radius() {
        return 35 * (this.slot[2] || 1) * DPR;
    }

    x() {
        let [dx] = this.slot;
        return dx < 0
            ? -dx * DPR
            : TOUCH_CONTROLS_CANVAS.width - dx * DPR;
    }

    y() {
        return TOUCH_CONTROLS_CANVAS.height - this.slot[1] * DPR;
    }

    render() {
        TOUCH_CONTROLS_CTX.translate(this.x(), this.y());

        let r = this.radius;

        TOUCH_CONTROLS_CTX.strokeStyle = '#fff';
        TOUCH_CONTROLS_CTX.lineWidth = 2;
        TOUCH_CONTROLS_CTX.fillStyle = this.down ? 'rgba(255,255,255,0.55)' : 'rgba(0,0,0,0.45)';
        TOUCH_CONTROLS_CTX.beginPath();
        TOUCH_CONTROLS_CTX.arc(0, 0, r, 0, TWO_PI);
        TOUCH_CONTROLS_CTX.fill();
        TOUCH_CONTROLS_CTX.stroke();

        TOUCH_CONTROLS_CTX.scale(DPR, DPR);
        TOUCH_CONTROLS_CTX.font = ('13pt Courier');
        TOUCH_CONTROLS_CTX.textAlign = ('center');
        TOUCH_CONTROLS_CTX.textBaseline = ('middle');
        TOUCH_CONTROLS_CTX.fillStyle = '#fff';
        TOUCH_CONTROLS_CTX.fillText(this.label, 0, 0);
    }
}

updateTouches = (touches) => {
    let free = [];

    for (let button of TOUCH_BUTTONS) {
        button.wasHit = false;
    }

    for (let touch of touches) {
        getEventPosition(touch, TOUCH_CONTROLS_CANVAS, touch);
    }

    for (let button of TOUCH_BUTTONS) {
        let wasDown = button.down;
        button.down = false;
        for (let touch of touches) {
            if (dist({'x': button.x(), 'y': button.y()}, touch) < button.radius * 1.15) {
                button.down = true;
                touch.onButton = true;
            }
        }
        if (button.down && !wasDown && button.tap) button.tap();
    }

    for (let touch of touches) {
        if (!touch.onButton) free.push(touch);
    }

    // Pinch to zoom: two free fingers, distance change drives the zoom factor.
    if (free.length >= 2) {
        let d = dist(free[0], free[1]);
        if (PINCH_DIST) setZoom(d / PINCH_DIST);
        PINCH_DIST = d;
    } else {
        PINCH_DIST = 0;
    }

    let movementTouch, lookTouch;
    for (let touch of free) {
        if (touch.identifier === TOUCH_JOYSTICK.touchIdentifier) movementTouch = touch;
        else if (touch.identifier === TOUCH_LOOK.touchIdentifier) lookTouch = touch;
    }
    for (let touch of free) {
        if (touch === movementTouch || touch === lookTouch) continue;
        if (!movementTouch && touch.x < TOUCH_CONTROLS_CANVAS.width / 2) movementTouch = touch;
        else if (!lookTouch) lookTouch = touch;
    }

    for (let [stick, touch] of [[TOUCH_JOYSTICK, movementTouch], [TOUCH_LOOK, lookTouch]]) {
        if (touch) {
            if (stick.touchIdentifier < 0) {
                stick.x = touch.x;
                stick.y = touch.y;
            }
            stick.touchIdentifier = touch.identifier;
            stick.touch.x = touch.x;
            stick.touch.y = touch.y;
        } else {
            stick.touchIdentifier = -1;
        }
    }
};


// While the options menu is open, taps on a line toggle that option.
tapOptions = (touch) => {
    getEventPosition(touch, TOUCH_CONTROLS_CANVAS, touch);
    let y = touch.y / TOUCH_CONTROLS_CANVAS.height * 720;
    let index = round((y - 250) / 46) + 1;
    if (index >= 1 && index <= 9) {
        toggleOption(index);
    } else {
        OPTIONS_OPEN = GAME_PAUSED = 0;
    }
};

ontouchstart = (event) => {
    inputMode = 1;
    event.preventDefault();
    if (OPTIONS_OPEN) return;
    updateTouches(event.touches);
};

ontouchmove = (event) => {
    event.preventDefault();
    if (OPTIONS_OPEN) return;
    updateTouches(event.touches);
};

ontouchend = (event) => {
    event.preventDefault();

    if (OPTIONS_OPEN) {
        if (event.changedTouches[0]) tapOptions(event.changedTouches[0]);
        updateTouches([]);
        return;
    }

    updateTouches(event.touches);

    if (onclick) onclick();
};

renderTouchControls = () => {
    TOUCH_CONTROLS_CANVAS.style.display = inputMode == 1 ? ('block') : ('none');
    DPR = Math.min(devicePixelRatio, 2);
    let dpr = DPR;
    if (TOUCH_CONTROLS_CANVAS.width != innerWidth * dpr) TOUCH_CONTROLS_CANVAS.width = innerWidth * dpr;
    if (TOUCH_CONTROLS_CANVAS.height != innerHeight * dpr) TOUCH_CONTROLS_CANVAS.height = innerHeight * dpr;
    TOUCH_CONTROLS_CTX.clearRect(0, 0, TOUCH_CONTROLS_CANVAS.width, TOUCH_CONTROLS_CANVAS.height);

    for (let button of TOUCH_BUTTONS.concat([TOUCH_JOYSTICK, TOUCH_LOOK])) {
        TOUCH_CONTROLS_CTX.wrap(() => button.render());
    }

    requestAnimationFrame(renderTouchControls);
}

TOUCH_CONTROLS_CANVAS = document.createElement(('canvas'));
TOUCH_CONTROLS_CTX = TOUCH_CONTROLS_CANVAS.getContext('2d');

TOUCH_BUTTONS = [
    TOUCH_ATTACK_BUTTON = new MobileButton(('ATK'), [
        [170, 80, 1.25],
        [95, 190, 1.3],
        [200, 70, 1.2],
    ]),
    TOUCH_SHIELD_BUTTON = new MobileButton(('DEF'), [
        [80, 80],
        [95, 90, 1.1],
        [95, 105],
    ]),
    TOUCH_DASH_BUTTON = new MobileButton(('ROLL'), [
        [125, 160],
        [190, 140],
        [140, 175],
    ]),
    TOUCH_WHIRL_BUTTON = new MobileButton(('SPIN'), [
        [225, 160],
        [275, 90],
        [70, 210],
    ]),
    TOUCH_SLAM_BUTTON = new MobileButton(('SLAM'), [
        [175, 235],
        [275, 190],
        [235, 175],
    ]),
    TOUCH_SPRINT_BUTTON = new MobileButton(('RUN'), [
        [70, 235],
        [360, 90],
        [60, 320],
    ]),
    TOUCH_GUN_BUTTON = new MobileButton(('GUN'), [
        [265, 245],
        [360, 190],
        [180, 275],
    ], () => {
        let player = firstItem(level.scene.category('player'));
        if (player) player.toggleWeapon();
    }),
    TOUCH_SHADOW_BUTTON = new MobileButton(('SHDW'), [
        [175, 320],
        [455, 90],
        [300, 245],
    ]),
    TOUCH_ZOOM_IN_BUTTON = new MobileButton(('Z+'), [
        [-60, 260, 0.7],
        [-60, 260, 0.7],
        [-60, 340, 0.7],
    ], () => setZoom(1.2)),
    TOUCH_ZOOM_OUT_BUTTON = new MobileButton(('Z-'), [
        [-140, 260, 0.7],
        [-140, 260, 0.7],
        [-140, 340, 0.7],
    ], () => setZoom(1 / 1.2)),
    TOUCH_MOVE1_BUTTON = new MobileButton(('PNCH'), [
        [-60, 180, 0.7],
        [-60, 180, 0.7],
        [-60, 260, 0.7],
    ], () => {
        let p = firstItem(level.scene.category('player'));
        if (p) p.testMove(1);
    }),
    TOUCH_MOVE2_BUTTON = new MobileButton(('WAVE'), [
        [-140, 180, 0.7],
        [-140, 180, 0.7],
        [-140, 260, 0.7],
    ], () => {
        let p = firstItem(level.scene.category('player'));
        if (p) p.testMove(2);
    }),
    TOUCH_MOVE3_BUTTON = new MobileButton(('LEG'), [
        [-220, 180, 0.7],
        [-220, 180, 0.7],
        [-220, 260, 0.7],
    ], () => {
        let p = firstItem(level.scene.category('player'));
        if (p) p.testMove(3);
    }),
    TOUCH_MOVE4_BUTTON = new MobileButton(('KICK'), [
        [-60, 100, 0.7],
        [-60, 100, 0.7],
        [-60, 180, 0.7],
    ], () => {
        let p = firstItem(level.scene.category('player'));
        if (p) p.testMove(4);
    }),
    TOUCH_MOVE5_BUTTON = new MobileButton(('SPNK'), [
        [-140, 100, 0.7],
        [-140, 100, 0.7],
        [-140, 180, 0.7],
    ], () => {
        let p = firstItem(level.scene.category('player'));
        if (p) p.testMove(5);
    }),
    TOUCH_MOVE6_BUTTON = new MobileButton(('UPPR'), [
        [-220, 100, 0.7],
        [-220, 100, 0.7],
        [-220, 180, 0.7],
    ], () => {
        let p = firstItem(level.scene.category('player'));
        if (p) p.testMove(6);
    }),
    TOUCH_OPT_BUTTON = new MobileButton(('OPT'), [
        [60, 340, 0.7],
        [60, 340, 0.7],
        [60, 420, 0.7],
    ], () => {
        OPTIONS_OPEN = !OPTIONS_OPEN;
        GAME_PAUSED = !!OPTIONS_OPEN;
    }),
    TOUCH_MENU_BUTTON = new MobileButton(('MENU'), [
        [150, 340, 0.7],
        [150, 340, 0.7],
        [150, 420, 0.7],
    ], () => backToMenu()),
    TOUCH_FS_BUTTON = new MobileButton(('FS'), [
        [-60, 340, 0.7],
        [-60, 340, 0.7],
        [-60, 420, 0.7],
    ], () => toggleFullscreen()),
];

TOUCH_JOYSTICK = new MobileJoystick();
TOUCH_LOOK = new MobileJoystick();


TOUCH_CONTROLS_CANVAS.style.cssText = ('position:fixed;left:0;top:0;width:100%;height:100%;z-index:5;touch-action:none;pointer-events:none');
document.body.appendChild(TOUCH_CONTROLS_CANVAS);
renderTouchControls();


// ---- ai/character-controller.js ----
class CharacterController {
    start(entity) {
        this.entity = entity;
    }

    // get description() {
    //     return this.constructor.name;
    // }

    cycle() {}
}

class AI extends CharacterController {

    start(entity) {
        super.start(entity);
        return new Promise((resolve, reject) => {
            this.doResolve = resolve;
            this.doReject = reject;
        });
    }

    cycle() {
        let player = firstItem(this.entity.scene.category('player'));
        if (player) {
            this.update(player);
        }
    }

    update(player) {

    }

    resolve() {
        let { doResolve } = this;
        this.onDone();
        if (doResolve) doResolve();
    }

    reject(error) {
        let { doReject } = this;
        this.onDone();
        if (doReject) doReject(error);
    }

    onDone() {
        this.doReject = null;
        this.doReject = null;
    }
}

class EnemyAI extends AI {

    constructor() {
        super();
        this.ais = new Set();
    }

    cycle(elapsed) {
        super.cycle(elapsed);

        for (let ai of this.ais.values()) {
            ai.cycle(elapsed);
        }
    }

    // get description() {
    //     return Array.from(this.ais).map(ai => ai.description).join('+');
    // }

    async start(entity) {
        super.start(entity);
        await this.doStart(entity);
    }

    async doStart() {
        // implement in subclasses
    }

    update(player) {
        this.entity.controls.aim.x = player.x;
        this.entity.controls.aim.y = player.y;
    }

    startAI(ai) {
        return this.race([ai]);
    }

    async race(ais) {
        try {
            await Promise.race(ais.map(ai => {
                this.ais.add(ai);
                return ai.start(this.entity);
            }));
        } finally { 
            for (let ai of ais) {
                ai.reject(Error());
                ai.resolve(); // Allow the AI to clean up
                this.ais.delete(ai);
            }
        }
    }

    async sequence(ais) {
        for (let ai of ais) {
            await this.startAI(ai);
        }
    }
}

class Wait extends AI {

    constructor(duration) {
        super();
        this.duration = duration;
    }

    start(entity) {
        this.endTime = entity.age + this.duration;
        return super.start(entity);
    }

    update() {
        if (this.entity.age > this.endTime) {
            this.resolve();
        }
    }
}

class Timeout extends AI {

    constructor(duration) {
        super();
        this.duration = duration;
    }

    start(entity) {
        this.endTime = entity.age + this.duration;
        return super.start(entity);
    }

    update() {
        if (this.entity.age > this.endTime) {
            this.reject(Error());
        }
    }
}

class BecomeAggressive extends AI {
    update() {
        let tracker = firstItem(this.entity.scene.category('aggressivity-tracker'));
        if (tracker.requestAggression(this.entity)) {
            this.resolve();
        }
    }
}

class BecomePassive extends AI {
    update() {
        let tracker = firstItem(this.entity.scene.category('aggressivity-tracker'));
        tracker.cancelAggression(this.entity);
        this.resolve();
    }
}

class ReachPlayer extends AI {
    constructor(radiusX, radiusY) {
        super();
        this.radiusX = radiusX;
        this.radiusY = radiusY;
        this.angle = random() * TWO_PI;
    }

    update(player) {
        let { controls } = this.entity;

        controls.force = 0;

        if (!this.entity.isStrikable(player, this.radiusX, this.radiusY, PI / 2)) {
            controls.force = 1;
            controls.angle = angleBetween(this.entity, {
                x: player.x + cos(this.angle) * this.radiusX,
                y: player.y + sin(this.angle) * this.radiusY,
            });
        } else {
            this.resolve();
        }
    }
}

// Peaceful mode: wander around, mind their own business.
class Stroll extends AI {
    start(entity) {
        this.angle = random() * TWO_PI;
        this.endTime = entity.age + rnd(0.8, 3);
        this.walking = random() < 0.75;
        return super.start(entity);
    }

    update() {
        let { controls } = this.entity;
        controls.attack = controls.shield = controls.dash = false;
        controls.force = this.walking ? 0.55 : 0;
        controls.angle = this.angle;
        controls.aim.x = this.entity.x + cos(this.angle) * 100;
        controls.aim.y = this.entity.y + sin(this.angle) * 100;
        if (this.entity.age > this.endTime) this.resolve();
    }

    onDone() {
        this.entity.controls.force = 0;
    }
}

class Attack extends AI {
    constructor(chargeRatio) {
        super();
        this.chargeRatio = chargeRatio; 
    }

    update() {
        let { controls } = this.entity;

        controls.attack = true;

        if (this.entity.stateMachine.state.attackPreparationRatio >= this.chargeRatio) {
            // Attack was prepared, release!
            controls.attack = false;
            this.resolve();
        }
    }
}

class RetreatAI extends AI {
    constructor(radiusX, radiusY) {
        super();
        this.radiusX = radiusX;
        this.radiusY = radiusY;
    }

    update(player) {
        this.entity.controls.force = 0;

        if (this.entity.isStrikable(player, this.radiusX, this.radiusY, PI / 2)) {
            // Get away from the player
            this.entity.controls.force = 1;
            this.entity.controls.angle = angleBetween(player, this.entity);
        } else {
            this.resolve();
        }
    }

    onDone() {
        this.entity.controls.force = 0;
    }
}

class HoldShield extends AI {
    update() {
        this.entity.controls.shield = true;
    }

    onDone() {
        this.entity.controls.shield = false;
    }
}

class Dash extends AI {
    update() {
        this.entity.controls.dash = true;
    }

    onDone() {
        this.entity.controls.dash = false;
    }
}


// ---- entities/entity.js ----
class Entity {
    constructor() {
        this.x = this.y = this.rotation = this.age = 0;   
        this.categories = [];

        this.rng = new RNG();

        this.renderPadding = Infinity;

        this.affectedBySpeedRatio = true;
    }

    get z() { 
        return this.y; 
    }

    get inWater() {
        if (this.scene)
        for (let water of this.scene.category('water')) {
            if (water.contains(this)) return true;
        }
    }

    cycle(elapsed) {
        this.age += elapsed;
    }

    render() {
        let camera = firstItem(this.scene.category('camera'));
        if (
            isBetween(camera.x - 1280 / 2 - this.renderPadding, this.x, camera.x + 1280 / 2 + this.renderPadding) &&
            isBetween(camera.y - 720 / 2 - this.renderPadding, this.y, camera.y + 720 / 2 + this.renderPadding)
        ) {
            this.rng.reset();
            this.doRender(camera);
        }
    }

    doRender(camera) {

    }

    remove() {
        this.scene.remove(this);
    }

    cancelCameraOffset(camera) {
        ctx.translate(camera.x, camera.y);
        ctx.scale(1 / camera.appliedZoom, 1 / camera.appliedZoom);
        ctx.translate((-1280 / 2), (-720 / 2));
    }
}


// ---- entities/camera.js ----
class Camera extends Entity {
    constructor() {
        super();
        this.categories.push('camera');
        this.zoom = 1;
        this.affectedBySpeedRatio = false;

        this.minX = -(1280 / 2);
    }

    get appliedZoom() {
        // I'm a lazy butt and refuse to update the entire game to have a bit more zoom.
        // So instead I do dis ¯\_(ツ)_/¯
        return interpolate(1.2, 3, (this.zoom - 1) / 3) * ZOOM_USER;
    }

    cycle(elapsed) {
        super.cycle(elapsed);

        for (let player of this.scene.category('player')) {
            let target = {'x': player.x, 'y': player.y - 60 };
            let distance = dist(this, target);
            let angle = angleBetween(this, target);
            let appliedDist = min(distance, distance * elapsed * 3);
            this.x += appliedDist * cos(angle);
            this.y += appliedDist * sin(angle);
        }

        this.x = max(this.minX, this.x);

        SHAKE = max(0, SHAKE - elapsed * 40);
    }

    zoomTo(toValue) {
        if (this.previousInterpolator) {
            this.previousInterpolator.remove();
        }
        return this.scene.add(new Interpolator(this, 'zoom', this.zoom, toValue, 1)).await();
    }
}


// ---- entities/interpolator.js ----
class Interpolator extends Entity {

    constructor(
        object,
        property,
        fromValue,
        toValue,
        duration,
        easing = linear,
    ) {
        super();
        this.object = object;
        this.property = property;
        this.fromValue = fromValue;
        this.toValue = toValue;
        this.duration = duration;
        this.easing = easing;

        this.affectedBySpeedRatio = object.affectedBySpeedRatio;

        this.cycle(0);
    }

    await() {
        return new Promise(resolve => this.resolve = resolve);
    }

    cycle(elapsed) {
        super.cycle(elapsed);

        let progress = this.age / this.duration;

        this.object[this.property] = interpolate(this.fromValue, this.toValue, this.easing(progress));

        if (progress > 1) {
            this.remove();
            if (this.resolve) this.resolve();
        }
    }
}


// ---- entities/cursor.js ----
class Cursor extends Entity {
    constructor(player) {
        super();
        this.player = player;
    }

    get z() { 
        return 9994;
    }

    doRender() {
        if (inputMode == 1) return;
        ctx.translate(this.player.controls.aim.x, this.player.controls.aim.y);

        ctx.fillStyle = '#000';
        ctx.rotate(PI / 4);
        ctx.fillRect(-15, -5, 30, 10);
        ctx.rotate(PI / 2);
        ctx.fillRect(-15, -5, 30, 10);
    }
}


// ---- entities/path.js ----
class Path extends Entity {

    get z() {
        return -9992;
    }

    doRender(camera) {
        ctx.strokeStyle = WINTER ? '#eef' : '#dc9';
        ctx.lineWidth = 70;

        ctx.fillStyle = '#fff';

        ctx.beginPath();
        for (let x = roundToNearest(camera.x - 1280 * 2, 300) ; x < camera.x + 1280 ; x += 300) {
            let y = this.scene.pathCurve(x);
            ctx.lineTo(x, y);
        }
        ctx.stroke();
    }
}


// ---- entities/aggressivity-tracker.js ----
class AggressivityTracker extends Entity {
    constructor() {
        super();
        this.categories.push('aggressivity-tracker');
        this.currentAggression = 0;
        this.aggressive = new Set();
    }

    requestAggression(enemy) {
        this.cancelAggression(enemy);

        let { aggression } = enemy;
        if (this.currentAggression + aggression > 6) {
            return;
        }

        this.currentAggression += aggression;
        this.aggressive.add(enemy);
        return true
    }

    cancelAggression(enemy) {
        if (this.aggressive.has(enemy)) {
            let { aggression } = enemy;
            this.currentAggression -= aggression;
            this.aggressive.delete(enemy);
        }
    }

    doRender(camera) {
        if (0 && 0) {
            ctx.fillStyle = '#fff';
            ctx.strokeStyle = '#000';
            ctx.lineWidth = 5;
            ctx.textAlign = ('center');
            ctx.textBaseline = ('middle');
            ctx.font = ('12pt Courier');

            ctx.wrap(() => {
                ctx.translate(camera.x, camera.y - 100);
        
                ctx.strokeText('Agg: ' + this.currentAggression, 0, 0);
                ctx.fillText('Agg: ' + this.currentAggression, 0, 0);
            });

            let player = firstItem(this.scene.category('player'));
            if (!player) return;

            for (let enemy of this.aggressive) {
                ctx.strokeStyle = '#f00';
                ctx.lineWidth = 20;
                ctx.globalAlpha = 0.1;
                ctx.beginPath();
                ctx.moveTo(enemy.x, enemy.y);
                ctx.lineTo(player.x, player.y);
                ctx.stroke();
            }
        }
    }
}


// ---- entities/animations/full-charge.js ----
class FullCharge extends Entity {

    get z() { 
        return 9992; 
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        if (this.age > 0.25) {
            this.remove();
        }
    }

    doRender() {
        let ratio = this.age / 0.25;

        ctx.translate(this.x, this.y);
        ctx.scale(ratio, ratio);

        ctx.globalAlpha = 1 - ratio; 
        ctx.strokeStyle = '#ff0';
        ctx.lineWidth = 10;
        ctx.beginPath();
        ctx.arc(0, 0, 80, 0, TWO_PI);
        ctx.stroke();
    }
}


// ---- entities/animations/shield-block.js ----
class ShieldBlock extends Entity {

    get z() { 
        return 9992; 
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        if (this.age > 0.25) {
            this.remove();
        }
    }

    doRender() {
        let ratio = this.age / 0.25;

        ctx.translate(this.x, this.y);
        ctx.scale(ratio, ratio);

        ctx.globalAlpha = 1 - ratio; 
        ctx.strokeStyle = '#fff';
        ctx.lineWidth = 10;
        ctx.beginPath();
        ctx.arc(0, 0, 80, 0, TWO_PI);
        ctx.stroke();
    }
}


// ---- entities/animations/perfect-parry.js ----
class PerfectParry extends Entity {

    constructor() {
        super();
        this.affectedBySpeedRatio = false;
    }

    get z() { 
        return 9992; 
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        if (this.age > 0.5) {
            this.remove();
        }
    }

    doRender() {
        let ratio = this.age / 0.5;
        ctx.fillStyle = '#fff';

        ctx.translate(this.x, this.y);

        ctx.globalAlpha = (1 - ratio); 
        ctx.strokeStyle = '#fff';
        ctx.fillStyle = '#fff';
        ctx.lineWidth = 20;
        ctx.beginPath();

        for (let r = 0 ; r < 1 ; r+= 0.05) {
            let angle = r * TWO_PI;
            let radius = ratio * rnd(140, 200);
            ctx.lineTo(
                cos(angle) * radius,
                sin(angle) * radius,
            );
        }

        // ctx.closePath();

        // // ctx.arc(0, 0, 100, 0, TWO_PI);
        // ctx.stroke();
        ctx.fill();
    }
}


// ---- entities/animations/particle.js ----
class Particle extends Entity {

    constructor(
        color,
        valuesSize,
        valuesX,
        valuesY,
        duration,
    ) {
        super();
        this.color = color;
        this.valuesSize = valuesSize;
        this.valuesX = valuesX;
        this.valuesY = valuesY;
        this.duration = duration;
    }

    get z() { 
        return 9991; 
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        if (this.age > this.duration) {
            this.remove();
        }
    }

    interp(property) {
        let progress = this.age / this.duration;
        return property[0] + progress * (property[1] - property[0]);
    }

    doRender() {
        let size = this.interp(this.valuesSize);
        ctx.translate(this.interp(this.valuesX) - size / 2, this.interp(this.valuesY) - size / 2);
        ctx.rotate(PI / 4);

        ctx.fillStyle = this.color;
        ctx.globalAlpha = this.interp([1, 0]);
        ctx.fillRect(0, 0, size, size);
    }
}


// ---- entities/animations/swing-effect.js ----
class SwingEffect extends Entity {
    constructor(character, color, fromAngle, toAngle) {
        super();
        this.character = character;
        this.color = color;
        this.fromAngle = fromAngle;
        this.toAngle = toAngle;
        this.affectedBySpeedRatio = character.affectedBySpeedRatio;
    }

    get z() {
        return 9992;
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        if (this.age > 0.2) this.remove();
    }

    doRender() {
        ctx.globalAlpha = 1 - this.age / 0.2;

        ctx.translate(this.character.x, this.character.y);
        ctx.scale(this.character.facing, 1);
        ctx.translate(11, -42);

        ctx.strokeStyle = this.color;
        ctx.lineWidth = 40;
        ctx.beginPath();

        for (let r = 0 ; r < 1 ; r += 0.05) {
            ctx.wrap(() => {
                ctx.rotate(
                    interpolate(
                        this.fromAngle * PI / 2, 
                        this.toAngle * PI / 2,
                        r,
                    )
                );
                ctx.lineTo(18, -26);
            });
        }

        ctx.stroke();
    }
}


// ---- entities/animations/rain.js ----
class Rain extends Entity {
    get z() { 
        return 9993;
    }

    doRender(camera) {
        this.rng.reset();

        ctx.fillStyle = '#0af';

        this.cancelCameraOffset(camera);

        for (let i = 99 ; i-- ;) {
            ctx.wrap(() => {
                ctx.translate((1280 / 2), (720 / 2));
                ctx.rotate(this.rng.next(0, PI / 16));
                ctx.translate(-(1280 / 2), -(720 / 2));

                ctx.fillRect(
                    this.rng.next(0, 1280),
                    this.rng.next(1000, 2000) * (this.age + this.rng.next(0, 10)) % 720,
                    2,
                    20,
                );
            });
        }
    }
}


// ---- entities/animations/bird.js ----
class Bird extends Entity {
    constructor() {
        super();
        this.regen();
    }

    get z() { 
        return 9993;
    }

    regen() {
        this.age = 0;

        let cameraX = 0, cameraY = 0;
        if (this.scene) {
            let camera = firstItem(this.scene.category('camera'));
            cameraX = camera.x;
            cameraY = camera.y;
        }
        this.x = rnd(cameraX - (1280 / 2), cameraX + (1280 / 2));
        this.y = cameraY - (720 / 2 + 100);
        this.rotation = rnd(PI / 4, PI * 3 / 4);
    }

    cycle(elapsed) {
        super.cycle(elapsed);

        let camera = firstItem(this.scene.category('camera'));
        if (this.y > camera.y + (720 / 2 + 300)) {
            this.regen();
        }

        this.x += cos(this.rotation) * elapsed * 300;
        this.y += sin(this.rotation) * elapsed * 300;
    }

    doRender() {
        ctx.translate(this.x, this.y + 300);

        ctx.withShadow(() => {
            ctx.strokeStyle = ctx.resolveColor('#000');
            ctx.lineWidth = 4;
            ctx.beginPath();

            ctx.translate(0, -300);

            let angle = sin(this.age * TWO_PI * 4) * PI / 16 + PI / 4;

            ctx.lineTo(-cos(angle) * 10, -sin(angle) * 10);
            ctx.lineTo(0, 0);
            ctx.lineTo(cos(angle) * 10, -sin(angle) * 10);
            ctx.stroke();
        });
    }
}


// ---- entities/animations/snow.js ----
class Snow extends Entity {
    get z() {
        return 9993;
    }

    doRender(camera) {
        if (!OPT_WEATHER) return;

        this.rng.reset();

        this.cancelCameraOffset(camera);

        ctx.fillStyle = '#fff';

        for (let i = 120 ; i-- ;) {
            let seed = this.rng.next(0, 20);
            let speed = this.rng.next(60, 220);
            let drift = this.rng.next(20, 90);
            let size = this.rng.next(2, 6);

            let x = (this.rng.next(0, 1280) + sin((this.age + seed) * 2) * drift + 1280 * 2) % 1280;
            let y = (speed * (this.age + seed)) % 720;

            ctx.globalAlpha = this.rng.next(0.35, 0.95);
            ctx.fillRect(x, y, size, size);
        }
    }
}


// ---- entities/animations/shockwave.js ----
class Shockwave extends Entity {
    constructor(color = '#fff', maxRadius = 220, duration = 0.5) {
        super();
        this.color = color;
        this.maxRadius = maxRadius;
        this.duration = duration;
        this.affectedBySpeedRatio = false;
    }

    get z() {
        return 9992;
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        if (this.age > this.duration) this.remove();
    }

    doRender() {
        let ratio = this.age / this.duration;

        ctx.translate(this.x, this.y);
        ctx.globalAlpha = 1 - ratio;

        ctx.strokeStyle = this.color;

        for (let scale of [1, 0.6]) {
            ctx.lineWidth = interpolate(16, 1, ratio) * scale;
            ctx.beginPath();
            ctx.ellipse(0, 0, this.maxRadius * ratio * scale, this.maxRadius * ratio * scale / 2, 0, 0, TWO_PI);
            ctx.stroke();
        }
    }
}


// ---- entities/animations/ember.js ----
// Ambient drifting motes: ash near battlefields, snow dust in the north.
class Ember extends Entity {
    constructor(color = '#fff') {
        super();
        this.color = color;
        this.regen();
    }

    get z() {
        return 9993;
    }

    regen() {
        this.age = 0;
        this.seed = rnd(0, 10);

        let cameraX = 0, cameraY = 0;
        if (this.scene) {
            let camera = firstItem(this.scene.category('camera'));
            cameraX = camera.x;
            cameraY = camera.y;
        }

        this.x = rnd(cameraX - (1280 / 2), cameraX + (1280 / 2));
        this.y = cameraY + (720 / 2);
        this.speed = rnd(30, 90);
        this.size = rnd(2, 5);
    }

    cycle(elapsed) {
        super.cycle(elapsed);

        let camera = firstItem(this.scene.category('camera'));
        if (this.y < camera.y - (720 / 2 + 100)) this.regen();

        this.y -= this.speed * elapsed;
        this.x += cos((this.age + this.seed) * 2) * 30 * elapsed;
    }

    doRender() {
        if (!OPT_WEATHER) return;

        ctx.translate(this.x, this.y);
        ctx.globalAlpha = 0.3 + abs(sin((this.age + this.seed) * 3)) * 0.6;
        ctx.fillStyle = this.color;
        ctx.fillRect(0, 0, this.size, this.size);
    }
}


// ---- entities/animations/gore.js ----
// Lingering blood decals + bigger, meatier hit/death effects.
class BloodPool extends Entity {
    constructor(x, y, size) {
        super();
        this.x = x;
        this.y = y;
        this.size = size;
        this.blobs = [];
        for (let i = 0; i < 7; i++) {
            this.blobs.push([rnd(-size, size), rnd(-size / 3, size / 3), rnd(size / 3, size)]);
        }
    }

    get z() {
        return -9990;
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        if (this.age > 14) this.remove();
    }

    doRender() {
        if (!OPT_BLOOD) return;
        ctx.globalAlpha = between(0, min(1, this.age * 3) * (1 - this.age / 14), 1) * 0.7;
        ctx.fillStyle = '#5a0006';
        ctx.translate(this.x, this.y);
        let grow = min(1, this.age * 2);
        for (let [bx, by, br] of this.blobs) {
            ctx.beginPath();
            ctx.ellipse(bx * grow, by * grow, br * grow, br * grow * 0.4, 0, 0, TWO_PI);
            ctx.fill();
        }
    }
}

bloodBurst = (scene, x, y, amount, power) => {
    if (!OPT_BLOOD) return;
    for (let i = 0; i < amount; i++) {
        let angle = random() * TWO_PI;
        let d = rnd(20, 60) * power;
        scene.add(new Particle(
            pick(['#900', '#b00', '#6a0009']),
            [rnd(2, 6), 0],
            [x, x + cos(angle) * d],
            [y, y + sin(angle) * d],
            rnd(0.2, 0.55),
        ));
    }
};

class Bullet extends Entity {
    constructor(shooter, angle, speed, damage, color) {
        super();
        this.categories.push('bullet');
        this.shooter = shooter;
        this.angle = angle;
        this.speed = speed || 900;
        this.damage = damage || 18;
        this.color = color || '#fe8';
        this.x = shooter.x + cos(angle) * 20;
        this.y = shooter.y - 44 + sin(angle) * 20;
        this.groundY = shooter.y + sin(angle) * 20;
        this.targetTeam = shooter.targetTeam;
    }

    get z() {
        return 9992;
    }

    cycle(elapsed) {
        super.cycle(elapsed);

        let step = this.speed * elapsed;
        this.x += cos(this.angle) * step;
        this.y += sin(this.angle) * step;
        this.groundY += sin(this.angle) * step;

        for (let victim of Array.from(this.scene.category(this.targetTeam))) {
            if (victim.health <= 0) continue;
            if (abs(victim.x - this.x) < 26 && abs(victim.y - this.groundY) < 40) {
                victim.damage(this.damage);
                victim.dash(this.angle, 20, 0.1);
                bloodBurst(this.scene, this.x, this.y, 12, 1);
                vibrate(20);
                this.remove();
                return;
            }
        }

        if (this.age > 1.2) this.remove();
    }

    doRender() {
        ctx.translate(this.x, this.y);
        ctx.rotate(this.angle);
        ctx.fillStyle = this.color;
        ctx.globalAlpha = 0.9;
        ctx.fillRect(-14, -1.5, 20, 3);
    }
}

class MuzzleFlash extends Entity {
    constructor(x, y, angle) {
        super();
        this.x = x;
        this.y = y;
        this.angle = angle;
    }

    get z() {
        return 9992;
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        if (this.age > 0.08) this.remove();
    }

    doRender() {
        ctx.translate(this.x, this.y - 44);
        ctx.rotate(this.angle);
        ctx.fillStyle = '#ffd';
        ctx.globalAlpha = 1 - this.age / 0.08;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(30, -9);
        ctx.lineTo(38, 0);
        ctx.lineTo(30, 9);
        ctx.fill();
    }
}


// ---- entities/props/grass.js ----
class Grass extends Entity {

    constructor() {
        super();
        this.renderPadding = 100;
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        regenEntity(this, 1280 / 2 + 50, 720 / 2 + 50);
    }

    doRender() {
        ctx.translate(this.x, this.y);
        
        ctx.withShadow(() => {
            this.rng.reset();

            let x = 0;
            for (let i = 0 ; i < (inputMode == 1 ? 2 : 5) ; i++) {
                ctx.wrap(() => {
                    ctx.fillStyle = ctx.resolveColor(WINTER ? '#dde' : '#ab8');
                    ctx.translate(x, 0);
                    ctx.rotate(sin((this.age + this.rng.next(0, 5)) * TWO_PI / this.rng.next(4, 8)) * this.rng.next(PI / 16, PI / 4));
                    ctx.fillRect(-2, 0, 4, -this.rng.next(5, 30));
                });

                x += this.rng.next(5, 15);
            }
        });
    }
}


// ---- entities/props/obstacle.js ----
class Obstacle extends Entity {

    constructor() {
        super();
        this.categories.push('obstacle');
    }
}


// ---- entities/props/tree.js ----
class Tree extends Obstacle {

    constructor() {
        super();

        this.trunkWidth = this.rng.next(10, 20);
        this.trunkHeight = this.rng.next(100, 250);

        this.collisionRadius = 20;
        this.alpha = 1;
        
        this.renderPadding = this.trunkHeight + 60;
    }

    cycle(elapsed) {
        super.cycle(elapsed);

        if (!this.noRegen) regenEntity(this, 1280 / 2 + 200, 720 / 2 + 400);

        this.rng.reset();

        let targetAlpha = 1;
        for (let character of this.scene.category('player')) {
            if (
                isBetween(this.x - 100, character.x, this.x + 100) &&
                isBetween(this.y - this.trunkHeight - 50, character.y, this.y)
            ) {
                targetAlpha = 0.2;
                break;
            }
        }

        this.alpha += between(-elapsed * 2, targetAlpha - this.alpha, elapsed * 2);
    }

    doRender() {
        ctx.translate(this.x, this.y);
        
        ctx.withShadow(() => {
            this.rng.reset();

            ctx.wrap(() => {
                ctx.rotate(sin((this.age + this.rng.next(0, 10)) * TWO_PI / this.rng.next(4, 16)) * this.rng.next(PI / 32, PI / 64));
                ctx.fillStyle = ctx.resolveColor('#a65');

                if (!ctx.isShadow) {
                    ctx.globalAlpha = this.alpha;
                }

                if (!ctx.isShadow) ctx.fillRect(0, 0, this.trunkWidth, -this.trunkHeight);

                ctx.translate(0, -this.trunkHeight);

                ctx.beginPath();
                ctx.fillStyle = ctx.resolveColor('#060');

                for (let i = 0 ; i < 5 ; i++) {
                    let angle = i / 5 * TWO_PI;
                    let dist = this.rng.next(20, 50);
                    let x =  cos(angle) * dist;
                    let y = sin(angle) * dist * 0.5;
                    let radius = this.rng.next(20, 40);

                    ctx.wrap(() => {
                        ctx.translate(x, y);
                        ctx.rotate(PI / 4);
                        ctx.rotate(sin((this.age + this.rng.next(0, 10)) * TWO_PI / this.rng.next(2, 8)) * PI / 32);
                        ctx.rect(-radius, -radius, radius * 2, radius * 2);
                    });
                }

                if (ctx.isShadow) ctx.rect(0, 0, this.trunkWidth, this.trunkHeight);

                ctx.fill();
            });

            ctx.clip();

            if (!ctx.isShadow) {
                for (let character of this.scene.category('enemy')) {
                    if (
                        isBetween(this.x - 100, character.x, this.x + 100) &&
                        isBetween(this.y - this.trunkHeight - 50, character.y, this.y)
                    ) {
                        ctx.resolveColor = () => character instanceof Player ? '#888' : '#400';
                        ctx.wrap(() => {
                            ctx.translate(character.x - this.x, character.y - this.y);
                            ctx.scale(character.facing, 1);
                            ctx.globalAlpha = this.alpha;
                            character.renderBody();
                        });
                    }
                }
            }
        });
    }
}


// ---- entities/props/bush.js ----
class Bush extends Entity {

    constructor() {
        super();
        this.renderPadding = 100;
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        regenEntity(this, 1280 / 2 + 50, 720 / 2 + 50);
    }

    doRender() {
        ctx.translate(this.x, this.y);
        
        ctx.withShadow(() => {
            this.rng.reset();

            let x = 0;
            for (let i = 0 ; i < 5 ; i++) {
                ctx.wrap(() => {
                    ctx.fillStyle = ctx.resolveColor(WINTER ? '#8ad' : 'green');
                    ctx.translate(x, 0);
                    ctx.rotate(sin((this.age + this.rng.next(0, 5)) * TWO_PI / this.rng.next(4, 8)) * this.rng.next(PI / 32, PI / 16));
                    ctx.fillRect(-10, 0, 20, -this.rng.next(20, 60));
                });

                x += this.rng.next(5, 15);
            }
        });
    }
}


// ---- entities/props/water.js ----
class Water extends Entity {
    constructor() {
        super();
        this.categories.push('water');
        this.width = this.height = 0;
    }

    get z() { 
        return -9991; 
    }

    get inWater() {
        return false;
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        this.renderPadding = max(this.width, this.height) / 2;
        regenEntity(this, 1280 * 2, 720 * 2, max(this.width, this.height));
    }

    contains(point) {
        let xInSelf = point.x - this.x;
        let yInSelf = point.y - this.y;

        let xInSelfRotated = xInSelf * cos(this.rotation) + yInSelf * sin(this.rotation);
        let yInSelfRotated = -xInSelf * sin(this.rotation) + yInSelf * cos(this.rotation);

        return abs(xInSelfRotated) < this.width / 2 && abs(yInSelfRotated) < this.height / 2;
    }

    doRender() {
        this.rng.reset();

        ctx.wrap(() => {
            ctx.fillStyle = '#08a';
            ctx.translate(this.x, this.y);
            ctx.rotate(this.rotation);
            ctx.beginPath();
            ctx.rect(-this.width / 2, -this.height / 2, this.width, this.height);
            ctx.fill();
            ctx.clip();

            // Ripples
            ctx.rotate(-this.rotation);
            ctx.scale(1, 0.5);
            ctx.strokeStyle = '#fff';
            ctx.lineWidth = 4;

            for (let i = 3; i-- ; ) {
                let relativeAge = (this.age + this.rng.next(0, 20)) / 2;
                let ratio = min(1, relativeAge % (2 / 2));

                ctx.globalAlpha = (1 - ratio) / 2;
                ctx.beginPath();
                ctx.arc(
                    ((this.rng.next(0, this.width) + ~~relativeAge * this.width * 0.7) % this.width) - this.width / 2,
                    ((this.rng.next(0, this.height) + ~~relativeAge * this.height * 0.7) % this.height) - this.width / 2,
                    ratio * this.rng.next(20, 60),
                    0,
                    TWO_PI,
                );
                ctx.stroke();
            }
        });
    }
}


// ---- entities/props/pine.js ----
// Snow-laden conifer for the northern act.
class Pine extends Obstacle {

    constructor() {
        super();

        this.trunkWidth = this.rng.next(12, 22);
        this.trunkHeight = this.rng.next(60, 130);
        this.tiers = ~~this.rng.next(3, 6);

        this.collisionRadius = 22;
        this.alpha = 1;

        this.renderPadding = this.trunkHeight + 220;
    }

    cycle(elapsed) {
        super.cycle(elapsed);

        if (!this.noRegen) regenEntity(this, 1280 / 2 + 200, 720 / 2 + 400);

        this.rng.reset();

        let targetAlpha = 1;
        for (let character of this.scene.category('player')) {
            if (
                isBetween(this.x - 100, character.x, this.x + 100) &&
                isBetween(this.y - this.trunkHeight - 150, character.y, this.y)
            ) {
                targetAlpha = 0.25;
                break;
            }
        }

        this.alpha += between(-elapsed * 2, targetAlpha - this.alpha, elapsed * 2);
    }

    doRender() {
        ctx.translate(this.x, this.y);

        ctx.withShadow(() => {
            this.rng.reset();

            ctx.wrap(() => {
                ctx.rotate(sin((this.age + this.rng.next(0, 10)) * TWO_PI / this.rng.next(6, 16)) * PI / 128);

                if (!ctx.isShadow) ctx.globalAlpha = this.alpha;

                // Trunk
                ctx.fillStyle = ctx.resolveColor('#543');
                ctx.fillRect(-this.trunkWidth / 2, 0, this.trunkWidth, -this.trunkHeight);

                ctx.translate(0, -this.trunkHeight);

                // Tiers of needles, each capped with snow
                let width = this.rng.next(60, 80);
                let y = 0;
                for (let i = 0 ; i < this.tiers ; i++) {
                    let height = this.rng.next(50, 70);

                    ctx.fillStyle = ctx.resolveColor('#132');
                    ctx.beginPath();
                    ctx.moveTo(-width / 2, y);
                    ctx.lineTo(0, y - height);
                    ctx.lineTo(width / 2, y);
                    ctx.fill();

                    if (!ctx.isShadow) {
                        ctx.fillStyle = ctx.resolveColor('#eef');
                        ctx.beginPath();
                        ctx.moveTo(-width / 2, y);
                        ctx.lineTo(0, y - height);
                        ctx.lineTo(width / 2, y);
                        ctx.lineTo(width / 4, y - height / 4);
                        ctx.lineTo(0, y - height / 8);
                        ctx.lineTo(-width / 4, y - height / 3);
                        ctx.fill();
                    }

                    y -= height * 0.6;
                    width *= 0.75;
                }
            });
        });
    }
}


// ---- entities/props/rock.js ----
// Snow-capped boulder, blocks movement.
class Rock extends Obstacle {

    constructor() {
        super();

        this.size = this.rng.next(25, 55);
        this.collisionRadius = this.size * 0.8;
        this.renderPadding = 150;
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        if (!this.noRegen) regenEntity(this, 1280 / 2 + 200, 720 / 2 + 300);
    }

    doRender() {
        ctx.translate(this.x, this.y);

        ctx.withShadow(() => {
            this.rng.reset();

            ctx.fillStyle = ctx.resolveColor('#778');
            ctx.beginPath();
            for (let r = 0 ; r < 1 ; r += 1 / 7) {
                let angle = r * TWO_PI;
                let radius = this.size * this.rng.next(0.7, 1);
                ctx.lineTo(cos(angle) * radius, sin(angle) * radius * 0.6 - this.size * 0.4);
            }
            ctx.fill();

            if (!ctx.isShadow) {
                this.rng.reset();
                ctx.fillStyle = ctx.resolveColor('#dde');
                ctx.beginPath();
                for (let r = 0 ; r < 0.5 ; r += 1 / 7) {
                    let angle = r * TWO_PI + PI;
                    let radius = this.size * this.rng.next(0.7, 1);
                    ctx.lineTo(cos(angle) * radius, sin(angle) * radius * 0.6 - this.size * 0.5);
                }
                ctx.fill();
            }
        });
    }
}


// ---- entities/props/banner.js ----
// Northern Empire war banner, pure decor.
class Banner extends Entity {

    constructor() {
        super();
        this.renderPadding = 250;
        this.height = this.rng.next(120, 180);
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        if (!this.noRegen) regenEntity(this, 1280 / 2 + 200, 720 / 2 + 300);
    }

    doRender() {
        ctx.translate(this.x, this.y);

        ctx.withShadow(() => {
            this.rng.reset();

            ctx.fillStyle = ctx.resolveColor('#432');
            ctx.fillRect(-3, 0, 6, -this.height);

            ctx.translate(0, -this.height);

            // Waving cloth
            ctx.fillStyle = ctx.resolveColor('#248');
            ctx.beginPath();
            ctx.moveTo(0, 0);
            for (let y = 0 ; y <= 70 ; y += 10) {
                ctx.lineTo(sin((this.age * 3) + y / 20) * 6, y);
            }
            ctx.lineTo(45 + sin(this.age * 3 + 4) * 8, 60);
            for (let y = 70 ; y >= 0 ; y -= 10) {
                ctx.lineTo(45 + sin((this.age * 3) + y / 20 + 2) * 8, y);
            }
            ctx.fill();

            if (!ctx.isShadow) {
                ctx.fillStyle = ctx.resolveColor('#eef');
                ctx.fillRect(16, 18, 10, 34);
                ctx.fillRect(6, 28, 30, 10);
            }
        });
    }
}


// ---- entities/props/ground.js ----
// Minimal "bare land" arena floor: soft gradient dirt with a faint 3D grid
// that fades with distance. Nothing else in the world for now.
class Ground extends Entity {
    get z() {
        return -9992;
    }

    doRender(camera) {
        let w = 1280 / camera.appliedZoom;
        let h = 720 / camera.appliedZoom;
        let x0 = camera.x - w;
        let y0 = camera.y - h;

        let grad = ctx.createLinearGradient(0, y0, 0, y0 + h * 2);
        grad.addColorStop(0, '#20242b');
        grad.addColorStop(0.5, '#33363c');
        grad.addColorStop(1, '#1b1e24');
        ctx.fillStyle = grad;
        ctx.fillRect(x0, y0, w * 2, h * 2);

        // Perspective-ish grid: rows get tighter towards the top
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5;
        ctx.globalAlpha = 0.06;
        ctx.beginPath();
        for (let x = roundToNearest(x0, 200); x < x0 + w * 2; x += 200) {
            ctx.moveTo(x, y0);
            ctx.lineTo(x, y0 + h * 2);
        }
        for (let y = roundToNearest(y0, 120); y < y0 + h * 2; y += 120) {
            ctx.moveTo(x0, y);
            ctx.lineTo(x0 + w * 2, y);
        }
        ctx.stroke();

        // Pool of light around the player
        let player = firstItem(this.scene.category('player'));
        if (player) {
            ctx.globalAlpha = 1;
            let light = ctx.createRadialGradient(player.x, player.y, 0, player.x, player.y, 700);
            light.addColorStop(0, 'rgba(255,240,210,.10)');
            light.addColorStop(1, 'rgba(0,0,0,0)');
            ctx.fillStyle = light;
            ctx.fillRect(x0, y0, w * 2, h * 2);
        }
    }
}


// ---- entities/ui/label.js ----
class Label extends Entity {
    constructor(text, color = '#fff') {
        super();
        this.text = text.toUpperCase();
        this.color = color;
    }

    get z() { 
        return 9994; 
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        if (this.age > 1 && !this.infinite) this.remove();
    }

    doRender() {
        ctx.translate(this.x, interpolate(this.y + 20, this.y, this.age / 0.25));
        if (!this.infinite) ctx.globalAlpha = interpolate(0, 1, this.age / 0.25);

        ctx.font = ('bold 14pt Arial');
        ctx.fillStyle = this.color;
        ctx.strokeStyle = '#000';
        ctx.lineWidth = 3;
        ctx.textAlign = ('center');
        ctx.textBaseline = ('middle');

        ctx.shadowColor = '#000';
        ctx.shadowOffsetX = ctx.shadowOffsetY = 1;

        ctx.strokeText(this.text, 0, 0);
        ctx.fillText(this.text, 0, 0);
    }
}


// ---- entities/ui/fade.js ----
class Fade extends Entity {
    constructor() {
        super();
        this.alpha = 1;
    }

    get z() { 
        return 9996;
    }

    doRender(camera) {
        this.cancelCameraOffset(camera);

        ctx.fillStyle = '#000';
        ctx.globalAlpha = this.alpha;
        ctx.fillRect(0, 0, 1280, 720);
    }
}


// ---- entities/ui/logo.js ----
class Logo extends Entity {
    constructor() {
        super();
        this.alpha = 1;
    }

    get z() { 
        return 9995; 
    }

    doRender(camera) {
        if (GAME_PAUSED) return;

        ctx.globalAlpha = this.alpha;

        ctx.wrap(() => {
            this.cancelCameraOffset(camera);
    
            ctx.fillStyle = '#000';
            ctx.fillRect(0, 0, 1280, 720);

            ctx.translate((1280 / 2), (720 / 3));
            ctx.renderLargeText([
                [('P'), 192, -30],
                [('ATH'), 96, 30],
                [('TO'), 36, 20],
                [('G'), 192],
                [('LORY'), 96],
            ]);      
        });

        for (let player of this.scene.category('player')) {
            player.doRender(camera);
            if (BEATEN) ctx.renderCrown(player);
        }
    }
}


// ---- entities/ui/announcement.js ----
class Announcement extends Entity {
    constructor(text) {
        super();
        this.text = text;
        this.affectedBySpeedRatio = false;
    }

    get z() { 
        return 9995; 
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        if (this.age > 5) this.remove();
    }

    doRender(camera) {
        this.cancelCameraOffset(camera);

        ctx.globalAlpha = this.age < 1 
            ? interpolate(0, 1, this.age)
            : interpolate(1, 0, this.age - 4);

        ctx.wrap(() => {
            ctx.translate(40, (720 - 40));

            ctx.fillStyle = '#fff';
            ctx.strokeStyle = '#000';
            ctx.lineWidth = 4;
            ctx.textAlign = ('left');
            ctx.textBaseline = ('alphabetic');
            ctx.font = ('72pt Times New Roman');
            ctx.strokeText(this.text, 0, 0);
            ctx.fillText(this.text, 0, 0);
        });
    }
}


// ---- entities/ui/instruction.js ----
class Instruction extends Entity {

    get z() { 
        return 9997; 
    }

    cycle(elapsed) {
        super.cycle(elapsed);

        if (this.text != this.previousText) {
            this.previousText = this.text;
            this.textAge = 0; 
        }
        this.textAge += elapsed;
    }

    doRender(camera) {
        if (!this.text || GAME_PAUSED) return;

        this.cancelCameraOffset(camera);

        ctx.translate(1280 / 2, 720 * 5 / 6);

        ctx.scale(
            interpolate(1.2, 1, this.textAge * 8),
            interpolate(1.2, 1, this.textAge * 8),
        );
        ctx.renderInstruction(this.text);
    }
}


// ---- entities/ui/exposition.js ----
class Exposition extends Entity {

    constructor(text) {
        super();
        this.text = text;
        this.alpha = 1;
    }

    get z() { 
        return 9997; 
    }

    doRender(camera) {
        if (!this.text) return;

        this.cancelCameraOffset(camera);

        ctx.translate(150, (720 / 2));

        ctx.textBaseline = ('middle');
        ctx.textAlign = ('left');
        ctx.fillStyle = '#fff';
        ctx.font = ('24pt Times New Roman');

        let y = -this.text.length / 2 * 50;
        let lineIndex = 0;
        for (let line of this.text) {
            ctx.globalAlpha = between(0, (this.age - lineIndex * 3), 1) * this.alpha;
            ctx.fillText(line, 0, y);
            y += 75;
            lineIndex++;
        }
    }
}


// ---- entities/ui/pause-overlay.js ----
class PauseOverlay extends Entity {
    get z() { 
        return 9995 + 1; 
    }

    doRender(camera) {
        if (!GAME_PAUSED) return;

        this.cancelCameraOffset(camera);

        ctx.fillStyle = 'rgba(0,0,0,0.5)';
        ctx.fillRect(0, 0, 1280, 720);

        ctx.wrap(() => {
            ctx.translate(1280 / 2, 720 / 3);

            ctx.renderLargeText([
                [('G'), 192],
                [('AME'), 96, 30],
                [('P'), 192, -30],
                [('AUSED'), 96],
            ]);
        });

        ctx.wrap(() => {
            ctx.translate(1280 / 2, 720 * 3 / 4);
            ctx.renderInstruction(('[P] or [ESC] to resume'));
        });

    }
}


// ---- entities/ui/options-overlay.js ----
// Toggled with [O] / the OPT button. Numeric keys or taps to change.
class OptionsOverlay extends Entity {
    get z() {
        return 9995 + 2;
    }

    doRender(camera) {
        if (!OPTIONS_OPEN) return;

        this.cancelCameraOffset(camera);

        ctx.fillStyle = 'rgba(0,0,0,.8)';
        ctx.fillRect(0, 0, 1280, 720);

        ctx.wrap(() => {
            ctx.translate(1280 / 2, 150);
            ctx.renderLargeText([
                [('O'), 120],
                [('PTIONS'), 60, 16],
            ]);
        });

        let lines = [
            [('[1] Weather effects'), OPT_WEATHER ? ('ON') : ('OFF')],
            [('[2] Blood & gore'), OPT_BLOOD ? ('ON') : ('OFF')],
            [('[3] Screen shake'), OPT_SHAKE ? ('ON') : ('OFF')],
            [('[4] Slow motion'), OPT_SLOWMO ? ('ON') : ('OFF')],
            [('[5] Vibration'), OPT_VIBRATE ? ('ON') : ('OFF')],
            [('[6] Enemies at once'), '' + ENEMY_COUNT],
            [('[7] Mobile layout'), '' + (TOUCH_LAYOUT + 1)],
            [('[8] Fullscreen'), ('TOGGLE')],
            [('[9] Enemies attack'), PEACEFUL ? ('NO') : ('YES')],
        ];

        ctx.wrap(() => {
            ctx.textAlign = ('center');
            ctx.textBaseline = ('middle');
            ctx.font = ('22pt Times New Roman');
            ctx.strokeStyle = '#000';
            ctx.lineWidth = 4;

            let y = 250;
            for (let [label, value] of lines) {
                let text = label + ': ' + value;
                ctx.fillStyle = '#fff';
                ctx.strokeText(text, 1280 / 2, y);
                ctx.fillText(text, 1280 / 2, y);
                y += 46;
            }
        });

        ctx.wrap(() => {
            ctx.translate(1280 / 2, 720 - 70);
            ctx.renderInstruction(('[Q] spin [E] shadow [F] slam [Z] run [G] gun [+/-] zoom [1-3] moves'));
        });
    }
}


// ---- entities/characters/character-hud.js ----
class CharacterHUD extends Entity {
    constructor(character) {
        super();
        this.character = character;

        this.healthGauge = new Gauge(() => this.character.health / this.character.maxHealth);
        this.staminaGauge = new Gauge(() => this.character.stamina);
    }

    get z() { 
        return 9990; 
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        this.healthGauge.cycle(elapsed);
        this.staminaGauge.cycle(elapsed);
        if (!this.character.health) this.remove();
    }

    doRender() {
        if (
            this.character.health > 0.5 && 
            this.character.age - max(this.character.lastStaminaLoss, this.character.lastDamage) > 2
        ) return;
 
        ctx.translate(this.character.x, this.character.y + 20);
        ctx.wrap(() => {
            ctx.translate(0, 4);
            this.staminaGauge.render(60, 6, staminaGradient, true);
        });
        this.healthGauge.render(80, 5, healthGradient);
    }
}


// ---- entities/characters/player-hud.js ----
class PlayerHUD extends Entity {
    constructor(player) {
        super();
        this.player = player;

        this.healthGauge = new Gauge(() => this.player.health / this.player.maxHealth);
        this.staminaGauge = new Gauge(() => this.player.stamina);
        this.progressGauge = new Gauge(() => this.progress);

        this.healthGauge.regenRate = 0.1;
        this.progressGauge.regenRate = 0.1;

        this.progressGauge.displayedValue = 0;

        this.progress = 0;
        this.progressAlpha = 0;

        this.dummyPlayer = new Player();
        this.dummyKing = new KingEnemy();

        this.affectedBySpeedRatio = false;
    }

    get z() { 
        return 9994; 
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        this.healthGauge.cycle(elapsed);
        this.staminaGauge.cycle(elapsed);
        this.progressGauge.cycle(elapsed);
    }

    doRender(camera) {
        this.cancelCameraOffset(camera);

        ctx.wrap(() => {
            ctx.translate(1280 / 2, 50);
            ctx.wrap(() => {
                ctx.translate(0, 10);
                this.staminaGauge.render(300, 20, staminaGradient, true);
            });
            this.healthGauge.render(400, 20, healthGradient);
        });

        ctx.wrap(() => {
            ctx.globalAlpha = this.progressAlpha;

            ctx.translate(1280 / 2, 720 - 150);
            this.progressGauge.render(600, 10, '#fff', false, 8);

            ctx.resolveColor = () => '#fff';
            ctx.shadowColor = '#000';
            ctx.shadowBlur = 1;

            ctx.wrap(() => {
                ctx.translate(interpolate(-300, 300, this.progressGauge.displayedValue), 20);
                ctx.scale(0.5, 0.5);
                this.dummyPlayer.renderBody();
            });

            ctx.wrap(() => {
                ctx.translate(300, 20);
                ctx.scale(-0.5, 0.5);
                this.dummyKing.renderBody();
            });
        });

        ctx.wrap(() => {
            ctx.translate(1280 / 2, 90);

            ctx.fillStyle = '#fff';
            ctx.strokeStyle = '#000';
            ctx.lineWidth = 4;
            ctx.textBaseline = ('top');
            ctx.textAlign = ('center');
            ctx.font = ('bold 16pt Times New Roman');
            ctx.strokeText(('SCORE: ') + this.player.score.toLocaleString(), 0, 0);
            ctx.fillText(('SCORE: ') + this.player.score.toLocaleString(), 0, 0);
        });

        // Ability cooldowns
        ctx.wrap(() => {
            ctx.translate(60, 720 - 90);

            ctx.textAlign = ('left');
            ctx.textBaseline = ('middle');
            ctx.font = ('bold 14pt Times New Roman');
            ctx.strokeStyle = '#000';
            ctx.lineWidth = 4;

            let abilities = [
                [('[Q] WHIRLWIND'), this.player.whirlwindCooldown / 4],
                [('[F] WAR SLAM'), this.player.slamCooldown / 8],
                [('[Z] SPRINT'), this.player.sprinting ? 1 : 0],
            ];

            let y = 0;
            for (let [label, ratio] of abilities) {
                ctx.wrap(() => {
                    ctx.globalAlpha = 0.4;
                    ctx.fillStyle = '#000';
                    ctx.fillRect(-6, y - 12, 190, 24);
                });

                ctx.wrap(() => {
                    ctx.globalAlpha = 0.5;
                    ctx.fillStyle = ratio > 0 ? '#f60' : '#0af';
                    ctx.fillRect(-6, y - 12, 190 * (ratio > 0 ? 1 - ratio : 1), 24);
                });

                ctx.fillStyle = ratio > 0 ? '#bbb' : '#fff';
                ctx.strokeText(label, 0, y);
                ctx.fillText(label, 0, y);

                y += 30;
            }
        });

        if (this.player.combo > 0) {
            ctx.wrap(() => {
                ctx.translate(1280 / 2 + 200, 70);

                ctx.fillStyle = '#fff';
                ctx.strokeStyle = '#000';
                ctx.lineWidth = 4;
                ctx.textBaseline = ('middle');
                ctx.textAlign = ('right');
                ctx.font = ('bold 36pt Times New Roman');

                ctx.rotate(-PI / 32);

                let ratio = min(1, (this.player.age - this.player.lastComboChange) / 0.1);
                ctx.scale(1 + 1 - ratio, 1 + 1 - ratio);

                ctx.strokeText('X' + this.player.combo, 0, 0);
                ctx.fillText('X' + this.player.combo, 0, 0);
            });
        }
    }
}


// ---- entities/characters/character.js ----
class Character extends Entity {
    constructor() {
        super();
        this.categories.push('character', 'obstacle');

        this.renderPadding = 90;

        this.facing = 1;

        this.health = this.maxHealth = 100;

        this.combo = 0;

        this.stamina = 1;

        this.lastDamage = this.lastStaminaLoss = this.lastComboChange = -9;

        this.baseSpeed = 200;

        this.strikeRadiusX = 80;
        this.strikeRadiusY = 40;

        this.magnetRadiusX = this.magnetRadiusY = 0;

        this.collisionRadius = 30;

        this.strength = 100;
        this.damageCount = this.parryCount = 0;

        this.staminaRecoveryDelay = 99;

        this.setController(this.ai);

        this.gibs = [];

        this.controls = {
            'force': 0,
            'angle': 0,
            // 'shield': false,
            // 'attack': false,
            'aim': {'x': 0, 'y': 0},
            // 'dash': false,
        };

        this.stateMachine = characterStateMachine({
            entity: this, 
        });
    }

    setController(controller) {
        (this.controller = controller).start(this);
    }

    get ai() {
        return new AI();
    }

    getColor(color) {
        return this.age - this.lastDamage < 0.1 ? '#fff' : color;
    }

    cycle(elapsed) {
        super.cycle(elapsed);

        this.renderAge = this.age * (this.inWater ? 0.5 : 1)

        this.stateMachine.cycle(elapsed);

        this.controller.cycle(elapsed);

        if (this.inWater && this.controls.force) {
            this.loseStamina(elapsed * 0.2);
        }

        let speed = this.stateMachine.state.speedRatio * this.baseSpeed;
        
        this.x += cos(this.controls.angle) * this.controls.force * speed * elapsed;
        this.y += sin(this.controls.angle) * this.controls.force * speed * elapsed;

        this.facing = sign(this.controls.aim.x - this.x) || 1;

        // Collisions with other characters and obstacles
        for (let obstacle of this.scene.category('obstacle')) {
            if (obstacle === this || dist(this, obstacle) > obstacle.collisionRadius) continue;
            let angle = angleBetween(this, obstacle);
            this.x = obstacle.x - cos(angle) * obstacle.collisionRadius;
            this.y = obstacle.y - sin(angle) * obstacle.collisionRadius;
        }

        // Stamina regen
        if (this.age - this.lastStaminaLoss > this.staminaRecoveryDelay || this.stateMachine.state.exhausted) {
            this.stamina = min(1, this.stamina + elapsed * 0.3);
        }

        // Combo reset
        if (this.age - this.lastComboChange > 5) {
            this.updateCombo(-99);
        }
    }

    updateCombo(value) {
        this.combo = max(0, this.combo + value);
        this.lastComboChange = this.age;
    }

    isStrikable(victim, radiusX, radiusY) {
        return this.strikability(victim, radiusX, radiusY, PI / 2) > 0;
    }

    isWithinRadii(character, radiusX, radiusY) {
        return abs(character.x - this.x) < radiusX && 
            abs(character.y - this.y) < radiusY;
    }

    strikability(victim, radiusX, radiusY, fov) {
        if (victim === this || !radiusX || !radiusY) return 0;

        let angleToVictim = angleBetween(this, victim);
        let aimAngle = angleBetween(this, this.controls.aim);
        let angleScore = 1 - abs(normalize(angleToVictim - aimAngle)) / (fov / 2);

        let dX = abs(this.x - victim.x);
        let adjustedDY = abs(this.y - victim.y) / (radiusY / radiusX);

        let adjustedDistance = hypot(dX, adjustedDY);
        let distanceScore = 1 - adjustedDistance / radiusX;

        return distanceScore < 0 || angleScore < 0 
            ? 0
            : (distanceScore + pow(angleScore, 3));
    }

    pickVictims(radiusX, radiusY, fov) {
        return Array
            .from(this.scene.category(this.targetTeam))
            .filter((victim) => this.strikability(victim, radiusX, radiusY, fov) > 0);
    }

    pickVictim(radiusX, radiusY, fov) {
        return this.pickVictims(radiusX, radiusY, fov)
            .reduce((acc, other) => {
                if (!acc) return other;

                return this.strikability(other, radiusX, radiusX, fov) > this.strikability(acc, radiusX, radiusY, fov) 
                    ? other 
                    : acc;
            }, null);
        
    }

    lunge() {
        let victim = this.pickVictim(this.magnetRadiusX, this.magnetRadiusY, PI / 2);
        victim
            ? this.dash(
                angleBetween(this, victim), 
                max(0, dist(this, victim) - this.strikeRadiusY / 2), 
                0.1,
            )
            : this.dash(
                angleBetween(this, this.controls.aim), 
                40, 
                0.1,
            );
    }

    strike(relativeStrength) {
        sound(...[.1,,400,.1,.01,,3,.92,17,,,,,2,,,,1.04]);

        for (let victim of this.pickVictims(this.strikeRadiusX, this.strikeRadiusY, TWO_PI)) {
            let angle = angleBetween(this, victim);
            if (victim.stateMachine.state.shielded) {
                victim.facing = sign(this.x - victim.x) || 1;
                victim.parryCount++;

                // Push back
                this.dash(angle + PI, 20, 0.1);

                if (victim.stateMachine.state.perfectParry) {
                    // Perfect parry, victim gets stamina back, we lose ours
                    victim.stamina = 1;
                    victim.updateCombo(1);
                    victim.displayLabel(('Perfect Block!'));

                    let animation = this.scene.add(new PerfectParry());
                    animation.x = victim.x;
                    animation.y = victim.y - 30;
                    
                    this.perfectlyBlocked = true; // Disable "exhausted" label
                    this.loseStamina(1);

                    for (let parryVictim of this.scene.category(victim.targetTeam)) {
                        if (victim.isWithinRadii(parryVictim, victim.strikeRadiusX * 2, victim.strikeRadiusY * 2)) {
                            parryVictim.dash(angleBetween(victim, parryVictim), 100, 0.2);
                        }
                    }

                    (async () => {
                        this.scene.speedRatio = 0.1;

                        let camera = firstItem(this.scene.category('camera'));
                        await camera.zoomTo(2);
                        await this.scene.delay(3 * this.scene.speedRatio);
                        await camera.zoomTo(1);
                        this.scene.speedRatio = 1;
                    })();

                    sound(...[2.14,,1e3,.01,.2,.31,3,3.99,,.9,,,.08,1.9,,,.22,.34,.12]);
                } else {
                    // Regular parry, victim loses stamina
                    victim.loseStamina(relativeStrength * this.strength / 100);
                    victim.displayLabel(('Blocked!'));
                
                    let animation = this.scene.add(new ShieldBlock());
                    animation.x = victim.x;
                    animation.y = victim.y - 30;

                    sound(...[2.03,,200,,.04,.12,1,1.98,,,,,,-2.4,,,.1,.59,.05,.17]);
                }
            } else {
                victim.damage(~~(this.strength * relativeStrength));
                victim.dash(angle, this.strength * relativeStrength, 0.1);

                // Regen a bit of health after a kill
                if (!victim.health) {
                    this.heal(this.maxHealth * 0.1);
                }

                this.updateCombo(1);

                let impactX = victim.x + rnd(-20, 20);
                let impactY = victim.y - 30 + rnd(-20, 20);
                let size = rnd(1, 2);

                bloodBurst(this.scene, impactX, impactY, 26, 1 + size / 2);
                if (OPT_BLOOD) this.scene.add(new BloodPool(victim.x, victim.y, rnd(10, 18)));
                shake(5);
                vibrate(25);
            }
        }
    }

    displayLabel(text, color) {
        if (this.lastLabel) this.lastLabel.remove();

        this.lastLabel = this.scene.add(new Label(text, color));
        this.lastLabel.x = this.x;
        this.lastLabel.y = this.y - 90;
    }

    loseStamina(amount) {
        this.stamina = max(0, this.stamina - amount);
        this.lastStaminaLoss = this.age;
    }

    damage(amount) {
        this.health = max(0, this.health - amount);
        this.lastDamage = this.age;
        this.damageCount++;

        if (!this.stateMachine.state.exhausted) this.loseStamina(amount / this.maxHealth * 0.3);
        this.updateCombo(-99);
        this.displayLabel('' + amount, this.damageLabelColor);

        // Death
        if (!this.health) this.die();
    }

    heal() {}

    doRender() {
        let { inWater, renderAge } = this;

        ctx.translate(this.x, this.y);

        if (0 && 0) {
            ctx.wrap(() => {
                ctx.lineWidth = 10;
                ctx.strokeStyle = '#f00';
                ctx.globalAlpha = 0.1;
                ctx.beginPath();
                ctx.ellipse(0, 0, this.strikeRadiusX, this.strikeRadiusY, 0, 0, TWO_PI);
                ctx.stroke();

                ctx.beginPath();
                ctx.ellipse(0, 0, this.magnetRadiusX, this.magnetRadiusY, 0, 0, TWO_PI);
                ctx.stroke();
            });
        }

        let orig = ctx.resolveColor || (x => x);
        ctx.resolveColor = x => this.getColor(orig(x));

        ctx.withShadow(() => {
            if (inWater) {
                ctx.beginPath();
                ctx.rect(-150, -150, 300, 150);
                ctx.clip();

                ctx.translate(0, 10);
            }

            let { facing } = this;
            let { dashAngle } = this.stateMachine.state;

            // Pseudo-3D body yaw: the fighter turns a full 360 towards the aim
            if (this.rotate3d && dashAngle === undefined) {
                let yaw = angleBetween(this, this.controls.aim);
                let sx = cos(yaw);
                facing = sign(sx) || 1;
                this.facing = facing;
                this.backView = sin(yaw) < -0.25;
                ctx.rotate(-sin(yaw) * 0.1 * facing);
                ctx.scale(facing * max(0.42, abs(sx)), 1 + abs(sin(yaw)) * 0.05);
                ctx.wrap(() => this.renderBody(renderAge));
                return;
            }
            if (dashAngle !== undefined) {
                facing = sign(cos(dashAngle));
    
                ctx.translate(0, -30);
                ctx.rotate(this.stateMachine.state.age / 0.3 * facing * TWO_PI);
                ctx.translate(0, 30);
            }

            ctx.scale(facing, 1);

            ctx.wrap(() => this.renderBody(renderAge));
        });

        if (0) {
            ctx.fillStyle = '#fff';
            ctx.strokeStyle = '#000';
            ctx.lineWidth = 3;
            ctx.textAlign = ('center');
            ctx.textBaseline = ('middle');
            ctx.font = ('12pt Courier');

            let bits = [];
            if (0) {
                bits.push(...[
                    ('State: ') + this.stateMachine.state.constructor.name,
                    ('HP: ') + ~~this.health + '/' + this.maxHealth,
                ]);
            }
            
            if (0) {
                bits.push(...[
                    ('AI: ') + this.controller.constructor.name,
                ]);
            }
            
            if (0) {
                bits.push(...[
                    ('Speed: ') + this.baseSpeed,
                    ('Strength: ') + this.strength,
                    ('Aggro: ') + this.aggression,
                ]);
            }
        
            let y = -90;
            for (let text of bits.reverse()) {
                ctx.strokeText(text, 0, y);
                ctx.fillText(text, 0, y);

                y -= 20;
            }
        }
    }

    dash(angle, distance, duration) {
        this.scene.add(new Interpolator(this, 'x', this.x, this.x + cos(angle) * distance, duration));
        this.scene.add(new Interpolator(this, 'y', this.y, this.y + sin(angle) * distance, duration));
    }

    die() {
        let duration = 1;

        let gibs = this.gibs.concat([true, false].map((sliceUp) => () => {
            ctx.slice(30, sliceUp, 0.5);
            ctx.translate(0, 30);
            this.renderBody();
        }));

        for (let step of gibs) {
            let bit = this.scene.add(new Corpse(step));
            bit.x = this.x;
            bit.y = this.y;
    
            let angle = angleBetween(this, this.controls.aim) + PI + rnd(-1, 1) * PI / 4;
            let distance = rnd(30, 60);
            this.scene.add(new Interpolator(bit, 'x', bit.x, bit.x + cos(angle) * distance, duration, easeOutQuint));
            this.scene.add(new Interpolator(bit, 'y', bit.y, bit.y + sin(angle) * distance, duration, easeOutQuint));
            this.scene.add(new Interpolator(bit, 'rotation', 0, pick([-1, 1]) * rnd(PI / 4, PI), duration, easeOutQuint));
        }

        this.poof();

        bloodBurst(this.scene, this.x, this.y - 40, 60, 2.2);
        if (OPT_BLOOD) this.scene.add(new BloodPool(this.x, this.y, rnd(24, 40)));
        shake(12);
        vibrate([30, 40, 60]);

        this.displayLabel(('Slain!'), this.damageLabelColor);

        this.remove();

        sound(...[2.1,,400,.03,.1,.4,4,4.9,.6,.3,,,.13,1.9,,.1,.08,.32]);
    }

    poof() {
        for (let i = 0 ; i < 80 ; i++) {
            let angle = random() * TWO_PI;
            let dist = random() * 40;

            let x = this.x + cos(angle) * dist;
            let y = this.y - 30 + sin(angle) * dist;

            this.scene.add(new Particle(
                '#fff',
                [10, 20],
                [x, x + rnd(-20, 20)],
                [y, y + rnd(-20, 20)],
                rnd(0.5, 1),
            ));
        }
    }
}


// ---- entities/characters/player.js ----
FOV_GRADIENT = [0, 255].map(red => createCanvas(1, 1, ctx => {
    let grad = ctx.createRadialGradient(0, 0, 0, 0, 0, 250);
    grad.addColorStop(0, 'rgba(' + red + ',0,0,.1)');
    grad.addColorStop(1, 'rgba(' + red + ',0,0,0)');
    return grad;
}));

class Player extends Character {
    constructor() {
        super();
        this.categories.push('player');

        this.targetTeam = 'enemy';

        this.score = 0;

        this.baseSpeed = 250;
        this.strength = 30;

        // Ninja: faster, lighter, deadlier on the counter-attack.
        this.ninja = HERO === 1;
        this.model3d = HERO >= 2;

        if (this.ninja) {
            this.baseSpeed = 330;
            this.strength = 26;
            this.staminaRecoveryDelay = 1.2;
            this.trail = [];
        }

        this.staminaRecoveryDelay = 2;

        this.magnetRadiusX = this.magnetRadiusY = 250;

        this.affectedBySpeedRatio = false;

        this.damageLabelColor = '#f00';

        this.gibs = [
            () => this.ninja ? ctx.renderKatana() : ctx.renderSword(),
            () => ctx.renderShield(),
        ];

        this.stateMachine = characterStateMachine({
            entity: this, 
            chargeTime: 1,
            perfectParryTime: 0.15,
            releaseAttackBetweenStrikes: true,
            staggerTime: 0.2,
        });
        // Full 360 body rotation + pose system
        this.rotate3d = 1;
        this.strikeT = 1;
        this.strikeStyle = 0;
        this.crouch = 0;
        this.gun = 0;
        this.ammo = 12;
        this.muzzle = 0;

        // Special moves
        this.whirlwindCooldown = this.slamCooldown = this.shadowCooldown = 0;

        // Rig test moves ([1] punches, [2] sword wave, [3] leg lift)
        this.testPose = 0;
        this.testT = 1;
        this.spin = 0;
        this.upgraded = 0;
    }

    get ai() {
        return new PlayerController();
    }

    // Act II hero: veteran gear, tougher, hits harder.
    upgrade() {
        this.upgraded = 1;
        this.health = this.maxHealth = this.ninja ? 130 : 160;
        this.strength = this.ninja ? 38 : 42;
        this.baseSpeed = this.ninja ? 360 : 280;
    }

    // The player's stamina bar is a testing tool here: effectively unlimited.
    loseStamina() {
        this.stamina = 1;
    }

    // Rig demo: procedurally driven moves to check what the skeleton can do.
    testMove(n) {
        this.testPose = n;
        this.testT = 0;
        let durations = [1.1, 1.3, 1.6, 0.9, 1.1, 1];
        this.scene.add(new Interpolator(this, 'testT', 0, 1, durations[n - 1] || 1));
        this.displayLabel([
            ('Punch Combo'),
            ('Sword Wave'),
            ('Crane Stance'),
            ('Front Kick'),
            ('Spin Kick'),
            ('Uppercut'),
        ][n - 1], '#8cf');
        shake(4);
        vibrate(15);
        sound(...[1.03,,329,.02,.09,.05,2,.56,,-0.2,,,,1.5,,1.1,,.72,.02,.3]);
    }


    toggleWeapon() {
        this.gun = !this.gun;
        this.displayLabel(this.gun ? ('Pistol') : ('Blade'), '#fd6');
        sound(...[1.03,,329,.02,.09,.05,2,.56,,-0.2,,,,1.5,,1.1,,.72,.02,.3]);
    }

    shoot() {
        if (this.age - (this.lastShot || -9) < 0.22) return;
        this.lastShot = this.age;
        this.muzzle = 0.12;

        let angle = angleBetween(this, this.controls.aim);
        this.scene.add(new Bullet(this, angle, 1100, ~~(this.strength * 0.8), '#ff8'));
        let flash = this.scene.add(new MuzzleFlash(this.x + cos(angle) * 24, this.y, angle));
        flash.groundY = this.y;
        this.dash(angle + PI, 12, 0.08);
        shake(6);
        vibrate(30);
        sound(...[1.99,,427,.01,,.07,,.62,6.7,-0.7,,,,.2,,,.11,.76,.05]);
    }

    // Sword strikes auto-cycle through a set of distinct attacks
    strike(relativeStrength) {
        this.strikeStyle = (this.strikeStyle + 1 + ~~(random() * 2)) % STRIKE_POSES.length;
        this.strikeT = 0;
        this.scene.add(new Interpolator(this, 'strikeT', 0, 1, 0.26));
        if (relativeStrength > 0.9) this.displayLabel(STRIKE_NAMES[this.strikeStyle], '#fff');

        if (this.gun) return this.shoot();

        vibrate(15);

        if (this.ninja) {
            let a = angleBetween(this, this.controls.aim);
            for (let i = 0 ; i < (MOBILE ? 4 : 8) ; i++) {
                let sa = a + rnd(-0.5, 0.5);
                this.scene.add(new Particle(
                    '#dff',
                    [rnd(2, 5), 0],
                    [this.x + cos(a) * 20, this.x + cos(sa) * rnd(50, 130)],
                    [this.y - 40, this.y - 40 + sin(sa) * rnd(20, 60)],
                    rnd(0.12, 0.3),
                ));
            }
        }

        super.strike(relativeStrength);
    }

    cycle(elapsed) {
        this.muzzle = max(0, this.muzzle - elapsed);
        this.crouch = this.controls.shield ? min(6, this.crouch + elapsed * 40) : max(0, this.crouch - elapsed * 40);
        this.whirlwindCooldown = max(0, this.whirlwindCooldown - elapsed);
        this.slamCooldown = max(0, this.slamCooldown - elapsed);
        this.shadowCooldown = max(0, this.shadowCooldown - elapsed);
        if (this.testPose && this.testT >= 1) this.testPose = 0;

        // Sprint: faster, but drains stamina
        let sprinting = this.controls.sprint && this.stamina > 0.05 && this.controls.force;
        this.sprinting = sprinting;
        this.speedMultiplier = sprinting ? 1.7 : 1;
        let baseSpeed = this.baseSpeed;
        this.baseSpeed *= this.speedMultiplier;

        super.cycle(elapsed);

        this.baseSpeed = baseSpeed;

        // Ninja afterimages
        if (this.ninja) {
            this.trail.push({'x': this.x, 'y': this.y, 'a': this.age, 'f': this.facing});
            while (this.trail.length && (this.age - this.trail[0].a > 0.18 || this.trail.length > (MOBILE ? 6 : 14))) this.trail.shift();
        }

        if (sprinting) {
            this.loseStamina(elapsed * 0.3);

            if (this.age % 0.1 < elapsed) {
                this.scene.add(new Particle(
                    WINTER ? '#fff' : '#cb9',
                    [6, 0],
                    [this.x, this.x + rnd(-20, 20)],
                    [this.y, this.y - rnd(5, 25)],
                    rnd(0.2, 0.5),
                ));
            }
        }

        if (this.controls.whirlwind && !this.whirlwindCooldown && this.stamina > 0.3) this.whirlwind();
        if (this.controls.slam && !this.slamCooldown && this.stamina > 0.4) this.slam();
        if (this.controls.shadow && !this.shadowCooldown && this.stamina > 0.25) this.shadowStrike();
    }

    // [Q] Spinning strike, hits everything around the hero.
    whirlwind() {
        this.whirlwindCooldown = this.ninja ? 2.5 : 4;
        this.loseStamina(0.3);
        this.displayLabel(this.ninja ? ('Blade Dance!') : ('Whirlwind!'), '#fff');
        shake(10);
        sound(...[1.4,,180,.02,.15,.25,1,1.8,,,,,.05,1.6,,.2,.1,.7,.05]);

        let wave = this.scene.add(new Shockwave('#fff', 240, 0.45));
        wave.x = this.x;
        wave.y = this.y - 20;

        this.scene.add(new Interpolator(this, 'spin', TWO_PI * 2, 0, 0.5));

        for (let victim of Array.from(this.scene.category('enemy'))) {
            if (victim.health <= 0 || dist(this, victim) > 200) continue;
            let angle = angleBetween(this, victim);
            victim.damage(~~(this.strength * 0.9));
            victim.dash(angle, 120, 0.2);
            this.updateCombo(1);
        }
    }

    // [F] Ground slam: wide knockback that also breaks guards.
    slam() {
        this.slamCooldown = 8;
        this.loseStamina(0.4);
        this.displayLabel(('War Slam!'), '#fb0');
        shake(20);
        sound(...[2.2,,110,.05,.2,.4,4,3,,,,,.2,1.5,,.3,.2,.5,.1]);

        let wave = this.scene.add(new Shockwave(WINTER ? '#0ef' : '#fb0', 420, 0.7));
        wave.x = this.x;
        wave.y = this.y - 10;

        for (let i = 0 ; i < 30 ; i++) {
            let angle = random() * TWO_PI;
            this.scene.add(new Particle(
                WINTER ? '#dff' : '#ba8',
                [rnd(4, 8), 0],
                [this.x, this.x + cos(angle) * rnd(40, 160)],
                [this.y, this.y + sin(angle) * rnd(20, 80)],
                rnd(0.3, 0.7),
            ));
        }

        for (let victim of Array.from(this.scene.category('enemy'))) {
            if (victim.health <= 0 || dist(this, victim) > 380) continue;
            let angle = angleBetween(this, victim);
            victim.damage(~~(this.strength * 0.6));
            victim.dash(angle, 220, 0.35);
            victim.loseStamina(1);
        }
    }


    // [E] Shadow Strike: blink onto the closest enemy and cut through them.
    shadowStrike() {
        this.shadowCooldown = this.ninja ? 3 : 5;
        this.loseStamina(0.25);

        let target, best = 520;
        for (let enemy of this.scene.category('enemy')) {
            let d = dist(this, enemy);
            if (enemy.health > 0 && d < best) best = d, target = enemy;
        }

        let angle = target ? angleBetween(this, target) : angleBetween(this, this.controls.aim);
        this.displayLabel(('Shadow Strike!'), '#8cf');
        sound(...[1.5,,660,.01,.08,.16,1,1.4,,,,,.03,1.4,,.15,.08,.6,.03]);
        shake(8);
        vibrate(25);

        // Blink past the target
        if (target) {
            let d = max(0, dist(this, target) - 40);
            this.x += cos(angle) * d;
            this.y += sin(angle) * d;
        } else {
            this.dash(angle, 260, 0.15);
        }

        for (let i = 0 ; i < 14 ; i++) {
            let a = angle + PI + rnd(-0.6, 0.6);
            this.scene.add(new Particle(
                '#8cf',
                [rnd(3, 7), 0],
                [this.x, this.x + cos(a) * rnd(30, 120)],
                [this.y, this.y + sin(a) * rnd(15, 60)],
                rnd(0.2, 0.5),
            ));
        }

        this.strike(1);
        if (target && target.health > 0) {
            target.damage(~~(this.strength * 1.4));
            target.dash(angle, 90, 0.15);
            target.loseStamina(0.6);
            this.updateCombo(1);
        }
    }

    damage(amount) {
        super.damage(amount);
        sound(...[2.07,,71,.01,.05,.03,2,.14,,,,,.01,1.5,,.1,.19,.95,.05,.16]);
    }

    getColor(color) {
        return this.age - this.lastDamage < 0.1 ? '#f00' : super.getColor(color);
    }

    heal(amount) {
        amount = ~~min(this.maxHealth - this.health, amount);
        this.health += amount

        for (let i = amount ; --i > 0 ;) {
            setTimeout(() => {
                let angle = random() * TWO_PI;
                let dist = random() * 40;

                let x = this.x + rnd(-10, 10);
                let y = this.y - 30 + sin(angle) * dist;

                this.scene.add(new Particle(
                    '#0f0',
                    [5, 10],
                    [x, x + rnd(-10, 10)],
                    [y, y + rnd(-30, -60)],
                    rnd(1, 1.5),
                ));
            }, i * 100);
        }
    }

    render() {
        let victim = this.pickVictim(this.magnetRadiusX, this.magnetRadiusY, PI / 2);
        if (victim) {
            ctx.wrap(() => {
                if (0) return;

                ctx.globalAlpha = 0.2;
                ctx.strokeStyle = '#f00';
                ctx.lineWidth = 5;
                ctx.setLineDash([10, 10]);
                ctx.beginPath();
                ctx.moveTo(this.x, this.y);
                ctx.lineTo(victim.x, victim.y);
                ctx.stroke();
            });
        }

        ctx.wrap(() => {
            if (0) return;

            ctx.translate(this.x, this.y);

            let aimAngle = angleBetween(this, this.controls.aim);
            ctx.fillStyle = FOV_GRADIENT[+!!victim];
            ctx.beginPath();
            ctx.arc(0, 0, this.magnetRadiusX, aimAngle - PI / 4, aimAngle + PI / 4);
            ctx.lineTo(0, 0);
            ctx.fill();
        });

        if (0 && 0) {
            ctx.wrap(() => {
                ctx.fillStyle = '#0f0';
                for (let x = this.x - this.magnetRadiusX - 20 ; x < this.x + this.magnetRadiusX + 20 ; x += 4) {
                    for (let y = this.y - this.magnetRadiusY - 20 ; y < this.y + this.magnetRadiusY + 20 ; y += 4) {
                        ctx.globalAlpha = this.strikability({ x, y }, this.magnetRadiusX, this.magnetRadiusY, PI / 2);
                        ctx.fillRect(x - 2, y - 2, 4, 4);
                    }
                }
            });
            ctx.wrap(() => {
                for (let victim of this.scene.category(this.targetTeam)) {
                    let strikability = this.strikability(victim, this.magnetRadiusX, this.magnetRadiusY, PI / 2);
                    if (!strikability) continue;
                    ctx.lineWidth = strikability * 30;
                    ctx.strokeStyle = '#ff0';
                    ctx.beginPath();
                    ctx.moveTo(this.x, this.y);
                    ctx.lineTo(victim.x, victim.y);
                    ctx.stroke();
                }
            });
        }

        if (this.ninja && this.trail && this.health > 0) {
            for (let ghost of this.trail) {
                if (dist(ghost, this) < 12) continue;
                ctx.wrap(() => {
                    ctx.globalAlpha = 0.18 * (1 - (this.age - ghost.a) / 0.18);
                    ctx.fillStyle = '#8cf';
                    ctx.beginPath();
                    ctx.ellipse(ghost.x, ghost.y - 32, 12, 34, 0, 0, TWO_PI);
                    ctx.fill();
                });
            }
        }

        super.render();
    }

    renderBody(renderAge) {
        // Whirlwind spin
        if (this.spin) {
            ctx.translate(0, -30);
            ctx.rotate(this.spin);
            ctx.translate(0, 30);
        }

        let { upgraded } = this;

        // Rigged 3D swordsman: composited from a WebGL canvas, posed procedurally.
        if (this.model3d && w.__S3D && w.__S3D.ready) {
            // The engine draws a skewed shadow pass; skewing a 3D render looks broken.
            if (ctx.isShadow) return;
            let yaw = angleBetween(this, this.controls.aim);
            let sx = cos(yaw);
            let facing = sign(sx) || 1;

            ctx.wrap(() => {
                // Undo the engine's pseudo-3D squash: the model turns for real.
                ctx.scale(1 / (facing * max(0.42, abs(sx))), 1 / (1 + abs(sin(yaw)) * 0.05));
                ctx.rotate(sin(yaw) * 0.1 * facing);

                let state = this.stateMachine.state;
                w.__S3D.update({
                    'yaw': yaw + PI / 2,
                    'moving': this.controls.force ? 1 : 0,
                    'sprint': this.sprinting ? 1 : 0,
                    'strikeT': this.strikeT === undefined ? 1 : this.strikeT,
                    'pose': this.strikeStyle || 0,
                    'crouch': (this.crouch || 0) + (state.shielded ? 5 : 0),
                    't': renderAge === undefined ? this.age : renderAge,
                    'dead': this.health > 0 ? 0 : 1,
                    'gun': this.gun ? 1 : 0,
                    'act': this.testPose || 0,
                    'actT': this.testT === undefined ? 1 : this.testT,
                });

                let g = w.__S3D.geometry(78 * (upgraded ? 1.08 : 1));
                if (this.age - this.lastDamage < 0.1) ctx.globalAlpha = 0.85;
                ctx.drawImage(w.__S3D.canvas, g.x, g.y, g.w, g.h);
            });

            ctx.renderExhaustion(this, -84);
            return;
        }

        ctx.renderFighter(this, {
            'suit': upgraded ? '#121a26' : '#1b1f26',
            'accent': upgraded ? '#2c3a4d' : '#2a2f38',
            'skin': upgraded ? '#fd6' : '#fec',
            'mask': upgraded ? '#121a26' : '#1b1f26',
            'weapon': this.gun ? 'gun' : 'katana',
            'scarf': 1,
        });
    }


}

class PlayerController extends CharacterController {
    // get description() {
    //     return 'Player';
    // }

    cycle() {
        let x = 0, y = 0;
        if (DOWN[37] || DOWN[65]) x = -1;
        if (DOWN[38] || DOWN[87]) y = -1;
        if (DOWN[39] || DOWN[68]) x = 1;
        if (DOWN[40] || DOWN[83]) y = 1;

        let camera = firstItem(this.entity.scene.category('camera'));

        if (x || y) this.entity.controls.angle = atan2(y, x);
        this.entity.controls.force = x || y ? 1 : 0;
        this.entity.controls.shield = DOWN[16] || MOUSE_RIGHT_DOWN || TOUCH_SHIELD_BUTTON.down;
        this.entity.controls.attack = MOUSE_DOWN || TOUCH_ATTACK_BUTTON.down;
        this.entity.controls.dash = DOWN[32] || DOWN[17] || TOUCH_DASH_BUTTON.down;
        this.entity.controls.whirlwind = DOWN[81] || TOUCH_WHIRL_BUTTON.down;
        this.entity.controls.slam = DOWN[70] || TOUCH_SLAM_BUTTON.down;
        this.entity.controls.shadow = DOWN[69] || TOUCH_SHADOW_BUTTON.down;
        this.entity.controls.sprint = DOWN[90] || TOUCH_SPRINT_BUTTON.down;

        if (DOWN[71] && !this.gunKeyDown) this.entity.toggleWeapon();
        this.gunKeyDown = DOWN[71];


        let mouseRelX = (MOUSE_POSITION.x - 1280 / 2) / (1280 / 2);
        let mouseRelY = (MOUSE_POSITION.y - 720 / 2) / (720 / 2);

        this.entity.controls.aim.x = this.entity.x + mouseRelX * 1280 / 2 / camera.appliedZoom;
        this.entity.controls.aim.y = this.entity.y + mouseRelY * 720 / 2 / camera.appliedZoom;

        if (inputMode == 1) {
            let { touch } = TOUCH_JOYSTICK;
            this.entity.controls.aim.x = this.entity.x + (touch.x - TOUCH_JOYSTICK.x);
            this.entity.controls.aim.y = this.entity.y + (touch.y - TOUCH_JOYSTICK.y);

            this.entity.controls.angle = angleBetween(TOUCH_JOYSTICK, touch);
            this.entity.controls.force = TOUCH_JOYSTICK.touchIdentifier < 0
                ? 0
                : min(1, dist(touch, TOUCH_JOYSTICK) / 50);

            // A second finger anywhere on the right steers the camera view and
            // walks the character wherever it points.
            if (TOUCH_LOOK.touchIdentifier >= 0) {
                let look = TOUCH_LOOK.touch;
                let angle = angleBetween(TOUCH_LOOK, look);
                let force = min(1, dist(look, TOUCH_LOOK) / 50);
                this.entity.controls.aim.x = this.entity.x + (look.x - TOUCH_LOOK.x) * 2;
                this.entity.controls.aim.y = this.entity.y + (look.y - TOUCH_LOOK.y) * 2;
                if (force > 0.15) {
                    this.entity.controls.angle = angle;
                    this.entity.controls.force = force;
                }
            }
        }


        if (x) this.entity.facing = x;
    }
}


// ---- entities/characters/enemy.js ----
class Enemy extends Character {

    constructor() {
        super();
        this.categories.push('enemy');
        this.targetTeam = 'player';
    }

    remove() {
        super.remove();

        // Cancel any remaining aggression
        firstItem(this.scene.category('aggressivity-tracker'))
            .cancelAggression(this);
    }

    die() {
        super.die();

        for (let player of this.scene.category('player')) {
            player.score += ~~(100 * this.aggression * player.combo);
        }
    }

    damage(amount) {
        super.damage(amount);
        sound(...[1.6,,278,,.01,.01,2,.7,-7.1,,,,.07,1,,,.09,.81,.08]);
    }
}

createEnemyAI = ({
    shield, 
    attackCount,
}) => {
    class EnemyTypeAI extends EnemyAI {
        async doStart() {
            while (true) {
                if (PEACEFUL) {
                    await this.startAI(new Stroll());
                    continue;
                }

                // Try to be near the player
                await this.startAI(new ReachPlayer(300, 300));
                
                // Wait for our turn to attack
                try {
                    await this.race([
                        new Timeout(3),
                        new BecomeAggressive(),
                    ]);
                } catch (e) {
                    // We failed to become aggressive, start a new loop
                    continue;
                }

                await this.startAI(new BecomeAggressive());

                // Okay we're allowed to be aggro, let's do it!
                let failedToAttack;
                try {
                    await this.race([
                        new Timeout(500 / this.entity.baseSpeed),
                        new ReachPlayer(this.entity.strikeRadiusX, this.entity.strikeRadiusY),
                    ]);

                    for (let i = attackCount ; i-- ; ) {
                        await this.startAI(new Attack(0.5));
                    }
                    await this.startAI(new Wait(0.5));
                } catch (e) {
                    failedToAttack = true;
                }

                // We're done attacking, let's allow someone else to be aggro
                await this.startAI(new BecomePassive());

                // Retreat a bit so we're not too close to the player
                let dash = !shield && !failedToAttack && random() < 0.5;
                await this.race([
                    new RetreatAI(300, 300),
                    new Wait(dash ? 0.1 : 4),
                    dash 
                        ? new Dash() 
                        : (shield ? new HoldShield() : new AI()),
                ]);
                await this.startAI(new Wait(1));

                // Rinse and repeat
            }
        }
    }

    return EnemyTypeAI;
}

createEnemyType = ({
    stick, sword, axe,
    shield, armor, superArmor,
    attackCount,
}) => {
    let ai = createEnemyAI({ shield, attackCount });

    let weight = 0
        + (!!armor * 0.2) 
        + (!!superArmor * 0.3) 
        + (!!axe * 0.1)
        + (!!(sword || shield) * 0.3);

    let protection = 0
        + (!!shield * 0.3)
        + (!!armor * 0.5)
        + (!!superArmor * 0.7);

    class EnemyType extends Enemy {
        constructor() {
            super();

            this.aggression = 1;
            if (sword) this.aggression += 1;
            if (axe) this.aggression += 2;

            this.health = this.maxHealth = ~~interpolate(100, 400, protection);
            this.strength = axe ? 35 : (sword ? 25 : 10);
            this.baseSpeed = interpolate(120, 50, weight);
    
            if (stick) this.gibs.push(() => ctx.renderStick());
            if (sword) this.gibs.push(() => ctx.renderSword());
            if (shield) this.gibs.push(() => ctx.renderShield());
            if (axe) this.gibs.push(() => ctx.renderAxe());
    
            this.stateMachine = characterStateMachine({
                entity: this, 
                chargeTime: 0.5,
                staggerTime: interpolate(0.3, 0.1, protection),
            });
        }

        get ai() {
            return new ai(this);
        }
    
        renderBody() {
            ctx.renderAttackIndicator(this);
            ctx.renderLegs(this, '#666');
            ctx.renderArm(this, armor || superArmor ? '#666' : '#fec', () => {
                if (stick) ctx.renderStick(this)
                if (sword) ctx.renderSword(this);
                if (axe) ctx.renderAxe(this);
            });
            ctx.renderChest(
                this, 
                armor 
                    ? '#ccc' 
                    : (superArmor ? '#444' : '#fec'), 
                22,
            );

            ctx.renderHead(
                this, 
                superArmor ? '#666' : '#fec', 
                superArmor ? '#000' : '#fec',
            );

            if (shield) ctx.renderArmAndShield(this, armor || superArmor ? '#666' : '#fec');
            ctx.renderExhaustion(this, -70);
            ctx.renderExclamation(this);
        }
    }

    return EnemyType;
};

shield = { shield: true };
sword = { sword: true, attackCount: 2 };
stick = { stick: true, attackCount: 3 };
axe = { axe: true, attackCount: 1 };
armor = { armor: true };
superArmor = { superArmor: true };

ENEMY_TYPES = [
    // Weapon
    StickEnemy = createEnemyType({ ...stick, }),
    AxeEnemy = createEnemyType({ ...axe, }),
    SwordEnemy = createEnemyType({ ...sword, }),

    // Weapon + armor
    SwordArmorEnemy = createEnemyType({ ...sword, ...armor, }),
    AxeArmorEnemy = createEnemyType({ ...axe, ...armor, }),

    // Weapon + armor + shield
    AxeShieldArmorEnemy = createEnemyType({ ...axe, ...shield, ...armor, }),
    SwordShieldArmorEnemy = createEnemyType({ ...sword, ...shield, ...armor, }),

    // Tank
    SwordShieldTankEnemy = createEnemyType({ ...sword,  ...shield, ...superArmor, }),
    AxeShieldTankEnemy = createEnemyType({ ...axe,  ...shield, ...superArmor, }),
];

WAVE_SETTINGS = [
    ENEMY_TYPES.slice(0, 3),
    ENEMY_TYPES.slice(0, 4),
    ENEMY_TYPES.slice(0, 5),
    ENEMY_TYPES.slice(0, 7),
    ENEMY_TYPES,
];


// ---- entities/characters/dummy-enemy.js ----
class DummyEnemy extends Enemy {
    constructor() {
        super();
        this.categories.push('enemy');

        this.health = 9999;
    }

    renderBody() {
        ctx.wrap(() => {
            ctx.fillStyle = ctx.resolveColor('#634');
            ctx.fillRect(-2, 0, 4, -20);
        });
        ctx.renderChest(this, '#634', 22);
        ctx.renderHead(this, '#634');
    }

    dash() {}
}


// ---- entities/characters/king-enemy.js ----
class KingEnemy extends Enemy {
    constructor() {
        super();

        this.gibs = [
            () => ctx.renderSword(),
            () => ctx.renderShield(),
        ];

        this.health = this.maxHealth = 600;
        this.strength = 40;
        this.baseSpeed = 100;

        this.stateMachine = characterStateMachine({
            entity: this, 
            chargeTime: 0.5,
            staggerTime: 0.2,
        });
    }

    renderBody() {
        ctx.renderAttackIndicator(this);
        ctx.renderLegs(this, '#400');
        ctx.renderArm(this, '#400', () => ctx.renderSword());
        ctx.renderHead(this, '#fec');
        ctx.renderCrown(this);
        ctx.renderChest(this, '#900', 25);
        ctx.renderArmAndShield(this, '#400');
        ctx.renderExhaustion(this, -70);
        ctx.renderExclamation(this);
    }
}


// ---- entities/characters/frost-enemy.js ----
// Act II enemies: frost-hardened northern troops. Built on the Act I roster
// so behaviour stays familiar, but tougher, faster and icy-looking.
FROST_PALETTE = {
    '#fec': '#cdd',
    '#753': '#245',
    '#666': '#456',
    '#ccc': '#9bd',
    '#444': '#123',
    '#a65': '#654',
    'green': '#8ad',
};

createFrostEnemyType = (options) => {
    let Base = createEnemyType(options);

    class FrostEnemyType extends Base {
        constructor() {
            super();

            this.health = this.maxHealth = ~~(this.maxHealth * 1.6);
            this.strength += 12;
            this.baseSpeed *= 1.25;
            this.aggression += 1;
            this.damageLabelColor = '#0ef';
        }

        getColor(color) {
            return super.getColor(FROST_PALETTE[color] || color);
        }

        renderBody(renderAge) {
            super.renderBody(renderAge);

            // Frost plume on the helmet
            ctx.wrap(() => {
                ctx.fillStyle = ctx.resolveColor('#0ef');
                ctx.translate(0, -62);
                ctx.rotate(sin((renderAge || this.age) * 3) * PI / 32);
                ctx.beginPath();
                ctx.moveTo(-3, 0);
                ctx.lineTo(0, -16);
                ctx.lineTo(3, 0);
                ctx.fill();
            });
        }

        die() {
            // Shatters into an icy burst
            let burst = this.scene.add(new Shockwave('#0ef', 160, 0.4));
            burst.x = this.x;
            burst.y = this.y - 20;

            for (let i = 0 ; i < 24 ; i++) {
                let x = this.x + rnd(-20, 20);
                let y = this.y - 30 + rnd(-20, 20);
                this.scene.add(new Particle(
                    '#0ef',
                    [rnd(3, 6), 0],
                    [x, x + rnd(-50, 50)],
                    [y, y + rnd(-50, 50)],
                    rnd(0.3, 0.6),
                ));
            }

            super.die();
        }
    }

    return FrostEnemyType;
};

FROST_ENEMY_TYPES = [
    FrostStickEnemy = createFrostEnemyType({ ...stick, }),
    FrostAxeEnemy = createFrostEnemyType({ ...axe, }),
    FrostSwordEnemy = createFrostEnemyType({ ...sword, }),
    FrostSwordArmorEnemy = createFrostEnemyType({ ...sword, ...armor, }),
    FrostAxeArmorEnemy = createFrostEnemyType({ ...axe, ...armor, }),
    FrostAxeShieldArmorEnemy = createFrostEnemyType({ ...axe, ...shield, ...armor, }),
    FrostSwordShieldArmorEnemy = createFrostEnemyType({ ...sword, ...shield, ...armor, }),
    FrostSwordShieldTankEnemy = createFrostEnemyType({ ...sword, ...shield, ...superArmor, }),
    FrostAxeShieldTankEnemy = createFrostEnemyType({ ...axe, ...shield, ...superArmor, }),
];

FROST_WAVE_SETTINGS = [
    FROST_ENEMY_TYPES.slice(0, 4),
    FROST_ENEMY_TYPES.slice(0, 5),
    FROST_ENEMY_TYPES.slice(0, 7),
    FROST_ENEMY_TYPES,
];


// ---- entities/characters/warlord-enemy.js ----
// Act II boss: the Frost Warlord, larger and meaner than the emperor.
class WarlordEnemy extends Enemy {
    constructor() {
        super();

        this.gibs = [
            () => ctx.renderAxe(),
            () => ctx.renderShield(),
        ];

        this.health = this.maxHealth = 1000;
        this.strength = 50;
        this.baseSpeed = 130;
        this.aggression = 4;
        this.damageLabelColor = '#0ef';

        this.strikeRadiusX = 110;
        this.strikeRadiusY = 55;

        this.stateMachine = characterStateMachine({
            entity: this,
            chargeTime: 0.4,
            staggerTime: 0.15,
        });
    }

    strike(relativeStrength) {
        super.strike(relativeStrength);

        // Every heavy blow sends out a frost wave
        if (relativeStrength > 1) {
            let wave = this.scene.add(new Shockwave('#0ef', 260, 0.5));
            wave.x = this.x;
            wave.y = this.y - 20;
            shake(8);
        }
    }

    renderBody(renderAge) {
        ctx.wrap(() => {
            ctx.scale(1.25, 1.25);

            ctx.renderAttackIndicator(this);
            ctx.renderLegs(this, '#123');
            ctx.renderArm(this, '#123', () => ctx.renderAxe());
            ctx.renderHead(this, '#456', '#0ef');

            // Horned helm
            ctx.wrap(() => {
                ctx.fillStyle = ctx.resolveColor('#dde');
                ctx.translate(0, -62);
                for (let side of [-1, 1]) {
                    ctx.beginPath();
                    ctx.moveTo(side * 5, 0);
                    ctx.lineTo(side * 18, -14);
                    ctx.lineTo(side * 8, 4);
                    ctx.fill();
                }
            });

            ctx.renderChest(this, '#245', 25 + 4);

            // Cape
            ctx.wrap(() => {
                ctx.fillStyle = ctx.resolveColor('#059');
                ctx.translate(-2, -50);
                ctx.beginPath();
                ctx.moveTo(0, 0);
                ctx.lineTo(-14 + sin((renderAge || this.age) * 4) * 4, 34);
                ctx.lineTo(6, 30);
                ctx.fill();
            });

            ctx.renderArmAndShield(this, '#123');
            ctx.renderExhaustion(this, -80);
            ctx.renderExclamation(this);
        });
    }
}


// ---- entities/characters/gangster-enemy.js ----
// Street gangs: knife thugs, gun goons, karate fighters and kombat brawlers.
class Gangster extends Enemy {
    constructor(o) {
        super();
        this.o = o;

        this.health = this.maxHealth = o.health;
        this.strength = o.strength;
        this.baseSpeed = o.speed;
        this.aggression = o.aggression;
        this.damageLabelColor = '#f66';
        this.strikeRadiusX = o.reach || 90;
        this.strikeRadiusY = (o.reach || 90) / 2;
        this.muzzle = 0;
        this.crouch = 0;

        this.gibs = o.weapon == 'gun'
            ? [() => ctx.renderPistol()]
            : (o.weapon == 'knife' ? [() => ctx.renderKnife()] : []);

        this.stateMachine = characterStateMachine({
            entity: this,
            chargeTime: 0.45,
            staggerTime: 0.22,
        });
    }

    get ai() {
        return this.o && this.o.weapon == 'gun'
            ? new GunnerAI()
            : new (createEnemyAI({ attackCount: this.o ? this.o.attackCount : 2 }))();
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        this.muzzle = max(0, this.muzzle - elapsed);
    }

    shoot() {
        let angle = angleBetween(this, firstItem(this.scene.category('player')) || this.controls.aim);
        this.muzzle = 0.12;
        this.scene.add(new Bullet(this, angle, 800, this.strength, '#fd6'));
        let flash = this.scene.add(new MuzzleFlash(this.x + cos(angle) * 22, this.y, angle));
        flash.groundY = this.y;
        sound(...[2.04, , 475, .01, .03, .06, 4, 1.9, -8.7, , , , .09, , 36, .2, .17, .67, .04]);
        shake(4);
    }

    strike(relativeStrength) {
        this.strikeStyle = ~~(random() * STRIKE_POSES.length);
        this.strikeT = 0;
        this.scene.add(new Interpolator(this, 'strikeT', 0, 1, 0.28));
        if (this.o.weapon == 'gun') return this.shoot();
        super.strike(relativeStrength);
    }

    renderBody() {
        ctx.renderAttackIndicator(this);
        ctx.renderFighter(this, this.o);
        ctx.renderExclamation(this);
    }
}

// Gunners keep their distance and pop shots at the player.
class GunnerAI extends EnemyAI {
    async doStart() {
        while (true) {
            if (PEACEFUL) {
                await this.startAI(new Stroll());
                continue;
            }

            await this.race([
                new Timeout(2.5),
                new ReachPlayer(420, 240),
            ]).catch(() => {});

            await this.startAI(new Wait(rnd(0.3, 0.9)));
            this.entity.strike(1);
            await this.startAI(new Wait(rnd(0.6, 1.4)));

            // Reposition
            await this.race([
                new RetreatAI(280, 160),
                new Wait(1.2),
            ]).catch(() => {});
        }
    }
}

createGangsterType = (o) => class extends Gangster {
    constructor() {
        super(o);
    }
};

KnifeThug = createGangsterType({
    'health': 90, 'strength': 16, 'speed': 240, 'aggression': 1, 'attackCount': 3, 'reach': 80,
    'suit': '#2b3a2f', 'accent': '#394', 'skin': '#c96', 'weapon': 'knife', 'hair': '#210',
});

BatThug = createGangsterType({
    'health': 130, 'strength': 22, 'speed': 200, 'aggression': 2, 'attackCount': 2, 'reach': 110,
    'suit': '#3a2b3a', 'accent': '#835', 'skin': '#a75', 'weapon': 'bat', 'hair': '#310',
});

Gunner = createGangsterType({
    'health': 80, 'strength': 14, 'speed': 210, 'aggression': 2, 'attackCount': 1, 'reach': 400,
    'suit': '#22262e', 'accent': '#556', 'skin': '#c96', 'weapon': 'gun', 'mask': '#333',
});

KarateFighter = createGangsterType({
    'health': 110, 'strength': 20, 'speed': 300, 'aggression': 3, 'attackCount': 4, 'reach': 75,
    'suit': '#dde', 'accent': '#fff', 'skin': '#e9b', 'weapon': 'fist', 'hair': '#111',
});

NunchakuFighter = createGangsterType({
    'health': 120, 'strength': 24, 'speed': 290, 'aggression': 3, 'attackCount': 3, 'reach': 95,
    'suit': '#1a2a3a', 'accent': '#28b', 'skin': '#d9a', 'weapon': 'chuck', 'hair': '#111',
});

KombatBrawler = createGangsterType({
    'health': 260, 'strength': 34, 'speed': 230, 'aggression': 4, 'attackCount': 2, 'reach': 120,
    'suit': '#3b1114', 'accent': '#c22', 'skin': '#b86', 'weapon': 'knife', 'mask': '#b22', 'bulk': 1.25,
});

KombatBoss = createGangsterType({
    'health': 420, 'strength': 42, 'speed': 250, 'aggression': 5, 'attackCount': 3, 'reach': 130,
    'suit': '#101820', 'accent': '#0cf', 'skin': '#9bd', 'weapon': 'bat', 'mask': '#06a', 'bulk': 1.35,
});

GANG_TYPES = [
    KnifeThug,
    BatThug,
    Gunner,
    KarateFighter,
    NunchakuFighter,
    KombatBrawler,
    KombatBoss,
];


// ---- entities/characters/character-offscreen-indicator.js ----
class CharacterOffscreenIndicator extends Entity {
    constructor(character) {
        super();
        this.character = character;
    }

    get z() { 
        return 9994; 
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        if (!this.character.health) this.remove();
    }

    doRender(camera) {
        if (
            abs(camera.x - this.character.x) < 1280 / 2 / camera.appliedZoom &&
            abs(camera.y - this.character.y) < 720 / 2 / camera.appliedZoom
        ) return;

        let x = between(
            camera.x - (1280 / 2 - 50) / camera.appliedZoom, 
            this.character.x,
            camera.x + (1280 / 2 - 50) / camera.appliedZoom,
        );
        let y = between(
            camera.y - (720 / 2 - 50) / camera.appliedZoom, 
            this.character.y,
            camera.y + (720 / 2 - 50) / camera.appliedZoom,
        );
        ctx.translate(x, y);

        ctx.beginPath();
        ctx.wrap(() => {
            ctx.shadowColor = '#000';
            ctx.shadowBlur = 5;

            ctx.fillStyle = '#f00';
            ctx.rotate(angleBetween({x, y}, this.character));
            ctx.arc(0, 0, 20, -PI / 4, PI / 4, true);
            ctx.lineTo(40, 0);
            ctx.closePath();
            ctx.fill();

            ctx.shadowBlur = 0;

            ctx.fillStyle = '#fff';
            ctx.beginPath();
            ctx.arc(0, 0, 15, 0, TWO_PI, true);
            ctx.fill();
        });
        ctx.clip();

        ctx.resolveColor = () => '#f00';
        ctx.scale(0.4, 0.4);
        ctx.translate(0, 30);
        ctx.scale(this.character.facing, 1);
        this.character.renderBody();
    }
}


// ---- entities/characters/corpse.js ----
class Corpse extends Entity {
    constructor(renderElement, sliceType) {
        super();
        this.renderElement = renderElement;
        this.sliceType = sliceType;
    }

    get z() { 
        return -9990; 
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        if (this.age > 5) this.remove();

        if (this.age < 0.5) {
            this.scene.add(new Particle(
                '#900',
                [3, 6],
                [this.x, this.x + rnd(-20, 20)],
                [this.y, this.y + rnd(-20, 20)],
                rnd(0.5, 1),
            ));
        }
    }

    doRender() {
        if (this.age > 3 && this.age % 0.25 < 0.125) return;

        ctx.translate(this.x, this.y);
        ctx.rotate(this.rotation);
        this.renderElement();
    }
}


// ---- sound/ZzFXMicro.js ----
// ZzFX - Zuper Zmall Zound Zynth - Micro Edition
// MIT License - Copyright 2019 Frank Force
// https://github.com/KilledByAPixel/ZzFX

// This is a minified build of zzfx for use in size coding projects.
// You can use zzfxV to set volume.
// Feel free to minify it further for your own needs!

// 'use strict';

///////////////////////////////////////////////////////////////////////////////

// ZzFXMicro - Zuper Zmall Zound Zynth - v1.1.8

// ==ClosureCompiler==
// @compilation_level ADVANCED_OPTIMIZATIONS
// @output_file_name ZzFXMicro.min.js
// @js_externs zzfx, zzfxG, zzfxP, zzfxV, zzfxX
// @language_out ECMASCRIPT_2019
// ==/ClosureCompiler==

let zzfx = (...z)=> zzfxP(zzfxG(...z)); // generate and play sound
let zzfxV = .3;    // volume
let zzfxR = 44100; // sample rate
let zzfxX = new AudioContext; // audio context
let zzfxP = (...samples)=>  // play samples
{
    // create buffer and source
    let buffer = zzfxX.createBuffer(samples.length, samples[0].length, zzfxR),
        source = zzfxX.createBufferSource();

    // copy samples to buffer and play
    samples.map((d,i)=> buffer.getChannelData(i).set(d));
    source.buffer = buffer;
    source.connect(zzfxX.destination);
    return source;
}
let zzfxG = // generate samples
(
    // parameters
    volume = 1, randomness = .05, frequency = 220, attack = 0, sustain = 0,
    release = .1, shape = 0, shapeCurve = 1, slide = 0, deltaSlide = 0,
    pitchJump = 0, pitchJumpTime = 0, repeatTime = 0, noise = 0, modulation = 0,
    bitCrush = 0, delay = 0, sustainVolume = 1, decay = 0, tremolo = 0
)=>
{
    // init parameters
    let PI2 = PI*2,
    sign = v => v>0?1:-1,
    startSlide = slide *= 500 * PI2 / zzfxR / zzfxR,
    startFrequency = frequency *= (1 + randomness*2*random() - randomness)
        * PI2 / zzfxR,
    b=[], t=0, tm=0, i=0, j=1, r=0, c=0, s=0, f, length;

    // scale by sample rate
    attack = attack * zzfxR + 9; // minimum attack to prevent pop
    decay *= zzfxR;
    sustain *= zzfxR;
    release *= zzfxR;
    delay *= zzfxR;
    deltaSlide *= 500 * PI2 / zzfxR**3;
    modulation *= PI2 / zzfxR;
    pitchJump *= PI2 / zzfxR;
    pitchJumpTime *= zzfxR;
    repeatTime = repeatTime * zzfxR | 0;

    // generate waveform
    for(length = attack + decay + sustain + release + delay | 0;
        i < length; b[i++] = s)
    {
        if (!(++c%(bitCrush*100|0)))                      // bit crush
        {
            s = shape? shape>1? shape>2? shape>3?         // wave shape
                sin((t%PI2)**3) :                    // 4 noise
                max(min(tan(t),1),-1):     // 3 tan
                1-(2*t/PI2%2+2)%2:                        // 2 saw
                1-4*abs(round(t/PI2)-t/PI2):    // 1 triangle
                sin(t);                              // 0 sin

            s = (repeatTime ?
                    1 - tremolo + tremolo*sin(PI2*i/repeatTime) // tremolo
                    : 1) *
                sign(s)*(abs(s)**shapeCurve) *       // curve 0=square, 2=pointy
                volume * zzfxV * (                        // envelope
                i < attack ? i/attack :                   // attack
                i < attack + decay ?                      // decay
                1-((i-attack)/decay)*(1-sustainVolume) :  // decay falloff
                i < attack  + decay + sustain ?           // sustain
                sustainVolume :                           // sustain volume
                i < length - delay ?                      // release
                (length - i - delay)/release *            // release falloff
                sustainVolume :                           // release volume
                0);                                       // post release

            s = delay ? s/2 + (delay > i ? 0 :            // delay
                (i<length-delay? 1 : (length-i)/delay) *  // release delay
                b[i-delay|0]/2) : s;                      // sample delay
        }

        f = (frequency += slide += deltaSlide) *          // frequency
            cos(modulation*tm++);                    // modulation
        t += f - f*noise*(1 - (sin(i)+1)*1e9%2);     // noise

        if (j && ++j > pitchJumpTime)       // pitch jump
        {
            frequency += pitchJump;         // apply pitch jump
            startFrequency += pitchJump;    // also apply to start
            j = 0;                          // reset pitch jump time
        }

        if (repeatTime && !(++r % repeatTime)) // repeat
        {
            frequency = startFrequency;     // reset frequency
            slide = startSlide;             // reset slide
            j = j || 1;                     // reset pitch jump time
        }
    }

    return b;
}

sound = (...def) => zzfx(...def).start();


// ---- sound/sonantx.js ----
//
// Sonant-X
//
// Copyright (c) 2014 Nicolas Vanhoren
//
// Sonant-X is a fork of js-sonant by Marcus Geelnard and Jake Taylor. It is
// still published using the same license (zlib license, see below).
//
// Copyright (c) 2011 Marcus Geelnard
// Copyright (c) 2008-2009 Jake Taylor
//
// This software is provided 'as-is', without any express or implied
// warranty. In no event will the authors be held liable for any damages
// arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgment in the product documentation would be
//    appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such, and must not be
//    misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source
//    distribution.


let WAVE_SPS = 44100;                    // Samples per second
let WAVE_CHAN = 2;                       // Channels
let MAX_TIME = 33; // maximum time, in millis, that the generator can use consecutively

let audioCtx;

// Oscillators
function osc_sin(value)
{
    return sin(value * 6.283184);
}

function osc_square(value) {
    return osc_sin(value) < 0 ? -1 : 1;
}

function osc_saw(value)
{
    return (value % 1) - 0.5;
}

function osc_tri(value)
{
    let v2 = (value % 1) * 4;
    return v2 < 2 ? v2 - 1 : 3 - v2;
}

// Array of oscillator functions
let oscillators = [
    osc_sin,
    osc_square,
    osc_saw,
    osc_tri
];

function getnotefreq(n)
{
    return 0.00390625 * pow(1.059463094, n - 128);
}

function genBuffer(waveSize, callBack) {
    setTimeout(() => {
        // Create the channel work buffer
        var buf = new Uint8Array(waveSize * WAVE_CHAN * 2);
        var b = buf.length - 2;
        var iterate = () => {
            var begin = new Date();
            var count = 0;
            while(b >= 0)
            {
                buf[b] = 0;
                buf[b + 1] = 128;
                b -= 2;
                count += 1;
                if (count % 1000 === 0 && (new Date() - begin) > MAX_TIME) {
                    setTimeout(iterate, 0);
                    return;
                }
            }
            setTimeout(() => callBack(buf), 0);
        };
        setTimeout(iterate, 0);
    }, 0);
}

function applyDelay(chnBuf, waveSamples, instr, rowLen, callBack) {
    let p1 = (instr.fx_delay_time * rowLen) >> 1;
    let t1 = instr.fx_delay_amt / 255;

    let n1 = 0;
    let iterate = () => {
        let beginning = new Date();
        let count = 0;
        while (n1 < waveSamples - p1) {
            var b1 = 4 * n1;
            var l = 4 * (n1 + p1);

            // Left channel = left + right[-p1] * t1
            var x1 = chnBuf[l] + (chnBuf[l+1] << 8) +
                (chnBuf[b1+2] + (chnBuf[b1+3] << 8) - 32768) * t1;
            chnBuf[l] = x1 & 255;
            chnBuf[l+1] = (x1 >> 8) & 255;

            // Right channel = right + left[-p1] * t1
            x1 = chnBuf[l+2] + (chnBuf[l+3] << 8) +
                (chnBuf[b1] + (chnBuf[b1+1] << 8) - 32768) * t1;
            chnBuf[l+2] = x1 & 255;
            chnBuf[l+3] = (x1 >> 8) & 255;
            ++n1;
            count += 1;
            if (count % 1000 === 0 && (new Date() - beginning) > MAX_TIME) {
                setTimeout(iterate, 0);
                return;
            }
        }
        setTimeout(callBack, 0);
    };
    setTimeout(iterate, 0);
}

class AudioGenerator {

    constructor(mixBuf) {
        this.mixBuf = mixBuf;
        this.waveSize = mixBuf.length / WAVE_CHAN / 2;
    }

    getWave() {
        let mixBuf = this.mixBuf;
        let waveSize = this.waveSize;
        // Local variables
        let b, k, x, wave, l1, l2, y;

        // Turn critical object properties into local variables (performance)
        let waveBytes = waveSize * WAVE_CHAN * 2;

        // Convert to a WAVE file (in a binary string)
        l1 = waveBytes - 8;
        l2 = l1 - 36;
        wave = String.fromCharCode(82,73,70,70,
                                   l1 & 255,(l1 >> 8) & 255,(l1 >> 16) & 255,(l1 >> 24) & 255,
                                   87,65,86,69,102,109,116,32,16,0,0,0,1,0,2,0,
                                   68,172,0,0,16,177,2,0,4,0,16,0,100,97,116,97,
                                   l2 & 255,(l2 >> 8) & 255,(l2 >> 16) & 255,(l2 >> 24) & 255);
        b = 0;
        while (b < waveBytes) {
            // This is a GC & speed trick: don't add one char at a time - batch up
            // larger partial strings
            x = "";
            for (k = 0; k < 256 && b < waveBytes; ++k, b += 2)
            {
                // Note: We amplify and clamp here
                y = 4 * (mixBuf[b] + (mixBuf[b+1] << 8) - 32768);
                y = y < -32768 ? -32768 : (y > 32767 ? 32767 : y);
                x += String.fromCharCode(y & 255, (y >> 8) & 255);
            }
            wave += x;
        }
        return wave;
    }

    getAudioBuffer(callBack) {
        if (!audioCtx) {
            audioCtx = new AudioContext();
        }

        let mixBuf = this.mixBuf;
        let waveSize = this.waveSize;

        let buffer = audioCtx.createBuffer(WAVE_CHAN, this.waveSize, WAVE_SPS); // Create Mono Source Buffer from Raw Binary
        let lchan = buffer.getChannelData(0);
        let rchan = buffer.getChannelData(1);
        let b = 0;
        let iterate = () => {
            var beginning = new Date();
            var count = 0;
            while (b < waveSize) {
                var y = 4 * (mixBuf[b * 4] + (mixBuf[(b * 4) + 1] << 8) - 32768);
                y = y < -32768 ? -32768 : (y > 32767 ? 32767 : y);
                lchan[b] = y / 32768;
                y = 4 * (mixBuf[(b * 4) + 2] + (mixBuf[(b * 4) + 3] << 8) - 32768);
                y = y < -32768 ? -32768 : (y > 32767 ? 32767 : y);
                rchan[b] = y / 32768;
                b += 1;
                count += 1;
                if (count % 1000 === 0 && new Date() - beginning > MAX_TIME) {
                    setTimeout(iterate, 0);
                    return;
                }
            }
            setTimeout(() => callBack(buffer), 0);
        };
        setTimeout(iterate, 0);
    }
}

class SoundGenerator {

    constructor(instr, rowLen) {
        this.instr = instr;
        this.rowLen = rowLen || 5605;

        this.osc_lfo = oscillators[instr.lfo_waveform];
        this.osc1 = oscillators[instr.osc1_waveform];
        this.osc2 = oscillators[instr.osc2_waveform];
        this.attack = instr.env_attack;
        this.sustain = instr.env_sustain;
        this.release = instr.env_release;
        this.panFreq = pow(2, instr.fx_pan_freq - 8) / this.rowLen;
        this.lfoFreq = pow(2, instr.lfo_freq - 8) / this.rowLen;
    }

    genSound(n, chnBuf, currentpos) {
        var c1 = 0;
        var c2 = 0;

        // Precalculate frequencues
        var o1t = getnotefreq(n + (this.instr.osc1_oct - 8) * 12 + this.instr.osc1_det) * (1 + 0.0008 * this.instr.osc1_detune);
        var o2t = getnotefreq(n + (this.instr.osc2_oct - 8) * 12 + this.instr.osc2_det) * (1 + 0.0008 * this.instr.osc2_detune);

        // State variable init
        var q = this.instr.fx_resonance / 255;
        var low = 0;
        var band = 0;
        for (var j = this.attack + this.sustain + this.release - 1; j >= 0; --j)
        {
            let k = j + currentpos;

            // LFO
            let lfor = this.osc_lfo(k * this.lfoFreq) * this.instr.lfo_amt / 512 + 0.5;

            // Envelope
            let e = 1;
            if (j < this.attack)
                e = j / this.attack;
            else if (j >= this.attack + this.sustain)
                e -= (j - this.attack - this.sustain) / this.release;

            // Oscillator 1
            var t = o1t;
            if (this.instr.lfo_osc1_freq) t += lfor;
            if (this.instr.osc1_xenv) t *= e * e;
            c1 += t;
            var rsample = this.osc1(c1) * this.instr.osc1_vol;

            // Oscillator 2
            t = o2t;
            if (this.instr.osc2_xenv) t *= e * e;
            c2 += t;
            rsample += this.osc2(c2) * this.instr.osc2_vol;

            // Noise oscillator
            if(this.instr.noise_fader) rsample += (2*random()-1) * this.instr.noise_fader * e;

            rsample *= e / 255;

            // State variable filter
            var f = this.instr.fx_freq;
            if(this.instr.lfo_fx_freq) f *= lfor;
            f = 1.5 * sin(f * 3.141592 / WAVE_SPS);
            low += f * band;
            var high = q * (rsample - band) - low;
            band += f * high;
            switch(this.instr.fx_filter)
            {
                case 1: // Hipass
                    rsample = high;
                    break;
                case 2: // Lopass
                    rsample = low;
                    break;
                case 3: // Bandpass
                    rsample = band;
                    break;
                case 4: // Notch
                    rsample = low + high;
                    break;
                default:
            }

            // Panning & master volume
            t = osc_sin(k * this.panFreq) * this.instr.fx_pan_amt / 512 + 0.5;
            rsample *= 39 * this.instr.env_master;

            // Add to 16-bit channel buffer
            k = k * 4;
            if (k + 3 < chnBuf.length) {
                var x = chnBuf[k] + (chnBuf[k+1] << 8) + rsample * (1 - t);
                chnBuf[k] = x & 255;
                chnBuf[k+1] = (x >> 8) & 255;
                x = chnBuf[k+2] + (chnBuf[k+3] << 8) + rsample * t;
                chnBuf[k+2] = x & 255;
                chnBuf[k+3] = (x >> 8) & 255;
            }
        }
    }

    createAudioBuffer(n, callBack) {
        this.getAudioGenerator(n, ag => {
            ag.getAudioBuffer(callBack);
        });
    }

    getAudioGenerator(n, callBack) {
        var bufferSize = (this.attack + this.sustain + this.release - 1) + (32 * this.rowLen);
        var self = this;
        genBuffer(bufferSize, buffer => {
            self.genSound(n, buffer, 0);
            applyDelay(buffer, bufferSize, self.instr, self.rowLen, function() {
                callBack(new AudioGenerator(buffer));
            });
        });
    }
}

class MusicGenerator {

    constructor(song) {
        this.song = song;
        // Wave data configuration
        this.waveSize = WAVE_SPS * song.songLen; // Total song size (in samples)
    }

    generateTrack(instr, mixBuf, callBack) {
        genBuffer(this.waveSize, chnBuf => {
            // Preload/precalc some properties/expressions (for improved performance)
            var waveSamples = this.waveSize,
                waveBytes = this.waveSize * WAVE_CHAN * 2,
                rowLen = this.song.rowLen,
                endPattern = this.song.endPattern,
                soundGen = new SoundGenerator(instr, rowLen);

            let currentpos = 0;
            let p = 0;
            let row = 0;
            let recordSounds = () => {
                var beginning = new Date();
                while (true) {
                    if (row === 32) {
                        row = 0;
                        p += 1;
                        continue;
                    }
                    if (p === endPattern - 1) {
                        setTimeout(delay, 0);
                        return;
                    }
                    var cp = instr.p[p];
                    if (cp) {
                        var n = instr.c[cp - 1].n[row];
                        if (n) {
                            soundGen.genSound(n, chnBuf, currentpos);
                        }
                    }
                    currentpos += rowLen;
                    row += 1;
                    if (new Date() - beginning > MAX_TIME) {
                        setTimeout(recordSounds, 0);
                        return;
                    }
                }
            };

            let delay = () => applyDelay(chnBuf, waveSamples, instr, rowLen, finalize);

            var b2 = 0;
            let finalize = () => {
                let beginning = new Date();
                let count = 0;

                // Add to mix buffer
                while(b2 < waveBytes) {
                    var x2 = mixBuf[b2] + (mixBuf[b2+1] << 8) + chnBuf[b2] + (chnBuf[b2+1] << 8) - 32768;
                    mixBuf[b2] = x2 & 255;
                    mixBuf[b2+1] = (x2 >> 8) & 255;
                    b2 += 2;
                    count += 1;
                    if (count % 1000 === 0 && (new Date() - beginning) > MAX_TIME) {
                        setTimeout(finalize, 0);
                        return;
                    }
                }
                setTimeout(callBack, 0);
            };
            setTimeout(recordSounds, 0);
        });
    }

    getAudioGenerator(callBack) {
        genBuffer(this.waveSize, mixBuf => {
            let t = 0;
            let recu = () => {
                if (t < this.song.songData.length) {
                    t += 1;
                    this.generateTrack(this.song.songData[t - 1], mixBuf, recu);
                } else {
                    callBack(new AudioGenerator(mixBuf));
                }
            };
            recu();
        });
    }

    createAudioBuffer(callBack) {
        this.getAudioGenerator(ag => ag.getAudioBuffer(callBack));
    }
}


// ---- sound/song.js ----
ZEROES = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];

SONG = {
    "rowLen": 5513,
    "endPattern": 10,
    "songData": [
        {
            "osc1_oct": 7,
            "osc1_det": 0,
            "osc1_detune": 0,
            "osc1_xenv": 1,
            "osc1_vol": 255,
            "osc1_waveform": 0,
            "osc2_oct": 7,
            "osc2_det": 0,
            "osc2_detune": 0,
            "osc2_xenv": 1,
            "osc2_vol": 255,
            "osc2_waveform": 0,
            "noise_fader": 0,
            "env_attack": 100,
            "env_sustain": 0,
            "env_release": 3636,
            "env_master": 254,
            "fx_filter": 2,
            "fx_freq": 500,
            "fx_resonance": 254,
            "fx_delay_time": 0,
            "fx_delay_amt": 27,
            "fx_pan_freq": 0,
            "fx_pan_amt": 0,
            "lfo_osc1_freq": 0,
            "lfo_fx_freq": 0,
            "lfo_freq": 0,
            "lfo_amt": 0,
            "lfo_waveform": 0,
            "p": [
                2,
                2,
                2,
                2,
                2,
                2,
                2,
                2,
                2
            ],
            "c": [
                {
                    "n": ZEROES
                },
                {
                    "n": [
                        135,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        135,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        135,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        135,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0
                    ]
                }
            ]
        },
        {
            "osc1_oct": 8,
            "osc1_det": 0,
            "osc1_detune": 0,
            "osc1_xenv": 1,
            "osc1_vol": 221,
            "osc1_waveform": 0,
            "osc2_oct": 8,
            "osc2_det": 0,
            "osc2_detune": 0,
            "osc2_xenv": 1,
            "osc2_vol": 210,
            "osc2_waveform": 0,
            "noise_fader": 255,
            "env_attack": 50,
            "env_sustain": 150,
            "env_release": 15454,
            "env_master": 229,
            "fx_filter": 3,
            "fx_freq": 11024,
            "fx_resonance": 240,
            "fx_delay_time": 6,
            "fx_delay_amt": 24,
            "fx_pan_freq": 0,
            "fx_pan_amt": 20,
            "lfo_osc1_freq": 0,
            "lfo_fx_freq": 1,
            "lfo_freq": 7,
            "lfo_amt": 64,
            "lfo_waveform": 0,
            "p": [
                3,
                3,
                3,
                3,
                3,
                3,
                3,
                3,
                3
            ],
            "c": [
                {
                    "n": ZEROES,
                },
                {
                    "n": ZEROES
                },
                {
                    "n": [
                        0,
                        0,
                        0,
                        0,
                        134,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        134,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        134,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        134,
                        0,
                        0,
                        0
                    ]
                }
            ]
        },
        {
            "osc1_oct": 7,
            "osc1_det": 0,
            "osc1_detune": 0,
            "osc1_xenv": 0,
            "osc1_vol": 192,
            "osc1_waveform": 1,
            "osc2_oct": 6,
            "osc2_det": 0,
            "osc2_detune": 9,
            "osc2_xenv": 0,
            "osc2_vol": 192,
            "osc2_waveform": 1,
            "noise_fader": 0,
            "env_attack": 137,
            "env_sustain": 2000,
            "env_release": 4611,
            "env_master": 192,
            "fx_filter": 1,
            "fx_freq": 982,
            "fx_resonance": 89,
            "fx_delay_time": 6,
            "fx_delay_amt": 25,
            "fx_pan_freq": 6,
            "fx_pan_amt": 77,
            "lfo_osc1_freq": 0,
            "lfo_fx_freq": 1,
            "lfo_freq": 3,
            "lfo_amt": 69,
            "lfo_waveform": 0,
            "p": [
                0,
                0,
                0,
                0,
                0,
                0,
                4,
                4
            ],
            "c": [
                {
                    "n": ZEROES
                },
                {
                    "n": ZEROES
                },
                {
                    "n": ZEROES
                },
                {
                    "n": [
                        137,
                        0,
                        0,
                        144,
                        0,
                        0,
                        142,
                        0,
                        0,
                        144,
                        0,
                        0,
                        0,
                        149,
                        0,
                        0,
                        144,
                        0,
                        0,
                        142,
                        0,
                        0,
                        144,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0
                    ]
                }
            ]
        },
        {
            "osc1_oct": 7,
            "osc1_det": 0,
            "osc1_detune": 0,
            "osc1_xenv": 0,
            "osc1_vol": 255,
            "osc1_waveform": 1,
            "osc2_oct": 7,
            "osc2_det": 0,
            "osc2_detune": 9,
            "osc2_xenv": 0,
            "osc2_vol": 154,
            "osc2_waveform": 1,
            "noise_fader": 0,
            "env_attack": 197,
            "env_sustain": 88,
            "env_release": 10614,
            "env_master": 45,
            "fx_filter": 0,
            "fx_freq": 11025,
            "fx_resonance": 255,
            "fx_delay_time": 2,
            "fx_delay_amt": 146,
            "fx_pan_freq": 3,
            "fx_pan_amt": 47,
            "lfo_osc1_freq": 0,
            "lfo_fx_freq": 0,
            "lfo_freq": 0,
            "lfo_amt": 0,
            "lfo_waveform": 0,
            "p": [
                0,
                5,
                5,
                0,
                0,
                0,
                0,
                0,
                5
            ],
            "c": [
                {
                    "n": ZEROES
                },
                {
                    "n": ZEROES
                },
                {
                    "n": ZEROES
                },
                {
                    "n": ZEROES
                },
                {
                    "n": [
                        125,
                        0,
                        0,
                        132,
                        0,
                        0,
                        130,
                        0,
                        0,
                        132,
                        0,
                        0,
                        137,
                        0,
                        0,
                        132,
                        0,
                        0,
                        130,
                        0,
                        0,
                        132,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0
                    ]
                }
            ]
        },
        {
            "osc1_oct": 9,
            "osc1_det": 0,
            "osc1_detune": 0,
            "osc1_xenv": 0,
            "osc1_vol": 255,
            "osc1_waveform": 0,
            "osc2_oct": 9,
            "osc2_det": 0,
            "osc2_detune": 12,
            "osc2_xenv": 0,
            "osc2_vol": 255,
            "osc2_waveform": 0,
            "noise_fader": 0,
            "env_attack": 100,
            "env_sustain": 0,
            "env_release": 14545,
            "env_master": 70,
            "fx_filter": 0,
            "fx_freq": 0,
            "fx_resonance": 240,
            "fx_delay_time": 2,
            "fx_delay_amt": 157,
            "fx_pan_freq": 3,
            "fx_pan_amt": 47,
            "lfo_osc1_freq": 0,
            "lfo_fx_freq": 0,
            "lfo_freq": 0,
            "lfo_amt": 0,
            "lfo_waveform": 0,
            "p": [
                0,
                0,
                0,
                6,
                6
            ],
            "c": [
                {
                    "n": ZEROES
                },
                {
                    "n": ZEROES
                },
                {
                    "n": ZEROES
                },
                {
                    "n": ZEROES
                },
                {
                    "n": ZEROES
                },
                {
                    "n": [
                        137,
                        0,
                        0,
                        132,
                        0,
                        0,
                        130,
                        0,
                        0,
                        132,
                        0,
                        0,
                        137,
                        0,
                        0,
                        132,
                        0,
                        0,
                        130,
                        0,
                        0,
                        132,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0
                    ]
                }
            ]
        }
    ],
    "songLen": 31
}

playSong = () => new MusicGenerator(SONG).createAudioBuffer(buffer => {
    let source = audioCtx.createBufferSource();
    source.buffer = buffer;
    source.loop = true;

    let gainNode = audioCtx.createGain();
    gainNode.gain.value = 0.5;
    gainNode.connect(audioCtx.destination);
    source.connect(gainNode);
    source.start();

    playSong = () => 0;
    setSongVolume = (x) => gainNode.gain.value = x;
});

setSongVolume = () => 0;


// ---- level/level.js ----
class Level {
    constructor(options = {}) {
        this.scene = new Scene();

        WINTER = 0;

        this.scene.add(new Camera());

        DOWN = {};
        MOUSE_DOWN = MOUSE_RIGHT_DOWN = false;

        this.scene.add(new AggressivityTracker());

        let player = this.scene.add(new Player());
        this.scene.add(new Cursor(player));

        this.scene.add(new PauseOverlay());
        this.scene.add(new OptionsOverlay());
    }

    cycle(elapsed) {
        this.scene.cycle(elapsed);
    }

    async respawn(x, y) {
        let fade = this.scene.add(new Fade());
        await this.scene.add(new Interpolator(fade, 'alpha', 0, 1, 1)).await();
        let player = firstItem(this.scene.category('player'));
        let camera = firstItem(this.scene.category('camera'));
        player.x = x;
        player.y = y;
        camera.cycle(999);
        await this.scene.add(new Interpolator(fade, 'alpha', 1, 0, 1)).await();
        fade.remove();
    }
}


// ---- level/arena-level.js ----
// Endless arena: bare land, the hero, and gangs closing in from every side.
class ArenaLevel extends Level {
    constructor() {
        super();

        let { scene } = this;

        let player = firstItem(scene.category('player'));
        player.x = player.y = 0;

        let camera = firstItem(scene.category('camera'));
        camera.cycle(99);

        let playerHUD = scene.add(new PlayerHUD(player));
        playerHUD.progress = playerHUD.progressGauge.displayedValue = 0;

        scene.add(new Ground());

        let spawn = () => {
            let angle = random() * TWO_PI;
            let d = rnd(320, 480);
            let types = GANG_TYPES.slice(0, min(GANG_TYPES.length, 3 + ~~(player.score / 4000)));
            let enemy = scene.add(new (pick(types))());
            enemy.x = player.x + cos(angle) * d;
            enemy.y = player.y + sin(angle) * d * 0.6;
            enemy.poof();
            scene.add(new CharacterHUD(enemy));
            scene.add(new CharacterOffscreenIndicator(enemy));
        };

        // Keep the arena populated according to the chosen difficulty
        (async () => {
            let fade = scene.add(new Fade());
            await scene.add(new Interpolator(fade, 'alpha', 1, 0, 1)).await();
            scene.add(new Announcement(('Fight')));

            while (!NO_ENEMIES) {
                let alive = Array.from(scene.category('enemy')).filter(e => e.health > 0).length;
                if (alive < ENEMY_COUNT) spawn();
                await scene.delay(alive < ENEMY_COUNT ? 0.6 : 1.5);
            }
        })();

        // Game over: restart the arena
        (async () => {
            await scene.waitFor(() => player.health <= 0);

            let fade = scene.add(new Fade());
            await scene.add(new Interpolator(fade, 'alpha', 0, 1, 2)).await();
            level = new ArenaLevel();
        })();
    }
}


// ---- util/resizer.js ----
onresize = () => {
    let windowWidth = innerWidth,
        windowHeight = innerHeight,

        availableRatio = windowWidth / windowHeight, // available ratio
        canvasRatio = 1280 / 720, // base ratio
        appliedWidth,
        appliedHeight,
        containerStyle = (t).style;

    if (availableRatio <= canvasRatio) {
        appliedWidth = windowWidth;
        appliedHeight = appliedWidth / canvasRatio;
    } else {
        appliedHeight = windowHeight;
        appliedWidth = appliedHeight * canvasRatio;
    }

    containerStyle.width = appliedWidth + 'px';
    containerStyle.height = appliedHeight + 'px';
};


// ---- util/first-item.js ----
firstItem = (iterable) => {
    for (let item of iterable) {
        return item;
    }
}


// ---- util/rng.js ----
class RNG {
    constructor() {
        this.index = 0;
        this.elements = Array.apply(null, Array(50)).map(() => random());
    }

    next(min = 0, max = 1) {
        return this.elements[this.index++ % this.elements.length] * (max - min) + min;
    }

    reset() {
        this.index = 0;
    }
}


// ---- util/regen-entity.js ----
regenEntity = (entity, radiusX, radiusY, pathMinDist = 50) => {
    let camera = firstItem(entity.scene.category('camera'));
    let regen = false;
    while (entity.x < camera.x - radiusX) {
        entity.x += radiusX * 2;
        regen = true;
    } 
    
    while (entity.x > camera.x + radiusX) {
        entity.x -= radiusX * 2;
        regen = true;
    }

    while (entity.y < camera.y - radiusY) {
        entity.y += radiusX * 2;
    } 
    
    while (entity.y > camera.y + radiusY) {
        entity.y -= radiusX * 2;
    }

    while (regen) {
        entity.y = entity.scene.pathCurve(entity.x) + rnd(pathMinDist, 500) * pick([-1, 1]);
        let distToPath = abs(entity.y - entity.scene.pathCurve(entity.x));
        regen = distToPath < pathMinDist || entity.inWater;
    }
};


// ---- scene.js ----

class Scene {
    constructor() {
        this.entities = new Set();
        this.categories = new Map();
        this.sortedEntities = [];

        this.speedRatio = 1;
        this.onCycle = new Set();
    }

    add(entity) {
        if (this.entities.has(entity)) return;
        this.entities.add(entity);
        entity.scene = this;

        this.sortedEntities.push(entity);

        for (let category of entity.categories) {
            if (!this.categories.has(category)) {
                this.categories.set(category, new Set([entity]));
            } else {
                this.categories.get(category).add(entity);
            }
        }

        return entity;
    }

    category(category) {
        return this.categories.get(category) || [];
    }

    remove(entity) {
        this.entities.delete(entity);

        for (let category of entity.categories) {
            if (this.categories.has(category)) {
                this.categories.get(category).delete(entity);
            }
        }

        let index = this.sortedEntities.indexOf(entity);
        if (index >= 0) this.sortedEntities.splice(index, 1);
    }

    cycle(elapsed) {
        if (0 && DOWN[70]) elapsed *= 3;
        if (0 && DOWN[71]) elapsed *= 0.1;
        if (GAME_PAUSED) return;

        for (let entity of this.entities) {
            entity.cycle(elapsed * (entity.affectedBySpeedRatio ? this.speedRatio : 1));
        }

        for (let onCycle of this.onCycle) {
            onCycle();
        }
    }

    pathCurve(x) {
        let main = sin(x * TWO_PI / 2000) * 200;
        let wiggle = sin(x * TWO_PI / 1000) * 100;
        return main + wiggle;
    }

    render() {
        let camera = firstItem(this.category('camera'));

        // Background
        ctx.fillStyle = WINTER ? '#8ab' : '#996';
        ctx.fillRect(0, 0, 1280, 720);

        // Thunder
        if (OPT_WEATHER && camera.age % 10 < 0.3 && camera.age % 0.2 < 0.1) {
            ctx.wrap(() => {
                ctx.globalAlpha = 0.3;
                ctx.fillStyle = '#fff';
                ctx.fillRect(0, 0, 1280, 720);
            });
        }
        
        ctx.wrap(() => {
            if (SHAKE > 0.1) ctx.translate(rnd(-SHAKE, SHAKE), rnd(-SHAKE, SHAKE));

            ctx.scale(camera.appliedZoom, camera.appliedZoom);
            ctx.translate(
                1280 / 2 / camera.appliedZoom - camera.x, 
                720 / 2 / camera.appliedZoom - camera.y,
            );

            this.sortedEntities.sort((a, b) => a.z - b.z);

            for (let entity of this.sortedEntities) {
                ctx.wrap(() => entity.render());
            }
        });
    }

    async waitFor(condition) {
        return new Promise((resolve) => {
            let checker = () => {
                if (condition()) {
                    this.onCycle.delete(checker);
                    resolve();
                }
            };
            this.onCycle.add(checker);
        })
    }

    async delay(timeout) {
        let entity = this.add(new Entity());
        await this.waitFor(() => entity.age > timeout);
        entity.remove();
    }
}


// ---- index.js ----
onload = () => {
    can = document.querySelector(('canvas'));
    // Mobile: render slightly under native to keep 60fps without visible softness.
    RENDER_SCALE = MOBILE ? 0.75 : 1;
    can.width = 1280 * RENDER_SCALE;
    can.height = 720 * RENDER_SCALE;

    ctx = can.getContext('2d', {'alpha': false});
    ctx.scale(RENDER_SCALE, RENDER_SCALE);

    // if (inputMode == 1) {
    //     can.width *= 0.5;
    //     can.height *= 0.5;
    //     ctx.scale(0.5, 0.5);
    // }

    onresize();

    if (0) {
        oncontextmenu = () => {};
        ctx.wrap(() => {
            can.width *= 10;
            can.height *= 10;
            ctx.scale(10, 10);

            ctx.translate(1280 / 2, 720 / 2)
            ctx.scale(5, 5);
            ctx.translate(0, 30);
            new Player().renderBody();
        });
        return;
    }

    frame();
};

let lastFrame = performance.now();

let level = new ArenaLevel();

frame = () => {
    let current = performance.now();
    let elapsed = (current - lastFrame) / 1000;
    lastFrame = current;

    // Game update
    if (!0) level.cycle(elapsed);

    // Rendering
    ctx.wrap(() => level.scene.render());

    if (0 && !0) {
        ctx.fillStyle = '#fff';
        ctx.strokeStyle = '#000';
        ctx.textAlign = ('left');
        ctx.textBaseline = ('bottom');
        ctx.font = ('14pt Courier');
        ctx.lineWidth = 3;

        let y = 720 - 10;
        for (let line of [
            ('FPS: ') + ~~(1 / elapsed),
            ('Entities: ') + level.scene.entities.size,
        ].reverse()) {
            ctx.strokeText(line, 10, y);
            ctx.fillText(line, 10, y);
            y -= 20;
        }
    }

    requestAnimationFrame(frame);
}

window.__game = {
    get scene() { return level.scene },
    get level() { return level },
    set level(v) { level = v },
    get player() { return firstItem(level.scene.category('player')) },
    get winter() { return WINTER },
    ArenaLevel,
};
