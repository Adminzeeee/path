// Builds the canvas game (game/js/**) into a single classic script at
// public/game/game.js, replicating the js13k compiler's constant injection
// and `nomangle` / `evaluate` macros (without the minifier/mangler).
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");

let belowLayer = -9990;
let aboveLayer = 9990;

const CONSTANTS = {
  DEBUG: 0,
  LARGE_INT: 9999,

  CANVAS_WIDTH: 1280,
  CANVAS_HEIGHT: 720,

  WAVE_COUNT: 8,

  PLAYER_HEAVY_ATTACK_INDEX: 3,
  PLAYER_HEAVY_CHARGE_TIME: 1,
  PLAYER_PERFECT_PARRY_TIME: 0.15,
  PLAYER_DASH_DURATION: 0.3,
  PLAYER_DASH_DISTANCE: 200,
  PLAYER_MAGNET_RADIUS: 250,

  STRIKE_WINDUP: 0.05,
  STRIKE_DURATION: 0.15,

  MAX_AGGRESSION: 6,

  LAYER_CORPSE: belowLayer--,
  LAYER_WATER: belowLayer--,
  LAYER_PATH: belowLayer--,
  LAYER_LOWER_FADE: belowLayer--,

  LAYER_CHARACTER_HUD: aboveLayer++,
  LAYER_PARTICLE: aboveLayer++,
  LAYER_ANIMATIONS: aboveLayer++,
  LAYER_WEATHER: aboveLayer++,
  LAYER_PLAYER_HUD: aboveLayer++,
  LAYER_LOGO: aboveLayer++,
  LAYER_FADE: aboveLayer++,
  LAYER_INSTRUCTIONS: aboveLayer++,

  CHEST_WIDTH_ARMORED: 25,
  CHEST_WIDTH_NAKED: 22,

  COLOR_SKIN: "'#fec'",
  COLOR_SHIRT: "'#753'",
  COLOR_LEGS: "'#666'",
  COLOR_ARMORED_ARM: "'#666'",
  COLOR_ARMOR: "'#ccc'",
  COLOR_WOOD: "'#634'",

  DEBUG_AGGRESSIVITY: 0,
  DEBUG_CHARACTER_RADII: 0,
  DEBUG_CHARACTER_STATE: 0,
  DEBUG_CHARACTER_STATS: 0,
  DEBUG_CHARACTER_AI: 0,
  DEBUG_PLAYER_MAGNET: 0,

  RENDER_PLAYER_ICON: 0,
  RENDER_SCREENSHOT: 0,

  INPUT_MODE_MOUSE: 0,
  INPUT_MODE_TOUCH: 1,
  INPUT_MODE_GAMEPAD: 2,

  TOUCH_JOYSTICK_RADIUS: 50,
  TOUCH_JOYSTICK_MAX_RADIUS: 150,
  TOUCH_BUTTON_RADIUS: 35,

  RIPPLE_DURATION: 2,
  THUNDER_INTERVAL: 10,

  SONG_VOLUME: 0.5,

  OPTIONS_FIRST_LINE_Y: 250,
  OPTIONS_LINE_HEIGHT: 46,
};

const FILES = [
  "globals.js",
  "math.js",
  "state-machine.js",

  "graphics/create-canvas.js",
  "graphics/wrap.js",
  "graphics/with-shadow.js",
  "graphics/characters/exclamation.js",
  "graphics/characters/body.js",
  "graphics/characters/fighter.js",
  "graphics/gauge.js",
  "graphics/text.js",

  "input/keyboard.js",
  "input/mouse.js",
  "input/touch.js",

  "ai/character-controller.js",

  "entities/entity.js",
  "entities/camera.js",
  "entities/interpolator.js",
  "entities/cursor.js",
  "entities/path.js",
  "entities/aggressivity-tracker.js",

  "entities/animations/full-charge.js",
  "entities/animations/shield-block.js",
  "entities/animations/perfect-parry.js",
  "entities/animations/particle.js",
  "entities/animations/swing-effect.js",
  "entities/animations/rain.js",
  "entities/animations/bird.js",
  "entities/animations/snow.js",
  "entities/animations/shockwave.js",
  "entities/animations/ember.js",
  "entities/animations/gore.js",

  "entities/props/grass.js",
  "entities/props/obstacle.js",
  "entities/props/tree.js",
  "entities/props/bush.js",
  "entities/props/water.js",
  "entities/props/pine.js",
  "entities/props/rock.js",
  "entities/props/banner.js",
  "entities/props/ground.js",

  "entities/ui/label.js",
  "entities/ui/fade.js",
  "entities/ui/logo.js",
  "entities/ui/announcement.js",
  "entities/ui/instruction.js",
  "entities/ui/exposition.js",
  "entities/ui/pause-overlay.js",
  "entities/ui/options-overlay.js",

  "entities/characters/character-hud.js",
  "entities/characters/player-hud.js",

  "entities/characters/character.js",
  "entities/characters/player.js",
  "entities/characters/enemy.js",
  "entities/characters/dummy-enemy.js",
  "entities/characters/king-enemy.js",
  "entities/characters/frost-enemy.js",
  "entities/characters/warlord-enemy.js",
  "entities/characters/gangster-enemy.js",
  "entities/characters/character-offscreen-indicator.js",

  "entities/characters/corpse.js",

  "sound/ZzFXMicro.js",
  "sound/sonantx.js",
  "sound/song.js",

  "level/level.js",
  "level/arena-level.js",

  "util/resizer.js",
  "util/first-item.js",
  "util/rng.js",
  "util/regen-entity.js",

  "scene.js",
  "index.js",
];

let source = FILES.map((f) => {
  const path = resolve(root, "game/js", f);
  return `// ---- ${f} ----\n${readFileSync(path, "utf8")}`;
}).join("\n\n");

// Macros: nomangle(x) / evaluate(x) are compile-time no-ops here.
// Member form `obj.nomangle(prop)(...)` must collapse to `obj.prop(...)`.
source = source.replace(/\.\s*(?:nomangle|evaluate)\s*\(\s*([A-Za-z_$][\w$]*)\s*\)/g, ".$1");
source = source.replace(/\b(?:nomangle|evaluate)\s*\(/g, "(");


// The original compiler rewrites `const` to `let` (top-level redeclarations
// and reassignments in index.js depend on it).
source = source.replace(/\bconst\b/g, "let");

// Constant injection.
for (const [name, value] of Object.entries(CONSTANTS)) {
  source = source.replace(new RegExp(`\\b${name}\\b`, "g"), String(value));
}

// Small hook so the running game can be inspected / jumped around while
// developing (e.g. skipping straight to Act II).
source += `
window.__game = {
    get scene() { return level.scene },
    get level() { return level },
    set level(v) { level = v },
    get player() { return firstItem(level.scene.category('player')) },
    get winter() { return WINTER },
    ArenaLevel,
};
`;

const out = resolve(root, "public/game/game.js");
mkdirSync(dirname(out), { recursive: true });
writeFileSync(out, source);

console.log(`built ${out} (${(source.length / 1024).toFixed(1)} kB)`);
