class Snow extends Entity {
    get z() {
        return LAYER_WEATHER;
    }

    doRender(camera) {
        if (!OPT_WEATHER) return;

        this.rng.reset();

        this.cancelCameraOffset(camera);

        ctx.fillStyle = '#fff';

        for (let i = 120 ; i-- ;) {
            const seed = this.rng.next(0, 20);
            const speed = this.rng.next(60, 220);
            const drift = this.rng.next(20, 90);
            const size = this.rng.next(2, 6);

            const x = (this.rng.next(0, CANVAS_WIDTH) + sin((this.age + seed) * 2) * drift + CANVAS_WIDTH * 2) % CANVAS_WIDTH;
            const y = (speed * (this.age + seed)) % CANVAS_HEIGHT;

            ctx.globalAlpha = this.rng.next(0.35, 0.95);
            ctx.fillRect(x, y, size, size);
        }
    }
}
