class Shockwave extends Entity {
    constructor(color = '#fff', maxRadius = 220, duration = 0.5) {
        super();
        this.color = color;
        this.maxRadius = maxRadius;
        this.duration = duration;
        this.affectedBySpeedRatio = false;
    }

    get z() {
        return LAYER_ANIMATIONS;
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        if (this.age > this.duration) this.remove();
    }

    doRender() {
        const ratio = this.age / this.duration;

        ctx.translate(this.x, this.y);
        ctx.globalAlpha = 1 - ratio;

        ctx.strokeStyle = this.color;

        for (const scale of [1, 0.6]) {
            ctx.lineWidth = interpolate(16, 1, ratio) * scale;
            ctx.beginPath();
            ctx.ellipse(0, 0, this.maxRadius * ratio * scale, this.maxRadius * ratio * scale / 2, 0, 0, TWO_PI);
            ctx.stroke();
        }
    }
}
