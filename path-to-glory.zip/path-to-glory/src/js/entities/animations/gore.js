// Lingering blood decals + bigger, meatier hit/death effects.
class BloodPool extends Entity {
    constructor(x, y, size) {
        super();
        this.x = x;
        this.y = y;
        this.size = size;
        this.blobs = [];
        for (let i = 0; i < 7; i++) {
            this.blobs.push([rnd(-size, size), rnd(-size / 3, size / 3), rnd(size / 3, size)]);
        }
    }

    get z() {
        return LAYER_CORPSE;
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        if (this.age > 14) this.remove();
    }

    doRender() {
        if (!OPT_BLOOD) return;
        ctx.globalAlpha = between(0, min(1, this.age * 3) * (1 - this.age / 14), 1) * 0.7;
        ctx.fillStyle = '#5a0006';
        ctx.translate(this.x, this.y);
        const grow = min(1, this.age * 2);
        for (const [bx, by, br] of this.blobs) {
            ctx.beginPath();
            ctx.ellipse(bx * grow, by * grow, br * grow, br * grow * 0.4, 0, 0, TWO_PI);
            ctx.fill();
        }
    }
}

bloodBurst = (scene, x, y, amount, power) => {
    if (!OPT_BLOOD) return;
    for (let i = 0; i < amount; i++) {
        const angle = random() * TWO_PI;
        const d = rnd(20, 60) * power;
        scene.add(new Particle(
            pick(['#900', '#b00', '#6a0009']),
            [rnd(2, 6), 0],
            [x, x + cos(angle) * d],
            [y, y + sin(angle) * d],
            rnd(0.2, 0.55),
        ));
    }
};

class Bullet extends Entity {
    constructor(shooter, angle, speed, damage, color) {
        super();
        this.categories.push('bullet');
        this.shooter = shooter;
        this.angle = angle;
        this.speed = speed || 900;
        this.damage = damage || 18;
        this.color = color || '#fe8';
        this.x = shooter.x + cos(angle) * 20;
        this.y = shooter.y - 44 + sin(angle) * 20;
        this.groundY = shooter.y + sin(angle) * 20;
        this.targetTeam = shooter.targetTeam;
    }

    get z() {
        return LAYER_ANIMATIONS;
    }

    cycle(elapsed) {
        super.cycle(elapsed);

        const step = this.speed * elapsed;
        this.x += cos(this.angle) * step;
        this.y += sin(this.angle) * step;
        this.groundY += sin(this.angle) * step;

        for (const victim of Array.from(this.scene.category(this.targetTeam))) {
            if (victim.health <= 0) continue;
            if (abs(victim.x - this.x) < 26 && abs(victim.y - this.groundY) < 40) {
                victim.damage(this.damage);
                victim.dash(this.angle, 20, 0.1);
                bloodBurst(this.scene, this.x, this.y, 12, 1);
                vibrate(20);
                this.remove();
                return;
            }
        }

        if (this.age > 1.2) this.remove();
    }

    doRender() {
        ctx.translate(this.x, this.y);
        ctx.rotate(this.angle);
        ctx.fillStyle = this.color;
        ctx.globalAlpha = 0.9;
        ctx.fillRect(-14, -1.5, 20, 3);
    }
}

class MuzzleFlash extends Entity {
    constructor(x, y, angle) {
        super();
        this.x = x;
        this.y = y;
        this.angle = angle;
    }

    get z() {
        return LAYER_ANIMATIONS;
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        if (this.age > 0.08) this.remove();
    }

    doRender() {
        ctx.translate(this.x, this.y - 44);
        ctx.rotate(this.angle);
        ctx.fillStyle = '#ffd';
        ctx.globalAlpha = 1 - this.age / 0.08;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(30, -9);
        ctx.lineTo(38, 0);
        ctx.lineTo(30, 9);
        ctx.fill();
    }
}
