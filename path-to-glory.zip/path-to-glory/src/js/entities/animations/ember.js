// Ambient drifting motes: ash near battlefields, snow dust in the north.
class Ember extends Entity {
    constructor(color = '#fff') {
        super();
        this.color = color;
        this.regen();
    }

    get z() {
        return LAYER_WEATHER;
    }

    regen() {
        this.age = 0;
        this.seed = rnd(0, 10);

        let cameraX = 0, cameraY = 0;
        if (this.scene) {
            const camera = firstItem(this.scene.category('camera'));
            cameraX = camera.x;
            cameraY = camera.y;
        }

        this.x = rnd(cameraX - evaluate(CANVAS_WIDTH / 2), cameraX + evaluate(CANVAS_WIDTH / 2));
        this.y = cameraY + evaluate(CANVAS_HEIGHT / 2);
        this.speed = rnd(30, 90);
        this.size = rnd(2, 5);
    }

    cycle(elapsed) {
        super.cycle(elapsed);

        const camera = firstItem(this.scene.category('camera'));
        if (this.y < camera.y - evaluate(CANVAS_HEIGHT / 2 + 100)) this.regen();

        this.y -= this.speed * elapsed;
        this.x += cos((this.age + this.seed) * 2) * 30 * elapsed;
    }

    doRender() {
        if (!OPT_WEATHER) return;

        ctx.translate(this.x, this.y);
        ctx.globalAlpha = 0.3 + abs(sin((this.age + this.seed) * 3)) * 0.6;
        ctx.fillStyle = this.color;
        ctx.fillRect(0, 0, this.size, this.size);
    }
}
