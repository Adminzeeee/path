// Toggled with [O] / the OPT button. Numeric keys or taps to change.
class OptionsOverlay extends Entity {
    get z() {
        return LAYER_LOGO + 2;
    }

    doRender(camera) {
        if (!OPTIONS_OPEN) return;

        this.cancelCameraOffset(camera);

        ctx.fillStyle = 'rgba(0,0,0,.8)';
        ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

        ctx.wrap(() => {
            ctx.translate(CANVAS_WIDTH / 2, 150);
            ctx.renderLargeText([
                [nomangle('O'), 120],
                [nomangle('PTIONS'), 60, 16],
            ]);
        });

        const lines = [
            [nomangle('[1] Weather effects'), OPT_WEATHER ? nomangle('ON') : nomangle('OFF')],
            [nomangle('[2] Blood & gore'), OPT_BLOOD ? nomangle('ON') : nomangle('OFF')],
            [nomangle('[3] Screen shake'), OPT_SHAKE ? nomangle('ON') : nomangle('OFF')],
            [nomangle('[4] Slow motion'), OPT_SLOWMO ? nomangle('ON') : nomangle('OFF')],
            [nomangle('[5] Vibration'), OPT_VIBRATE ? nomangle('ON') : nomangle('OFF')],
            [nomangle('[6] Enemies at once'), '' + ENEMY_COUNT],
            [nomangle('[7] Mobile layout'), '' + (TOUCH_LAYOUT + 1)],
            [nomangle('[8] Fullscreen'), nomangle('TOGGLE')],
            [nomangle('[9] Enemies attack'), PEACEFUL ? nomangle('NO') : nomangle('YES')],
        ];

        ctx.wrap(() => {
            ctx.textAlign = nomangle('center');
            ctx.textBaseline = nomangle('middle');
            ctx.font = nomangle('22pt Times New Roman');
            ctx.strokeStyle = '#000';
            ctx.lineWidth = 4;

            let y = OPTIONS_FIRST_LINE_Y;
            for (const [label, value] of lines) {
                const text = label + ': ' + value;
                ctx.fillStyle = '#fff';
                ctx.strokeText(text, CANVAS_WIDTH / 2, y);
                ctx.fillText(text, CANVAS_WIDTH / 2, y);
                y += OPTIONS_LINE_HEIGHT;
            }
        });

        ctx.wrap(() => {
            ctx.translate(CANVAS_WIDTH / 2, CANVAS_HEIGHT - 70);
            ctx.renderInstruction(nomangle('[Q] spin [E] shadow [F] slam [Z] run [G] gun [+/-] zoom [1-3] moves'));
        });
    }
}
