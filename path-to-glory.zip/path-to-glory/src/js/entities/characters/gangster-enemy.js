// Street gangs: knife thugs, gun goons, karate fighters and kombat brawlers.
class Gangster extends Enemy {
    constructor(o) {
        super();
        this.o = o;

        this.health = this.maxHealth = o.health;
        this.strength = o.strength;
        this.baseSpeed = o.speed;
        this.aggression = o.aggression;
        this.damageLabelColor = '#f66';
        this.strikeRadiusX = o.reach || 90;
        this.strikeRadiusY = (o.reach || 90) / 2;
        this.muzzle = 0;
        this.crouch = 0;

        this.gibs = o.weapon == 'gun'
            ? [() => ctx.renderPistol()]
            : (o.weapon == 'knife' ? [() => ctx.renderKnife()] : []);

        this.stateMachine = characterStateMachine({
            entity: this,
            chargeTime: 0.45,
            staggerTime: 0.22,
        });
    }

    get ai() {
        return this.o && this.o.weapon == 'gun'
            ? new GunnerAI()
            : new (createEnemyAI({ attackCount: this.o ? this.o.attackCount : 2 }))();
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        this.muzzle = max(0, this.muzzle - elapsed);
    }

    shoot() {
        const angle = angleBetween(this, firstItem(this.scene.category('player')) || this.controls.aim);
        this.muzzle = 0.12;
        this.scene.add(new Bullet(this, angle, 800, this.strength, '#fd6'));
        const flash = this.scene.add(new MuzzleFlash(this.x + cos(angle) * 22, this.y, angle));
        flash.groundY = this.y;
        sound(...[2.04, , 475, .01, .03, .06, 4, 1.9, -8.7, , , , .09, , 36, .2, .17, .67, .04]);
        shake(4);
    }

    strike(relativeStrength) {
        this.strikeStyle = ~~(random() * STRIKE_POSES.length);
        this.strikeT = 0;
        this.scene.add(new Interpolator(this, 'strikeT', 0, 1, 0.28));
        if (this.o.weapon == 'gun') return this.shoot();
        super.strike(relativeStrength);
    }

    renderBody() {
        ctx.renderAttackIndicator(this);
        ctx.renderFighter(this, this.o);
        ctx.renderExclamation(this);
    }
}

// Gunners keep their distance and pop shots at the player.
class GunnerAI extends EnemyAI {
    async doStart() {
        while (true) {
            if (PEACEFUL) {
                await this.startAI(new Stroll());
                continue;
            }

            await this.race([
                new Timeout(2.5),
                new ReachPlayer(420, 240),
            ]).catch(() => {});

            await this.startAI(new Wait(rnd(0.3, 0.9)));
            this.entity.strike(1);
            await this.startAI(new Wait(rnd(0.6, 1.4)));

            // Reposition
            await this.race([
                new RetreatAI(280, 160),
                new Wait(1.2),
            ]).catch(() => {});
        }
    }
}

createGangsterType = (o) => class extends Gangster {
    constructor() {
        super(o);
    }
};

KnifeThug = createGangsterType({
    'health': 90, 'strength': 16, 'speed': 240, 'aggression': 1, 'attackCount': 3, 'reach': 80,
    'suit': '#2b3a2f', 'accent': '#394', 'skin': '#c96', 'weapon': 'knife', 'hair': '#210',
});

BatThug = createGangsterType({
    'health': 130, 'strength': 22, 'speed': 200, 'aggression': 2, 'attackCount': 2, 'reach': 110,
    'suit': '#3a2b3a', 'accent': '#835', 'skin': '#a75', 'weapon': 'bat', 'hair': '#310',
});

Gunner = createGangsterType({
    'health': 80, 'strength': 14, 'speed': 210, 'aggression': 2, 'attackCount': 1, 'reach': 400,
    'suit': '#22262e', 'accent': '#556', 'skin': '#c96', 'weapon': 'gun', 'mask': '#333',
});

KarateFighter = createGangsterType({
    'health': 110, 'strength': 20, 'speed': 300, 'aggression': 3, 'attackCount': 4, 'reach': 75,
    'suit': '#dde', 'accent': '#fff', 'skin': '#e9b', 'weapon': 'fist', 'hair': '#111',
});

NunchakuFighter = createGangsterType({
    'health': 120, 'strength': 24, 'speed': 290, 'aggression': 3, 'attackCount': 3, 'reach': 95,
    'suit': '#1a2a3a', 'accent': '#28b', 'skin': '#d9a', 'weapon': 'chuck', 'hair': '#111',
});

KombatBrawler = createGangsterType({
    'health': 260, 'strength': 34, 'speed': 230, 'aggression': 4, 'attackCount': 2, 'reach': 120,
    'suit': '#3b1114', 'accent': '#c22', 'skin': '#b86', 'weapon': 'knife', 'mask': '#b22', 'bulk': 1.25,
});

KombatBoss = createGangsterType({
    'health': 420, 'strength': 42, 'speed': 250, 'aggression': 5, 'attackCount': 3, 'reach': 130,
    'suit': '#101820', 'accent': '#0cf', 'skin': '#9bd', 'weapon': 'bat', 'mask': '#06a', 'bulk': 1.35,
});

GANG_TYPES = [
    KnifeThug,
    BatThug,
    Gunner,
    KarateFighter,
    NunchakuFighter,
    KombatBrawler,
    KombatBoss,
];
