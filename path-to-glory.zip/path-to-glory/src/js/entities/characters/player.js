FOV_GRADIENT = [0, 255].map(red => createCanvas(1, 1, ctx => {
    const grad = ctx.createRadialGradient(0, 0, 0, 0, 0, PLAYER_MAGNET_RADIUS);
    grad.addColorStop(0, 'rgba(' + red + ',0,0,.1)');
    grad.addColorStop(1, 'rgba(' + red + ',0,0,0)');
    return grad;
}));

class Player extends Character {
    constructor() {
        super();
        this.categories.push('player');

        this.targetTeam = 'enemy';

        this.score = 0;

        this.baseSpeed = 250;
        this.strength = 30;

        // Ninja: faster, lighter, deadlier on the counter-attack.
        this.ninja = HERO === 1;
        this.model3d = HERO >= 2;

        if (this.ninja) {
            this.baseSpeed = 330;
            this.strength = 26;
            this.staminaRecoveryDelay = 1.2;
            this.trail = [];
        }

        this.staminaRecoveryDelay = 2;

        this.magnetRadiusX = this.magnetRadiusY = PLAYER_MAGNET_RADIUS;

        this.affectedBySpeedRatio = false;

        this.damageLabelColor = '#f00';

        this.gibs = [
            () => this.ninja ? ctx.renderKatana() : ctx.renderSword(),
            () => ctx.renderShield(),
        ];

        this.stateMachine = characterStateMachine({
            entity: this, 
            chargeTime: PLAYER_HEAVY_CHARGE_TIME,
            perfectParryTime: PLAYER_PERFECT_PARRY_TIME,
            releaseAttackBetweenStrikes: true,
            staggerTime: 0.2,
        });
        // Full 360 body rotation + pose system
        this.rotate3d = 1;
        this.strikeT = 1;
        this.strikeStyle = 0;
        this.crouch = 0;
        this.gun = 0;
        this.ammo = 12;
        this.muzzle = 0;

        // Special moves
        this.whirlwindCooldown = this.slamCooldown = this.shadowCooldown = 0;

        // Rig test moves ([1] punches, [2] sword wave, [3] leg lift)
        this.testPose = 0;
        this.testT = 1;
        this.spin = 0;
        this.upgraded = 0;
    }

    get ai() {
        return new PlayerController();
    }

    // Act II hero: veteran gear, tougher, hits harder.
    upgrade() {
        this.upgraded = 1;
        this.health = this.maxHealth = this.ninja ? 130 : 160;
        this.strength = this.ninja ? 38 : 42;
        this.baseSpeed = this.ninja ? 360 : 280;
    }

    // The player's stamina bar is a testing tool here: effectively unlimited.
    loseStamina() {
        this.stamina = 1;
    }

    // Rig demo: procedurally driven moves to check what the skeleton can do.
    testMove(n) {
        this.testPose = n;
        this.testT = 0;
        const durations = [1.1, 1.3, 1.6, 0.9, 1.1, 1];
        this.scene.add(new Interpolator(this, 'testT', 0, 1, durations[n - 1] || 1));
        this.displayLabel([
            nomangle('Punch Combo'),
            nomangle('Sword Wave'),
            nomangle('Crane Stance'),
            nomangle('Front Kick'),
            nomangle('Spin Kick'),
            nomangle('Uppercut'),
        ][n - 1], '#8cf');
        shake(4);
        vibrate(15);
        sound(...[1.03,,329,.02,.09,.05,2,.56,,-0.2,,,,1.5,,1.1,,.72,.02,.3]);
    }


    toggleWeapon() {
        this.gun = !this.gun;
        this.displayLabel(this.gun ? nomangle('Pistol') : nomangle('Blade'), '#fd6');
        sound(...[1.03,,329,.02,.09,.05,2,.56,,-0.2,,,,1.5,,1.1,,.72,.02,.3]);
    }

    shoot() {
        if (this.age - (this.lastShot || -9) < 0.22) return;
        this.lastShot = this.age;
        this.muzzle = 0.12;

        const angle = angleBetween(this, this.controls.aim);
        this.scene.add(new Bullet(this, angle, 1100, ~~(this.strength * 0.8), '#ff8'));
        const flash = this.scene.add(new MuzzleFlash(this.x + cos(angle) * 24, this.y, angle));
        flash.groundY = this.y;
        this.dash(angle + PI, 12, 0.08);
        shake(6);
        vibrate(30);
        sound(...[1.99,,427,.01,,.07,,.62,6.7,-0.7,,,,.2,,,.11,.76,.05]);
    }

    // Sword strikes auto-cycle through a set of distinct attacks
    strike(relativeStrength) {
        this.strikeStyle = (this.strikeStyle + 1 + ~~(random() * 2)) % STRIKE_POSES.length;
        this.strikeT = 0;
        this.scene.add(new Interpolator(this, 'strikeT', 0, 1, 0.26));
        if (relativeStrength > 0.9) this.displayLabel(STRIKE_NAMES[this.strikeStyle], '#fff');

        if (this.gun) return this.shoot();

        vibrate(15);

        if (this.ninja) {
            const a = angleBetween(this, this.controls.aim);
            for (let i = 0 ; i < (MOBILE ? 4 : 8) ; i++) {
                const sa = a + rnd(-0.5, 0.5);
                this.scene.add(new Particle(
                    '#dff',
                    [rnd(2, 5), 0],
                    [this.x + cos(a) * 20, this.x + cos(sa) * rnd(50, 130)],
                    [this.y - 40, this.y - 40 + sin(sa) * rnd(20, 60)],
                    rnd(0.12, 0.3),
                ));
            }
        }

        super.strike(relativeStrength);
    }

    cycle(elapsed) {
        this.muzzle = max(0, this.muzzle - elapsed);
        this.crouch = this.controls.shield ? min(6, this.crouch + elapsed * 40) : max(0, this.crouch - elapsed * 40);
        this.whirlwindCooldown = max(0, this.whirlwindCooldown - elapsed);
        this.slamCooldown = max(0, this.slamCooldown - elapsed);
        this.shadowCooldown = max(0, this.shadowCooldown - elapsed);
        if (this.testPose && this.testT >= 1) this.testPose = 0;

        // Sprint: faster, but drains stamina
        const sprinting = this.controls.sprint && this.stamina > 0.05 && this.controls.force;
        this.sprinting = sprinting;
        this.speedMultiplier = sprinting ? 1.7 : 1;
        const baseSpeed = this.baseSpeed;
        this.baseSpeed *= this.speedMultiplier;

        super.cycle(elapsed);

        this.baseSpeed = baseSpeed;

        // Ninja afterimages
        if (this.ninja) {
            this.trail.push({'x': this.x, 'y': this.y, 'a': this.age, 'f': this.facing});
            while (this.trail.length && (this.age - this.trail[0].a > 0.18 || this.trail.length > (MOBILE ? 6 : 14))) this.trail.shift();
        }

        if (sprinting) {
            this.loseStamina(elapsed * 0.3);

            if (this.age % 0.1 < elapsed) {
                this.scene.add(new Particle(
                    WINTER ? '#fff' : '#cb9',
                    [6, 0],
                    [this.x, this.x + rnd(-20, 20)],
                    [this.y, this.y - rnd(5, 25)],
                    rnd(0.2, 0.5),
                ));
            }
        }

        if (this.controls.whirlwind && !this.whirlwindCooldown && this.stamina > 0.3) this.whirlwind();
        if (this.controls.slam && !this.slamCooldown && this.stamina > 0.4) this.slam();
        if (this.controls.shadow && !this.shadowCooldown && this.stamina > 0.25) this.shadowStrike();
    }

    // [Q] Spinning strike, hits everything around the hero.
    whirlwind() {
        this.whirlwindCooldown = this.ninja ? 2.5 : 4;
        this.loseStamina(0.3);
        this.displayLabel(this.ninja ? nomangle('Blade Dance!') : nomangle('Whirlwind!'), '#fff');
        shake(10);
        sound(...[1.4,,180,.02,.15,.25,1,1.8,,,,,.05,1.6,,.2,.1,.7,.05]);

        const wave = this.scene.add(new Shockwave('#fff', 240, 0.45));
        wave.x = this.x;
        wave.y = this.y - 20;

        this.scene.add(new Interpolator(this, 'spin', TWO_PI * 2, 0, 0.5));

        for (const victim of Array.from(this.scene.category('enemy'))) {
            if (victim.health <= 0 || dist(this, victim) > 200) continue;
            const angle = angleBetween(this, victim);
            victim.damage(~~(this.strength * 0.9));
            victim.dash(angle, 120, 0.2);
            this.updateCombo(1);
        }
    }

    // [F] Ground slam: wide knockback that also breaks guards.
    slam() {
        this.slamCooldown = 8;
        this.loseStamina(0.4);
        this.displayLabel(nomangle('War Slam!'), '#fb0');
        shake(20);
        sound(...[2.2,,110,.05,.2,.4,4,3,,,,,.2,1.5,,.3,.2,.5,.1]);

        const wave = this.scene.add(new Shockwave(WINTER ? '#0ef' : '#fb0', 420, 0.7));
        wave.x = this.x;
        wave.y = this.y - 10;

        for (let i = 0 ; i < 30 ; i++) {
            const angle = random() * TWO_PI;
            this.scene.add(new Particle(
                WINTER ? '#dff' : '#ba8',
                [rnd(4, 8), 0],
                [this.x, this.x + cos(angle) * rnd(40, 160)],
                [this.y, this.y + sin(angle) * rnd(20, 80)],
                rnd(0.3, 0.7),
            ));
        }

        for (const victim of Array.from(this.scene.category('enemy'))) {
            if (victim.health <= 0 || dist(this, victim) > 380) continue;
            const angle = angleBetween(this, victim);
            victim.damage(~~(this.strength * 0.6));
            victim.dash(angle, 220, 0.35);
            victim.loseStamina(1);
        }
    }


    // [E] Shadow Strike: blink onto the closest enemy and cut through them.
    shadowStrike() {
        this.shadowCooldown = this.ninja ? 3 : 5;
        this.loseStamina(0.25);

        let target, best = 520;
        for (const enemy of this.scene.category('enemy')) {
            const d = dist(this, enemy);
            if (enemy.health > 0 && d < best) best = d, target = enemy;
        }

        const angle = target ? angleBetween(this, target) : angleBetween(this, this.controls.aim);
        this.displayLabel(nomangle('Shadow Strike!'), '#8cf');
        sound(...[1.5,,660,.01,.08,.16,1,1.4,,,,,.03,1.4,,.15,.08,.6,.03]);
        shake(8);
        vibrate(25);

        // Blink past the target
        if (target) {
            const d = max(0, dist(this, target) - 40);
            this.x += cos(angle) * d;
            this.y += sin(angle) * d;
        } else {
            this.dash(angle, 260, 0.15);
        }

        for (let i = 0 ; i < 14 ; i++) {
            const a = angle + PI + rnd(-0.6, 0.6);
            this.scene.add(new Particle(
                '#8cf',
                [rnd(3, 7), 0],
                [this.x, this.x + cos(a) * rnd(30, 120)],
                [this.y, this.y + sin(a) * rnd(15, 60)],
                rnd(0.2, 0.5),
            ));
        }

        this.strike(1);
        if (target && target.health > 0) {
            target.damage(~~(this.strength * 1.4));
            target.dash(angle, 90, 0.15);
            target.loseStamina(0.6);
            this.updateCombo(1);
        }
    }

    damage(amount) {
        super.damage(amount);
        sound(...[2.07,,71,.01,.05,.03,2,.14,,,,,.01,1.5,,.1,.19,.95,.05,.16]);
    }

    getColor(color) {
        return this.age - this.lastDamage < 0.1 ? '#f00' : super.getColor(color);
    }

    heal(amount) {
        amount = ~~min(this.maxHealth - this.health, amount);
        this.health += amount

        for (let i = amount ; --i > 0 ;) {
            setTimeout(() => {
                const angle = random() * TWO_PI;
                const dist = random() * 40;

                const x = this.x + rnd(-10, 10);
                const y = this.y - 30 + sin(angle) * dist;

                this.scene.add(new Particle(
                    '#0f0',
                    [5, 10],
                    [x, x + rnd(-10, 10)],
                    [y, y + rnd(-30, -60)],
                    rnd(1, 1.5),
                ));
            }, i * 100);
        }
    }

    render() {
        const victim = this.pickVictim(this.magnetRadiusX, this.magnetRadiusY, PI / 2);
        if (victim) {
            ctx.wrap(() => {
                if (RENDER_SCREENSHOT) return;

                ctx.globalAlpha = 0.2;
                ctx.strokeStyle = '#f00';
                ctx.lineWidth = 5;
                ctx.setLineDash([10, 10]);
                ctx.beginPath();
                ctx.moveTo(this.x, this.y);
                ctx.lineTo(victim.x, victim.y);
                ctx.stroke();
            });
        }

        ctx.wrap(() => {
            if (RENDER_SCREENSHOT) return;

            ctx.translate(this.x, this.y);

            const aimAngle = angleBetween(this, this.controls.aim);
            ctx.fillStyle = FOV_GRADIENT[+!!victim];
            ctx.beginPath();
            ctx.arc(0, 0, this.magnetRadiusX, aimAngle - PI / 4, aimAngle + PI / 4);
            ctx.lineTo(0, 0);
            ctx.fill();
        });

        if (DEBUG && DEBUG_PLAYER_MAGNET) {
            ctx.wrap(() => {
                ctx.fillStyle = '#0f0';
                for (let x = this.x - this.magnetRadiusX - 20 ; x < this.x + this.magnetRadiusX + 20 ; x += 4) {
                    for (let y = this.y - this.magnetRadiusY - 20 ; y < this.y + this.magnetRadiusY + 20 ; y += 4) {
                        ctx.globalAlpha = this.strikability({ x, y }, this.magnetRadiusX, this.magnetRadiusY, PI / 2);
                        ctx.fillRect(x - 2, y - 2, 4, 4);
                    }
                }
            });
            ctx.wrap(() => {
                for (const victim of this.scene.category(this.targetTeam)) {
                    const strikability = this.strikability(victim, this.magnetRadiusX, this.magnetRadiusY, PI / 2);
                    if (!strikability) continue;
                    ctx.lineWidth = strikability * 30;
                    ctx.strokeStyle = '#ff0';
                    ctx.beginPath();
                    ctx.moveTo(this.x, this.y);
                    ctx.lineTo(victim.x, victim.y);
                    ctx.stroke();
                }
            });
        }

        if (this.ninja && this.trail && this.health > 0) {
            for (const ghost of this.trail) {
                if (dist(ghost, this) < 12) continue;
                ctx.wrap(() => {
                    ctx.globalAlpha = 0.18 * (1 - (this.age - ghost.a) / 0.18);
                    ctx.fillStyle = '#8cf';
                    ctx.beginPath();
                    ctx.ellipse(ghost.x, ghost.y - 32, 12, 34, 0, 0, TWO_PI);
                    ctx.fill();
                });
            }
        }

        super.render();
    }

    renderBody(renderAge) {
        // Whirlwind spin
        if (this.spin) {
            ctx.translate(0, -30);
            ctx.rotate(this.spin);
            ctx.translate(0, 30);
        }

        const { upgraded } = this;

        // Rigged 3D swordsman: composited from a WebGL canvas, posed procedurally.
        if (this.model3d && w.__S3D && w.__S3D.ready) {
            // The engine draws a skewed shadow pass; skewing a 3D render looks broken.
            if (ctx.isShadow) return;
            const yaw = angleBetween(this, this.controls.aim);
            const sx = cos(yaw);
            const facing = sign(sx) || 1;

            ctx.wrap(() => {
                // Undo the engine's pseudo-3D squash: the model turns for real.
                ctx.scale(1 / (facing * max(0.42, abs(sx))), 1 / (1 + abs(sin(yaw)) * 0.05));
                ctx.rotate(sin(yaw) * 0.1 * facing);

                const state = this.stateMachine.state;
                w.__S3D.update({
                    'yaw': yaw + PI / 2,
                    'moving': this.controls.force ? 1 : 0,
                    'sprint': this.sprinting ? 1 : 0,
                    'strikeT': this.strikeT === undefined ? 1 : this.strikeT,
                    'pose': this.strikeStyle || 0,
                    'crouch': (this.crouch || 0) + (state.shielded ? 5 : 0),
                    't': renderAge === undefined ? this.age : renderAge,
                    'dead': this.health > 0 ? 0 : 1,
                    'gun': this.gun ? 1 : 0,
                    'act': this.testPose || 0,
                    'actT': this.testT === undefined ? 1 : this.testT,
                });

                const g = w.__S3D.geometry(78 * (upgraded ? 1.08 : 1));
                if (this.age - this.lastDamage < 0.1) ctx.globalAlpha = 0.85;
                ctx.drawImage(w.__S3D.canvas, g.x, g.y, g.w, g.h);
            });

            ctx.renderExhaustion(this, -84);
            return;
        }

        ctx.renderFighter(this, {
            'suit': upgraded ? '#121a26' : '#1b1f26',
            'accent': upgraded ? '#2c3a4d' : '#2a2f38',
            'skin': upgraded ? '#fd6' : '#fec',
            'mask': upgraded ? '#121a26' : '#1b1f26',
            'weapon': this.gun ? 'gun' : 'katana',
            'scarf': 1,
        });
    }


}

class PlayerController extends CharacterController {
    // get description() {
    //     return 'Player';
    // }

    cycle() {
        let x = 0, y = 0;
        if (DOWN[37] || DOWN[65]) x = -1;
        if (DOWN[38] || DOWN[87]) y = -1;
        if (DOWN[39] || DOWN[68]) x = 1;
        if (DOWN[40] || DOWN[83]) y = 1;

        const camera = firstItem(this.entity.scene.category('camera'));

        if (x || y) this.entity.controls.angle = atan2(y, x);
        this.entity.controls.force = x || y ? 1 : 0;
        this.entity.controls.shield = DOWN[16] || MOUSE_RIGHT_DOWN || TOUCH_SHIELD_BUTTON.down;
        this.entity.controls.attack = MOUSE_DOWN || TOUCH_ATTACK_BUTTON.down;
        this.entity.controls.dash = DOWN[32] || DOWN[17] || TOUCH_DASH_BUTTON.down;
        this.entity.controls.whirlwind = DOWN[81] || TOUCH_WHIRL_BUTTON.down;
        this.entity.controls.slam = DOWN[70] || TOUCH_SLAM_BUTTON.down;
        this.entity.controls.shadow = DOWN[69] || TOUCH_SHADOW_BUTTON.down;
        this.entity.controls.sprint = DOWN[90] || TOUCH_SPRINT_BUTTON.down;

        if (DOWN[71] && !this.gunKeyDown) this.entity.toggleWeapon();
        this.gunKeyDown = DOWN[71];


        const mouseRelX = (MOUSE_POSITION.x - CANVAS_WIDTH / 2) / (CANVAS_WIDTH / 2);
        const mouseRelY = (MOUSE_POSITION.y - CANVAS_HEIGHT / 2) / (CANVAS_HEIGHT / 2);

        this.entity.controls.aim.x = this.entity.x + mouseRelX * CANVAS_WIDTH / 2 / camera.appliedZoom;
        this.entity.controls.aim.y = this.entity.y + mouseRelY * CANVAS_HEIGHT / 2 / camera.appliedZoom;

        if (inputMode == INPUT_MODE_TOUCH) {
            const { touch } = TOUCH_JOYSTICK;
            this.entity.controls.aim.x = this.entity.x + (touch.x - TOUCH_JOYSTICK.x);
            this.entity.controls.aim.y = this.entity.y + (touch.y - TOUCH_JOYSTICK.y);

            this.entity.controls.angle = angleBetween(TOUCH_JOYSTICK, touch);
            this.entity.controls.force = TOUCH_JOYSTICK.touchIdentifier < 0
                ? 0
                : min(1, dist(touch, TOUCH_JOYSTICK) / TOUCH_JOYSTICK_RADIUS);

            // A second finger anywhere on the right steers the camera view and
            // walks the character wherever it points.
            if (TOUCH_LOOK.touchIdentifier >= 0) {
                const look = TOUCH_LOOK.touch;
                const angle = angleBetween(TOUCH_LOOK, look);
                const force = min(1, dist(look, TOUCH_LOOK) / TOUCH_JOYSTICK_RADIUS);
                this.entity.controls.aim.x = this.entity.x + (look.x - TOUCH_LOOK.x) * 2;
                this.entity.controls.aim.y = this.entity.y + (look.y - TOUCH_LOOK.y) * 2;
                if (force > 0.15) {
                    this.entity.controls.angle = angle;
                    this.entity.controls.force = force;
                }
            }
        }


        if (x) this.entity.facing = x;
    }
}
