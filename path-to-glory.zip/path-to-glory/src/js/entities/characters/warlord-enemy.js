// Act II boss: the Frost Warlord, larger and meaner than the emperor.
class WarlordEnemy extends Enemy {
    constructor() {
        super();

        this.gibs = [
            () => ctx.renderAxe(),
            () => ctx.renderShield(),
        ];

        this.health = this.maxHealth = 1000;
        this.strength = 50;
        this.baseSpeed = 130;
        this.aggression = 4;
        this.damageLabelColor = '#0ef';

        this.strikeRadiusX = 110;
        this.strikeRadiusY = 55;

        this.stateMachine = characterStateMachine({
            entity: this,
            chargeTime: 0.4,
            staggerTime: 0.15,
        });
    }

    strike(relativeStrength) {
        super.strike(relativeStrength);

        // Every heavy blow sends out a frost wave
        if (relativeStrength > 1) {
            const wave = this.scene.add(new Shockwave('#0ef', 260, 0.5));
            wave.x = this.x;
            wave.y = this.y - 20;
            shake(8);
        }
    }

    renderBody(renderAge) {
        ctx.wrap(() => {
            ctx.scale(1.25, 1.25);

            ctx.renderAttackIndicator(this);
            ctx.renderLegs(this, '#123');
            ctx.renderArm(this, '#123', () => ctx.renderAxe());
            ctx.renderHead(this, '#456', '#0ef');

            // Horned helm
            ctx.wrap(() => {
                ctx.fillStyle = ctx.resolveColor('#dde');
                ctx.translate(0, -62);
                for (const side of [-1, 1]) {
                    ctx.beginPath();
                    ctx.moveTo(side * 5, 0);
                    ctx.lineTo(side * 18, -14);
                    ctx.lineTo(side * 8, 4);
                    ctx.fill();
                }
            });

            ctx.renderChest(this, '#245', CHEST_WIDTH_ARMORED + 4);

            // Cape
            ctx.wrap(() => {
                ctx.fillStyle = ctx.resolveColor('#059');
                ctx.translate(-2, -50);
                ctx.beginPath();
                ctx.moveTo(0, 0);
                ctx.lineTo(-14 + sin((renderAge || this.age) * 4) * 4, 34);
                ctx.lineTo(6, 30);
                ctx.fill();
            });

            ctx.renderArmAndShield(this, '#123');
            ctx.renderExhaustion(this, -80);
            ctx.renderExclamation(this);
        });
    }
}
