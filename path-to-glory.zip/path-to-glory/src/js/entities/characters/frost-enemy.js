// Act II enemies: frost-hardened northern troops. Built on the Act I roster
// so behaviour stays familiar, but tougher, faster and icy-looking.
FROST_PALETTE = {
    '#fec': '#cdd',
    '#753': '#245',
    '#666': '#456',
    '#ccc': '#9bd',
    '#444': '#123',
    '#a65': '#654',
    'green': '#8ad',
};

createFrostEnemyType = (options) => {
    const Base = createEnemyType(options);

    class FrostEnemyType extends Base {
        constructor() {
            super();

            this.health = this.maxHealth = ~~(this.maxHealth * 1.6);
            this.strength += 12;
            this.baseSpeed *= 1.25;
            this.aggression += 1;
            this.damageLabelColor = '#0ef';
        }

        getColor(color) {
            return super.getColor(FROST_PALETTE[color] || color);
        }

        renderBody(renderAge) {
            super.renderBody(renderAge);

            // Frost plume on the helmet
            ctx.wrap(() => {
                ctx.fillStyle = ctx.resolveColor('#0ef');
                ctx.translate(0, -62);
                ctx.rotate(sin((renderAge || this.age) * 3) * PI / 32);
                ctx.beginPath();
                ctx.moveTo(-3, 0);
                ctx.lineTo(0, -16);
                ctx.lineTo(3, 0);
                ctx.fill();
            });
        }

        die() {
            // Shatters into an icy burst
            const burst = this.scene.add(new Shockwave('#0ef', 160, 0.4));
            burst.x = this.x;
            burst.y = this.y - 20;

            for (let i = 0 ; i < 24 ; i++) {
                const x = this.x + rnd(-20, 20);
                const y = this.y - 30 + rnd(-20, 20);
                this.scene.add(new Particle(
                    '#0ef',
                    [rnd(3, 6), 0],
                    [x, x + rnd(-50, 50)],
                    [y, y + rnd(-50, 50)],
                    rnd(0.3, 0.6),
                ));
            }

            super.die();
        }
    }

    return FrostEnemyType;
};

FROST_ENEMY_TYPES = [
    FrostStickEnemy = createFrostEnemyType({ ...stick, }),
    FrostAxeEnemy = createFrostEnemyType({ ...axe, }),
    FrostSwordEnemy = createFrostEnemyType({ ...sword, }),
    FrostSwordArmorEnemy = createFrostEnemyType({ ...sword, ...armor, }),
    FrostAxeArmorEnemy = createFrostEnemyType({ ...axe, ...armor, }),
    FrostAxeShieldArmorEnemy = createFrostEnemyType({ ...axe, ...shield, ...armor, }),
    FrostSwordShieldArmorEnemy = createFrostEnemyType({ ...sword, ...shield, ...armor, }),
    FrostSwordShieldTankEnemy = createFrostEnemyType({ ...sword, ...shield, ...superArmor, }),
    FrostAxeShieldTankEnemy = createFrostEnemyType({ ...axe, ...shield, ...superArmor, }),
];

FROST_WAVE_SETTINGS = [
    FROST_ENEMY_TYPES.slice(0, 4),
    FROST_ENEMY_TYPES.slice(0, 5),
    FROST_ENEMY_TYPES.slice(0, 7),
    FROST_ENEMY_TYPES,
];
