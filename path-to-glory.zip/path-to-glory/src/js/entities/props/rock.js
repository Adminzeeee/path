// Snow-capped boulder, blocks movement.
class Rock extends Obstacle {

    constructor() {
        super();

        this.size = this.rng.next(25, 55);
        this.collisionRadius = this.size * 0.8;
        this.renderPadding = 150;
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        if (!this.noRegen) regenEntity(this, CANVAS_WIDTH / 2 + 200, CANVAS_HEIGHT / 2 + 300);
    }

    doRender() {
        ctx.translate(this.x, this.y);

        ctx.withShadow(() => {
            this.rng.reset();

            ctx.fillStyle = ctx.resolveColor('#778');
            ctx.beginPath();
            for (let r = 0 ; r < 1 ; r += 1 / 7) {
                const angle = r * TWO_PI;
                const radius = this.size * this.rng.next(0.7, 1);
                ctx.lineTo(cos(angle) * radius, sin(angle) * radius * 0.6 - this.size * 0.4);
            }
            ctx.fill();

            if (!ctx.isShadow) {
                this.rng.reset();
                ctx.fillStyle = ctx.resolveColor('#dde');
                ctx.beginPath();
                for (let r = 0 ; r < 0.5 ; r += 1 / 7) {
                    const angle = r * TWO_PI + PI;
                    const radius = this.size * this.rng.next(0.7, 1);
                    ctx.lineTo(cos(angle) * radius, sin(angle) * radius * 0.6 - this.size * 0.5);
                }
                ctx.fill();
            }
        });
    }
}
