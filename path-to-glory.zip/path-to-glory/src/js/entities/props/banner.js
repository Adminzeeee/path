// Northern Empire war banner, pure decor.
class Banner extends Entity {

    constructor() {
        super();
        this.renderPadding = 250;
        this.height = this.rng.next(120, 180);
    }

    cycle(elapsed) {
        super.cycle(elapsed);
        if (!this.noRegen) regenEntity(this, CANVAS_WIDTH / 2 + 200, CANVAS_HEIGHT / 2 + 300);
    }

    doRender() {
        ctx.translate(this.x, this.y);

        ctx.withShadow(() => {
            this.rng.reset();

            ctx.fillStyle = ctx.resolveColor('#432');
            ctx.fillRect(-3, 0, 6, -this.height);

            ctx.translate(0, -this.height);

            // Waving cloth
            ctx.fillStyle = ctx.resolveColor('#248');
            ctx.beginPath();
            ctx.moveTo(0, 0);
            for (let y = 0 ; y <= 70 ; y += 10) {
                ctx.lineTo(sin((this.age * 3) + y / 20) * 6, y);
            }
            ctx.lineTo(45 + sin(this.age * 3 + 4) * 8, 60);
            for (let y = 70 ; y >= 0 ; y -= 10) {
                ctx.lineTo(45 + sin((this.age * 3) + y / 20 + 2) * 8, y);
            }
            ctx.fill();

            if (!ctx.isShadow) {
                ctx.fillStyle = ctx.resolveColor('#eef');
                ctx.fillRect(16, 18, 10, 34);
                ctx.fillRect(6, 28, 30, 10);
            }
        });
    }
}
