// Minimal "bare land" arena floor: soft gradient dirt with a faint 3D grid
// that fades with distance. Nothing else in the world for now.
class Ground extends Entity {
    get z() {
        return LAYER_PATH;
    }

    doRender(camera) {
        const w = CANVAS_WIDTH / camera.appliedZoom;
        const h = CANVAS_HEIGHT / camera.appliedZoom;
        const x0 = camera.x - w;
        const y0 = camera.y - h;

        const grad = ctx.createLinearGradient(0, y0, 0, y0 + h * 2);
        grad.addColorStop(0, '#20242b');
        grad.addColorStop(0.5, '#33363c');
        grad.addColorStop(1, '#1b1e24');
        ctx.fillStyle = grad;
        ctx.fillRect(x0, y0, w * 2, h * 2);

        // Perspective-ish grid: rows get tighter towards the top
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5;
        ctx.globalAlpha = 0.06;
        ctx.beginPath();
        for (let x = roundToNearest(x0, 200); x < x0 + w * 2; x += 200) {
            ctx.moveTo(x, y0);
            ctx.lineTo(x, y0 + h * 2);
        }
        for (let y = roundToNearest(y0, 120); y < y0 + h * 2; y += 120) {
            ctx.moveTo(x0, y);
            ctx.lineTo(x0 + w * 2, y);
        }
        ctx.stroke();

        // Pool of light around the player
        const player = firstItem(this.scene.category('player'));
        if (player) {
            ctx.globalAlpha = 1;
            const light = ctx.createRadialGradient(player.x, player.y, 0, player.x, player.y, 700);
            light.addColorStop(0, 'rgba(255,240,210,.10)');
            light.addColorStop(1, 'rgba(0,0,0,0)');
            ctx.fillStyle = light;
            ctx.fillRect(x0, y0, w * 2, h * 2);
        }
    }
}
