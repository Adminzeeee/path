// Snow-laden conifer for the northern act.
class Pine extends Obstacle {

    constructor() {
        super();

        this.trunkWidth = this.rng.next(12, 22);
        this.trunkHeight = this.rng.next(60, 130);
        this.tiers = ~~this.rng.next(3, 6);

        this.collisionRadius = 22;
        this.alpha = 1;

        this.renderPadding = this.trunkHeight + 220;
    }

    cycle(elapsed) {
        super.cycle(elapsed);

        if (!this.noRegen) regenEntity(this, CANVAS_WIDTH / 2 + 200, CANVAS_HEIGHT / 2 + 400);

        this.rng.reset();

        let targetAlpha = 1;
        for (const character of this.scene.category('player')) {
            if (
                isBetween(this.x - 100, character.x, this.x + 100) &&
                isBetween(this.y - this.trunkHeight - 150, character.y, this.y)
            ) {
                targetAlpha = 0.25;
                break;
            }
        }

        this.alpha += between(-elapsed * 2, targetAlpha - this.alpha, elapsed * 2);
    }

    doRender() {
        ctx.translate(this.x, this.y);

        ctx.withShadow(() => {
            this.rng.reset();

            ctx.wrap(() => {
                ctx.rotate(sin((this.age + this.rng.next(0, 10)) * TWO_PI / this.rng.next(6, 16)) * PI / 128);

                if (!ctx.isShadow) ctx.globalAlpha = this.alpha;

                // Trunk
                ctx.fillStyle = ctx.resolveColor('#543');
                ctx.fillRect(-this.trunkWidth / 2, 0, this.trunkWidth, -this.trunkHeight);

                ctx.translate(0, -this.trunkHeight);

                // Tiers of needles, each capped with snow
                let width = this.rng.next(60, 80);
                let y = 0;
                for (let i = 0 ; i < this.tiers ; i++) {
                    const height = this.rng.next(50, 70);

                    ctx.fillStyle = ctx.resolveColor('#132');
                    ctx.beginPath();
                    ctx.moveTo(-width / 2, y);
                    ctx.lineTo(0, y - height);
                    ctx.lineTo(width / 2, y);
                    ctx.fill();

                    if (!ctx.isShadow) {
                        ctx.fillStyle = ctx.resolveColor('#eef');
                        ctx.beginPath();
                        ctx.moveTo(-width / 2, y);
                        ctx.lineTo(0, y - height);
                        ctx.lineTo(width / 2, y);
                        ctx.lineTo(width / 4, y - height / 4);
                        ctx.lineTo(0, y - height / 8);
                        ctx.lineTo(-width / 4, y - height / 3);
                        ctx.fill();
                    }

                    y -= height * 0.6;
                    width *= 0.75;
                }
            });
        });
    }
}
