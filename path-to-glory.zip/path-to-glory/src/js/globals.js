const w = window;

let can;
let ctx;

let GAME_PAUSED;
let BEATEN;

// Kept for prop/sky tinting compatibility; the arena is not wintery.
WINTER = 0;

// Screen shake, decayed by the camera.
SHAKE = 0;
shake = (amount) => {
    if (OPT_SHAKE) SHAKE = max(SHAKE, amount);
};

// Haptics on hits/strikes (mobile).
vibrate = (ms) => {
    if (OPT_VIBRATE && navigator.vibrate) navigator.vibrate(ms);
};

// Camera zoom controlled by the player (wheel / +- / on-screen buttons).
ZOOM_USER = 1;
setZoom = (factor) => ZOOM_USER = between(0.55, ZOOM_USER * factor, 3);

// Peaceful world: enemies wander around and never attack.
PEACEFUL = 1;

// Options ([O] in game)
OPTIONS_OPEN = 0;
OPT_WEATHER = 1;
OPT_BLOOD = 1;
OPT_SHAKE = 1;
OPT_SLOWMO = 1;
OPT_VIBRATE = 1;

// How many gangsters roam the arena at once.
ENEMY_COUNTS = [1, 2, 3, 5, 8, 12];
ENEMY_COUNT_INDEX = 1;
ENEMY_COUNT = 2;

// Mobile button layouts: 0 = cluster, 1 = spread, 2 = corner arc
TOUCH_LAYOUT = 0;

// Chosen hero: 0 = knight, 1 = ninja, 2 = rigged swordsman, 3 = rigged fighter.
HERO = [0, 1, 2, 3].indexOf(w.__hero) >= 0 ? w.__hero : 1;

// The rigged 3D characters are pose labs: no enemies at all.
NO_ENEMIES = HERO >= 2;

// Back to the character select screen.
backToMenu = () => location.reload();


canvasPrototype = CanvasRenderingContext2D.prototype;

DPR = Math.min(devicePixelRatio, 2);
MOBILE = /andro|ipho|ipa|ipo|mobi/i.test(navigator.userAgent) || navigator.maxTouchPoints > 0;

inputMode = (navigator.userAgent.match(nomangle(/andro|ipho|ipa|ipo|mobi/i)) || navigator.maxTouchPoints > 0) ? INPUT_MODE_TOUCH : INPUT_MODE_MOUSE;

toggleFullscreen = () => {
    if (document.fullscreenElement) {
        document.exitFullscreen();
    } else if (document.documentElement.requestFullscreen) {
        document.documentElement.requestFullscreen();
    }
};
