class Level {
    constructor(options = {}) {
        this.scene = new Scene();

        WINTER = 0;

        this.scene.add(new Camera());

        DOWN = {};
        MOUSE_DOWN = MOUSE_RIGHT_DOWN = false;

        this.scene.add(new AggressivityTracker());

        const player = this.scene.add(new Player());
        this.scene.add(new Cursor(player));

        this.scene.add(new PauseOverlay());
        this.scene.add(new OptionsOverlay());
    }

    cycle(elapsed) {
        this.scene.cycle(elapsed);
    }

    async respawn(x, y) {
        const fade = this.scene.add(new Fade());
        await this.scene.add(new Interpolator(fade, 'alpha', 0, 1, 1)).await();
        const player = firstItem(this.scene.category('player'));
        const camera = firstItem(this.scene.category('camera'));
        player.x = x;
        player.y = y;
        camera.cycle(999);
        await this.scene.add(new Interpolator(fade, 'alpha', 1, 0, 1)).await();
        fade.remove();
    }
}
