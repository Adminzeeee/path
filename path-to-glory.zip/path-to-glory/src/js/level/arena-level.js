// Endless arena: bare land, the hero, and gangs closing in from every side.
class ArenaLevel extends Level {
    constructor() {
        super();

        const { scene } = this;

        const player = firstItem(scene.category('player'));
        player.x = player.y = 0;

        const camera = firstItem(scene.category('camera'));
        camera.cycle(99);

        const playerHUD = scene.add(new PlayerHUD(player));
        playerHUD.progress = playerHUD.progressGauge.displayedValue = 0;

        scene.add(new Ground());

        const spawn = () => {
            const angle = random() * TWO_PI;
            const d = rnd(320, 480);
            const types = GANG_TYPES.slice(0, min(GANG_TYPES.length, 3 + ~~(player.score / 4000)));
            const enemy = scene.add(new (pick(types))());
            enemy.x = player.x + cos(angle) * d;
            enemy.y = player.y + sin(angle) * d * 0.6;
            enemy.poof();
            scene.add(new CharacterHUD(enemy));
            scene.add(new CharacterOffscreenIndicator(enemy));
        };

        // Keep the arena populated according to the chosen difficulty
        (async () => {
            const fade = scene.add(new Fade());
            await scene.add(new Interpolator(fade, 'alpha', 1, 0, 1)).await();
            scene.add(new Announcement(nomangle('Fight')));

            while (!NO_ENEMIES) {
                const alive = Array.from(scene.category('enemy')).filter(e => e.health > 0).length;
                if (alive < ENEMY_COUNT) spawn();
                await scene.delay(alive < ENEMY_COUNT ? 0.6 : 1.5);
            }
        })();

        // Game over: restart the arena
        (async () => {
            await scene.waitFor(() => player.health <= 0);

            const fade = scene.add(new Fade());
            await scene.add(new Interpolator(fade, 'alpha', 0, 1, 2)).await();
            level = new ArenaLevel();
        })();
    }
}
