// Act II: the northern campaign. Same core loop as Act I, colder world,
// tougher troops, upgraded hero, and the Frost Warlord at the end.
class FrozenLevel extends Level {
    constructor(waveIndex = 0, score = 0) {
        super({ 'winter': 1 });

        const { scene } = this;

        let waveStartScore = score;

        const player = firstItem(scene.category('player'));
        player.upgrade();
        player.x = waveIndex * CANVAS_WIDTH;
        player.y = scene.pathCurve(player.x);
        player.score = score;

        const camera = firstItem(scene.category('camera'));
        camera.cycle(99);

        const playerHUD = scene.add(new PlayerHUD(player));
        playerHUD.dummyKing = new WarlordEnemy();
        scene.add(new Path());

        for (let i = 0 ; i < 18 ; i++) {
            const pine = scene.add(new Pine());
            pine.x = rnd(-1, 1) * CANVAS_WIDTH / 2;
            pine.y = rnd(-1, 1) * CANVAS_HEIGHT / 2;
        }

        for (let i = 0 ; i < 10 ; i++) {
            const banner = scene.add(new Banner());
            banner.x = random() * CANVAS_WIDTH * 5;
            banner.y = rnd(-1, 1) * CANVAS_HEIGHT;
        }

        for (let i = 0 ; i < 14 ; i++) {
            const water = scene.add(new Water());
            water.width = rnd(120, 260);
            water.height = rnd(200, 400);
            water.rotation = random() * TWO_PI;
            water.x = random() * CANVAS_WIDTH * 5;
            water.y = random() * CANVAS_HEIGHT * 5;
        }

        // Respawn when far from the path
        (async () => {
            while (true) {
                await scene.waitFor(() => abs(player.y - scene.pathCurve(player.x)) > 1000 || player.x < camera.minX - CANVAS_WIDTH / 2);

                const x = max(camera.minX + CANVAS_WIDTH, player.x);
                await this.respawn(x, scene.pathCurve(x));
            }
        })();

        async function slowMo() {
            if (!OPT_SLOWMO) return;
            player.affectedBySpeedRatio = true;
            scene.speedRatio = 0.2;
            await camera.zoomTo(3);
            await scene.delay(1.5 * scene.speedRatio);
            await camera.zoomTo(1);
            scene.speedRatio = 1;
            player.affectedBySpeedRatio = false;
        }

        function spawnWave(enemyCount, enemyTypes) {
            return Array.apply(null, Array(enemyCount)).map(() => {
                const enemy = scene.add(new (pick(enemyTypes))());
                enemy.x = player.x + rnd(-CANVAS_WIDTH / 2, CANVAS_WIDTH / 2);
                enemy.y = player.y + pick([-1, 1]) * (evaluate(CANVAS_HEIGHT / 2) + rnd(50, 100));
                scene.add(new CharacterHUD(enemy));
                scene.add(new CharacterOffscreenIndicator(enemy));
                return enemy;
            });
        }

        // Scenario
        (async () => {
            const fade = scene.add(new Fade());
            await scene.add(new Interpolator(fade, 'alpha', 1, 0, 2)).await();

            scene.add(new Announcement(nomangle('The Frozen March')));

            const instruction = scene.add(new Instruction());
            instruction.text = nomangle('New moves: [Q] whirlwind, [F] war slam, [Z] sprint');
            (async () => {
                await scene.delay(8);
                instruction.text = '';
            })();

            playerHUD.progress = playerHUD.progressGauge.displayedValue = waveIndex / WAVE_COUNT;

            let nextWaveX = player.x + CANVAS_WIDTH;
            for ( ; waveIndex < WAVE_COUNT ; waveIndex++) {
                (async () => {
                    await scene.delay(1);
                    await scene.add(new Interpolator(playerHUD, 'progressAlpha', 0, 1, 1)).await();
                    playerHUD.progress = waveIndex / WAVE_COUNT;

                    player.heal(player.maxHealth * 0.5);

                    await scene.delay(3);
                    await scene.add(new Interpolator(playerHUD, 'progressAlpha', 1, 0, 1)).await();
                })();

                (async () => {
                    await scene.delay(12);
                    if (!instruction.text) instruction.text = nomangle('Follow the path to the right');
                })();

                await scene.waitFor(() => player.x >= nextWaveX);

                instruction.text = '';
                waveStartScore = player.score;

                scene.add(new Announcement(nomangle('Frost Wave ') + (waveIndex + 1)));

                const waveEnemies = spawnWave(
                    4 + waveIndex,
                    FROST_WAVE_SETTINGS[min(FROST_WAVE_SETTINGS.length - 1, waveIndex)],
                );

                await Promise.all(waveEnemies.map(enemy => scene.waitFor(() => enemy.health <= 0)));
                slowMo();

                scene.add(new Announcement(nomangle('Wave Cleared')));

                nextWaveX = player.x + evaluate(CANVAS_WIDTH * 2);
                camera.minX = player.x - CANVAS_WIDTH;
            }

            // The Warlord
            await scene.waitFor(() => player.x >= nextWaveX);
            const warlord = scene.add(new WarlordEnemy());
            warlord.x = camera.x + CANVAS_WIDTH + 50;
            warlord.y = scene.pathCurve(warlord.x);
            scene.add(new CharacterHUD(warlord));

            await scene.waitFor(() => warlord.x - player.x < 400);
            await scene.add(new Interpolator(fade, 'alpha', 0, 1, 2 * scene.speedRatio)).await();

            player.x = warlord.x - 400;
            player.y = scene.pathCurve(player.x);

            const expo = scene.add(new Exposition([
                nomangle('Beyond the frozen pass waited the Warlord of the North.'),
            ]));

            await scene.delay(3);
            await scene.add(new Interpolator(expo, 'alpha', 1, 0, 2)).await();
            await scene.add(new Interpolator(fade, 'alpha', 1, 0, 2)).await();

            const aiType = createEnemyAI({
                shield: true,
                attackCount: 4,
            });
            warlord.setController(new aiType());
            scene.add(new CharacterOffscreenIndicator(warlord));

            spawnWave(6, FROST_WAVE_SETTINGS[FROST_WAVE_SETTINGS.length - 1]);

            await scene.waitFor(() => warlord.health <= 0);

            player.health = player.maxHealth = 999;
            BEATEN = true;

            await slowMo();
            await scene.add(new Interpolator(fade, 'alpha', 0, 1, 2 * scene.speedRatio)).await();

            const finalExpo = scene.add(new Exposition([
                nomangle('The Warlord fell, and the northern host broke with him.'),
                nomangle('The path to glory was walked to its very end.'),
                nomangle('Final score: ') + player.score.toLocaleString() + '.',
            ]));
            await scene.add(new Interpolator(finalExpo, 'alpha', 0, 1, 2 * scene.speedRatio)).await();
            await scene.delay(9 * scene.speedRatio);
            await scene.add(new Interpolator(finalExpo, 'alpha', 1, 0, 2 * scene.speedRatio)).await();

            level = new IntroLevel();
        })();

        // Game over
        (async () => {
            await scene.waitFor(() => player.health <= 0);

            slowMo();

            const fade = scene.add(new Fade());
            await scene.add(new Interpolator(fade, 'alpha', 0, 1, 2 * scene.speedRatio)).await();
            scene.speedRatio = 2;

            const expo = scene.add(new Exposition([
                pick([
                    nomangle('The snow took him, but not his resolve.'),
                    nomangle('The cold was a crueler foe than any soldier.'),
                    nomangle('He rose again, frost in his beard.'),
                ]),

                pick([
                    nomangle('The whirlwind would clear the crowd next time ([Q])'),
                    nomangle('A war slam would break their shields ([F])'),
                    nomangle('Sprinting would keep him out of reach ([Z])'),
                ]),
            ]));

            await scene.delay(6);
            await scene.add(new Interpolator(expo, 'alpha', 1, 0, 2)).await();

            level = new FrozenLevel(waveIndex, max(0, waveStartScore - 5000));
        })();
    }
}
