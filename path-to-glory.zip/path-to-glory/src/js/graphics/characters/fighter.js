// Shared "real body" renderer: rounded capsule limbs, oval head, pose system.
// Used by the ninja hero and every gangster enemy so anatomy stays consistent.

capsule = (x1, y1, x2, y2, w, color) => {
    ctx.strokeStyle = ctx.resolveColor ? ctx.resolveColor(color) : color;
    ctx.lineWidth = w;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
};

blob = (x, y, rx, ry, color, rot) => {
    ctx.fillStyle = ctx.resolveColor ? ctx.resolveColor(color) : color;
    ctx.beginPath();
    ctx.ellipse(x, y, rx, ry, rot || 0, 0, TWO_PI);
    ctx.fill();
};

// [armStart, armEnd, torsoStart, torsoEnd, offArm, weaponSpin]
STRIKE_POSES = [
    [-2.5, 1.1, -0.22, 0.3, -0.7, 0],       // Overhead cleave
    [-1.9, 1.9, 0.3, -0.35, 0.9, 0],        // Horizontal sweep
    [1.6, -1.9, 0.25, -0.2, -0.3, 0],       // Rising uppercut
    [-0.2, 0.1, 0.1, -0.1, -0.2, 0],        // Straight thrust
    [-2.2, 2.2, -0.4, 0.45, 1.2, 1],        // Spinning drop-slash
];
STRIKE_NAMES = ['Cleave!', 'Sweep!', 'Rising Fang!', 'Thrust!', 'Tornado Slash!'];

canvasPrototype.renderKnife = function() {
    ctx.wrap(() => {
        ctx.fillStyle = ctx.resolveColor('#222');
        ctx.fillRect(-2, 0, 4, 10);
        ctx.fillStyle = ctx.resolveColor('#dee');
        ctx.beginPath();
        ctx.moveTo(-2.5, 0);
        ctx.lineTo(-1, -20);
        ctx.lineTo(2.5, -16);
        ctx.lineTo(2.5, 0);
        ctx.fill();
    });
};

canvasPrototype.renderPistol = function() {
    ctx.wrap(() => {
        ctx.fillStyle = ctx.resolveColor('#333');
        ctx.fillRect(-3, -2, 6, 10);
        ctx.fillStyle = ctx.resolveColor('#555');
        ctx.rotate(-PI / 2);
        ctx.fillRect(-4, -3, 22, 6);
        ctx.fillStyle = ctx.resolveColor('#222');
        ctx.fillRect(14, -2, 6, 4);
    });
};

canvasPrototype.renderBat = function() {
    ctx.wrap(() => {
        ctx.fillStyle = ctx.resolveColor('#963');
        ctx.beginPath();
        ctx.moveTo(-2, 8);
        ctx.lineTo(-5, -30);
        ctx.lineTo(5, -30);
        ctx.lineTo(2, 8);
        ctx.fill();
    });
};

canvasPrototype.renderNunchaku = function(t) {
    ctx.wrap(() => {
        ctx.rotate(sin(t * 12) * 1.2);
        capsule(0, 0, 0, -16, 4, '#421');
        capsule(0, -16, 10, -26, 3, '#421');
    });
};

renderWeapon = (weapon, t) => {
    if (weapon == 'katana') ctx.renderKatana();
    if (weapon == 'knife') ctx.renderKnife();
    if (weapon == 'gun') ctx.renderPistol();
    if (weapon == 'bat') ctx.renderBat();
    if (weapon == 'chuck') ctx.renderNunchaku(t);
};

// o: { suit, skin, accent, weapon, mask, bulk, scarf }
canvasPrototype.renderFighter = function(entity, o) {
    const t = entity.renderAge === undefined ? entity.age : entity.renderAge;
    const state = entity.stateMachine ? entity.stateMachine.state : {};
    const moving = entity.controls.force;
    const bulk = o.bulk || 1;

    const p = t * (moving ? (entity.sprinting ? 17 : 11) : 1.4);
    const stride = moving ? sin(p) : 0;
    // Natural bob: hopping while running, soft breathing while idle
    const bounce = moving ? abs(sin(p)) * 3.5 : sin(t * 1.4) * 1.3;
    const guard = state.shielded ? 1 : 0;
    const crouchIdle = entity.health > 0 ? (sin(t * 0.7) > 0.93 ? 6 : 0) : 0;
    const crouch = (entity.crouch || 0) + guard * 5 + crouchIdle - bounce;

    const hipY = -32 + crouch;
    const shoulderY = hipY - 22 * bulk;
    const headY = shoulderY - 13 * bulk;

    const charge = state.attackPreparationRatio || 0;
    const st = entity.strikeT === undefined ? 1 : entity.strikeT;

    let armA = -0.5 + sin(t * 1.2) * 0.07;
    let armB = 0.45 - sin(t * 1.1) * 0.07;
    let torso = moving ? 0.1 : 0;

    if (charge > 0) {
        armA = interpolate(-0.5, -2.3, charge);
        torso = -0.25 * charge;
    }

    if (st < 1) {
        const pose = STRIKE_POSES[(entity.strikeStyle || 0) % STRIKE_POSES.length];
        const e = min(1, st * 1.5);
        armA = interpolate(pose[0], pose[1], e);
        torso = interpolate(pose[2], pose[3], e);
        armB = pose[4];
    }

    if (guard) armB = -1.15;

    if (o.weapon == 'gun') {
        const aimAngle = angleBetween(entity, entity.controls.aim);
        armA = -sin(aimAngle) * 0.9 * (entity.facing || 1);
        if (entity.muzzle > 0) armA -= 0.25;
    }

    ctx.wrap(() => {
        ctx.rotate(torso * 0.35);

        // Shadowed under-leg first
        capsule(-2, hipY, -3 - stride * 9, -2 + abs(stride) * 5, 9 * bulk, o.suit);
        capsule(-3 - stride * 9, -2 + abs(stride) * 5, -5 - stride * 11, 0, 7 * bulk, '#111');

        // Front leg
        capsule(2, hipY, 3 + stride * 9, -2 + abs(stride) * 5, 9.5 * bulk, o.suit);
        capsule(3 + stride * 9, -2 + abs(stride) * 5, 5 + stride * 11, 0, 7 * bulk, '#111');

        // Torso: tapered chest + waist
        blob(0, (hipY + shoulderY) / 2, 11 * bulk, 15 * bulk, o.suit, torso * 0.2);
        blob(0, shoulderY + 2, 12 * bulk, 8 * bulk, o.accent || o.suit);

        if (o.scarf) ctx.renderScarf(entity, t);

        // Off arm (behind)
        ctx.wrap(() => {
            ctx.translate(-4, shoulderY + 2);
            ctx.rotate(armB - stride * 0.5);
            capsule(0, 0, 13 * bulk, 0, 7 * bulk, o.accent || o.suit);
            ctx.translate(13 * bulk, 0);
            ctx.rotate(0.7);
            capsule(0, 0, 11 * bulk, 0, 6 * bulk, o.skin);
        });

        // Head: oval skull, mask wrap, eye slit
        ctx.wrap(() => {
            ctx.translate(0, headY);
            ctx.rotate(torso * 0.5 + sin(t * 1.4) * 0.03);
            blob(0, 0, 8.5 * bulk, 10.5 * bulk, o.mask || o.skin);
            if (entity.backView) {
                // Back of the head: knot / ponytail
                blob(0, 2, 5 * bulk, 6 * bulk, '#0000002a');
                capsule(0, 4, -2, 16, 5, o.mask || o.skin);
            } else {
                blob(2.5, -1.5, 5.5 * bulk, 2.6 * bulk, o.skin);
                blob(4.5, -1.5, 1.6, 1.9, '#111');
            }
            if (o.hair) blob(-1, -8, 8 * bulk, 5 * bulk, o.hair);
        });

        // Weapon arm (front)
        ctx.wrap(() => {
            if (entity.health <= 0) return;
            ctx.translate(4, shoulderY + 3);
            ctx.rotate(armA + stride * 0.5);
            capsule(0, 0, 13 * bulk, 0, 7.5 * bulk, o.accent || o.suit);
            ctx.translate(13 * bulk, 0);
            ctx.rotate(st < 1 ? -0.2 : 0.45);
            capsule(0, 0, 11 * bulk, 0, 6.5 * bulk, o.skin);
            ctx.translate(11 * bulk, 0);
            ctx.rotate(-PI / 2 + 0.2);
            renderWeapon(o.weapon, t);
        });
    });

    ctx.renderExhaustion(entity, -78);
};
