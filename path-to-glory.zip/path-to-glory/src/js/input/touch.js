PINCH_DIST = 0;

class MobileJoystick {

    constructor() {
        this.x = this.y = 0;
        this.touch = {'x': 0, 'y': 0};
        this.touchIdentifier = -1;
    }

    render() {
        if (this.touchIdentifier < 0) return;

        const extraForceRatio = between(0, (dist(this, this.touch) - TOUCH_JOYSTICK_RADIUS) / (TOUCH_JOYSTICK_MAX_RADIUS - TOUCH_JOYSTICK_RADIUS), 1);
        const radius = (1 - extraForceRatio) * TOUCH_JOYSTICK_RADIUS;

        TOUCH_CONTROLS_CTX.globalAlpha = interpolate(0.5, 0, extraForceRatio);
        TOUCH_CONTROLS_CTX.strokeStyle = '#fff';
        TOUCH_CONTROLS_CTX.lineWidth = 2;
        TOUCH_CONTROLS_CTX.fillStyle = 'rgba(0,0,0,0.5)';
        TOUCH_CONTROLS_CTX.beginPath();
        TOUCH_CONTROLS_CTX.arc(this.x, this.y, radius * DPR, 0, TWO_PI);
        TOUCH_CONTROLS_CTX.fill();
        TOUCH_CONTROLS_CTX.stroke();

        TOUCH_CONTROLS_CTX.globalAlpha = 0.5;
        TOUCH_CONTROLS_CTX.fillStyle = '#fff';
        TOUCH_CONTROLS_CTX.beginPath();
        TOUCH_CONTROLS_CTX.arc(this.touch.x, this.touch.y, 30 * DPR, 0, TWO_PI);
        TOUCH_CONTROLS_CTX.fill();
    }
}

// Each button knows its position in the 3 selectable layouts, as an offset
// from an anchor corner: [dxFromRight, dyFromBottom, scale].
class MobileButton {
    constructor(label, layouts, tap) {
        this.label = label;
        this.layouts = layouts;
        this.tap = tap;
    }

    get slot() {
        return this.layouts[TOUCH_LAYOUT] || this.layouts[0];
    }

    get radius() {
        return TOUCH_BUTTON_RADIUS * (this.slot[2] || 1) * DPR;
    }

    x() {
        const [dx] = this.slot;
        return dx < 0
            ? -dx * DPR
            : TOUCH_CONTROLS_CANVAS.width - dx * DPR;
    }

    y() {
        return TOUCH_CONTROLS_CANVAS.height - this.slot[1] * DPR;
    }

    render() {
        TOUCH_CONTROLS_CTX.translate(this.x(), this.y());

        const r = this.radius;

        TOUCH_CONTROLS_CTX.strokeStyle = '#fff';
        TOUCH_CONTROLS_CTX.lineWidth = 2;
        TOUCH_CONTROLS_CTX.fillStyle = this.down ? 'rgba(255,255,255,0.55)' : 'rgba(0,0,0,0.45)';
        TOUCH_CONTROLS_CTX.beginPath();
        TOUCH_CONTROLS_CTX.arc(0, 0, r, 0, TWO_PI);
        TOUCH_CONTROLS_CTX.fill();
        TOUCH_CONTROLS_CTX.stroke();

        TOUCH_CONTROLS_CTX.scale(DPR, DPR);
        TOUCH_CONTROLS_CTX.font = nomangle('13pt Courier');
        TOUCH_CONTROLS_CTX.textAlign = nomangle('center');
        TOUCH_CONTROLS_CTX.textBaseline = nomangle('middle');
        TOUCH_CONTROLS_CTX.fillStyle = '#fff';
        TOUCH_CONTROLS_CTX.fillText(this.label, 0, 0);
    }
}

updateTouches = (touches) => {
    const free = [];

    for (const button of TOUCH_BUTTONS) {
        button.wasHit = false;
    }

    for (const touch of touches) {
        getEventPosition(touch, TOUCH_CONTROLS_CANVAS, touch);
    }

    for (const button of TOUCH_BUTTONS) {
        const wasDown = button.down;
        button.down = false;
        for (const touch of touches) {
            if (dist({'x': button.x(), 'y': button.y()}, touch) < button.radius * 1.15) {
                button.down = true;
                touch.onButton = true;
            }
        }
        if (button.down && !wasDown && button.tap) button.tap();
    }

    for (const touch of touches) {
        if (!touch.onButton) free.push(touch);
    }

    // Pinch to zoom: two free fingers, distance change drives the zoom factor.
    if (free.length >= 2) {
        const d = dist(free[0], free[1]);
        if (PINCH_DIST) setZoom(d / PINCH_DIST);
        PINCH_DIST = d;
    } else {
        PINCH_DIST = 0;
    }

    let movementTouch, lookTouch;
    for (const touch of free) {
        if (touch.identifier === TOUCH_JOYSTICK.touchIdentifier) movementTouch = touch;
        else if (touch.identifier === TOUCH_LOOK.touchIdentifier) lookTouch = touch;
    }
    for (const touch of free) {
        if (touch === movementTouch || touch === lookTouch) continue;
        if (!movementTouch && touch.x < TOUCH_CONTROLS_CANVAS.width / 2) movementTouch = touch;
        else if (!lookTouch) lookTouch = touch;
    }

    for (const [stick, touch] of [[TOUCH_JOYSTICK, movementTouch], [TOUCH_LOOK, lookTouch]]) {
        if (touch) {
            if (stick.touchIdentifier < 0) {
                stick.x = touch.x;
                stick.y = touch.y;
            }
            stick.touchIdentifier = touch.identifier;
            stick.touch.x = touch.x;
            stick.touch.y = touch.y;
        } else {
            stick.touchIdentifier = -1;
        }
    }
};


// While the options menu is open, taps on a line toggle that option.
tapOptions = (touch) => {
    getEventPosition(touch, TOUCH_CONTROLS_CANVAS, touch);
    const y = touch.y / TOUCH_CONTROLS_CANVAS.height * CANVAS_HEIGHT;
    const index = round((y - OPTIONS_FIRST_LINE_Y) / OPTIONS_LINE_HEIGHT) + 1;
    if (index >= 1 && index <= 9) {
        toggleOption(index);
    } else {
        OPTIONS_OPEN = GAME_PAUSED = 0;
    }
};

ontouchstart = (event) => {
    inputMode = INPUT_MODE_TOUCH;
    event.preventDefault();
    if (OPTIONS_OPEN) return;
    updateTouches(event.touches);
};

ontouchmove = (event) => {
    event.preventDefault();
    if (OPTIONS_OPEN) return;
    updateTouches(event.touches);
};

ontouchend = (event) => {
    event.preventDefault();

    if (OPTIONS_OPEN) {
        if (event.changedTouches[0]) tapOptions(event.changedTouches[0]);
        updateTouches([]);
        return;
    }

    updateTouches(event.touches);

    if (onclick) onclick();
};

renderTouchControls = () => {
    TOUCH_CONTROLS_CANVAS.style.display = inputMode == INPUT_MODE_TOUCH ? nomangle('block') : nomangle('none');
    DPR = Math.min(devicePixelRatio, 2);
    const dpr = DPR;
    if (TOUCH_CONTROLS_CANVAS.width != innerWidth * dpr) TOUCH_CONTROLS_CANVAS.width = innerWidth * dpr;
    if (TOUCH_CONTROLS_CANVAS.height != innerHeight * dpr) TOUCH_CONTROLS_CANVAS.height = innerHeight * dpr;
    TOUCH_CONTROLS_CTX.clearRect(0, 0, TOUCH_CONTROLS_CANVAS.width, TOUCH_CONTROLS_CANVAS.height);

    for (const button of TOUCH_BUTTONS.concat([TOUCH_JOYSTICK, TOUCH_LOOK])) {
        TOUCH_CONTROLS_CTX.wrap(() => button.render());
    }

    requestAnimationFrame(renderTouchControls);
}

TOUCH_CONTROLS_CANVAS = document.createElement(nomangle('canvas'));
TOUCH_CONTROLS_CTX = TOUCH_CONTROLS_CANVAS.getContext('2d');

TOUCH_BUTTONS = [
    TOUCH_ATTACK_BUTTON = new MobileButton(nomangle('ATK'), [
        [170, 80, 1.25],
        [95, 190, 1.3],
        [200, 70, 1.2],
    ]),
    TOUCH_SHIELD_BUTTON = new MobileButton(nomangle('DEF'), [
        [80, 80],
        [95, 90, 1.1],
        [95, 105],
    ]),
    TOUCH_DASH_BUTTON = new MobileButton(nomangle('ROLL'), [
        [125, 160],
        [190, 140],
        [140, 175],
    ]),
    TOUCH_WHIRL_BUTTON = new MobileButton(nomangle('SPIN'), [
        [225, 160],
        [275, 90],
        [70, 210],
    ]),
    TOUCH_SLAM_BUTTON = new MobileButton(nomangle('SLAM'), [
        [175, 235],
        [275, 190],
        [235, 175],
    ]),
    TOUCH_SPRINT_BUTTON = new MobileButton(nomangle('RUN'), [
        [70, 235],
        [360, 90],
        [60, 320],
    ]),
    TOUCH_GUN_BUTTON = new MobileButton(nomangle('GUN'), [
        [265, 245],
        [360, 190],
        [180, 275],
    ], () => {
        const player = firstItem(level.scene.category('player'));
        if (player) player.toggleWeapon();
    }),
    TOUCH_SHADOW_BUTTON = new MobileButton(nomangle('SHDW'), [
        [175, 320],
        [455, 90],
        [300, 245],
    ]),
    TOUCH_ZOOM_IN_BUTTON = new MobileButton(nomangle('Z+'), [
        [-60, 260, 0.7],
        [-60, 260, 0.7],
        [-60, 340, 0.7],
    ], () => setZoom(1.2)),
    TOUCH_ZOOM_OUT_BUTTON = new MobileButton(nomangle('Z-'), [
        [-140, 260, 0.7],
        [-140, 260, 0.7],
        [-140, 340, 0.7],
    ], () => setZoom(1 / 1.2)),
    TOUCH_MOVE1_BUTTON = new MobileButton(nomangle('PNCH'), [
        [-60, 180, 0.7],
        [-60, 180, 0.7],
        [-60, 260, 0.7],
    ], () => {
        const p = firstItem(level.scene.category('player'));
        if (p) p.testMove(1);
    }),
    TOUCH_MOVE2_BUTTON = new MobileButton(nomangle('WAVE'), [
        [-140, 180, 0.7],
        [-140, 180, 0.7],
        [-140, 260, 0.7],
    ], () => {
        const p = firstItem(level.scene.category('player'));
        if (p) p.testMove(2);
    }),
    TOUCH_MOVE3_BUTTON = new MobileButton(nomangle('LEG'), [
        [-220, 180, 0.7],
        [-220, 180, 0.7],
        [-220, 260, 0.7],
    ], () => {
        const p = firstItem(level.scene.category('player'));
        if (p) p.testMove(3);
    }),
    TOUCH_MOVE4_BUTTON = new MobileButton(nomangle('KICK'), [
        [-60, 100, 0.7],
        [-60, 100, 0.7],
        [-60, 180, 0.7],
    ], () => {
        const p = firstItem(level.scene.category('player'));
        if (p) p.testMove(4);
    }),
    TOUCH_MOVE5_BUTTON = new MobileButton(nomangle('SPNK'), [
        [-140, 100, 0.7],
        [-140, 100, 0.7],
        [-140, 180, 0.7],
    ], () => {
        const p = firstItem(level.scene.category('player'));
        if (p) p.testMove(5);
    }),
    TOUCH_MOVE6_BUTTON = new MobileButton(nomangle('UPPR'), [
        [-220, 100, 0.7],
        [-220, 100, 0.7],
        [-220, 180, 0.7],
    ], () => {
        const p = firstItem(level.scene.category('player'));
        if (p) p.testMove(6);
    }),
    TOUCH_OPT_BUTTON = new MobileButton(nomangle('OPT'), [
        [60, 340, 0.7],
        [60, 340, 0.7],
        [60, 420, 0.7],
    ], () => {
        OPTIONS_OPEN = !OPTIONS_OPEN;
        GAME_PAUSED = !!OPTIONS_OPEN;
    }),
    TOUCH_MENU_BUTTON = new MobileButton(nomangle('MENU'), [
        [150, 340, 0.7],
        [150, 340, 0.7],
        [150, 420, 0.7],
    ], () => backToMenu()),
    TOUCH_FS_BUTTON = new MobileButton(nomangle('FS'), [
        [-60, 340, 0.7],
        [-60, 340, 0.7],
        [-60, 420, 0.7],
    ], () => toggleFullscreen()),
];

TOUCH_JOYSTICK = new MobileJoystick();
TOUCH_LOOK = new MobileJoystick();


TOUCH_CONTROLS_CANVAS.style.cssText = nomangle('position:fixed;left:0;top:0;width:100%;height:100%;z-index:5;touch-action:none;pointer-events:none');
document.body.appendChild(TOUCH_CONTROLS_CANVAS);
renderTouchControls();
