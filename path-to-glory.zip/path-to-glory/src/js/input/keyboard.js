let DOWN = {};

toggleOption = (n) => {
    if (n == 1) OPT_WEATHER = !OPT_WEATHER;
    if (n == 2) OPT_BLOOD = !OPT_BLOOD;
    if (n == 3) OPT_SHAKE = !OPT_SHAKE;
    if (n == 4) OPT_SLOWMO = !OPT_SLOWMO;
    if (n == 5) OPT_VIBRATE = !OPT_VIBRATE;
    if (n == 6) {
        ENEMY_COUNT_INDEX = (ENEMY_COUNT_INDEX + 1) % ENEMY_COUNTS.length;
        ENEMY_COUNT = ENEMY_COUNTS[ENEMY_COUNT_INDEX];
    }
    if (n == 9) PEACEFUL = !PEACEFUL;
    if (n == 7) TOUCH_LAYOUT = (TOUCH_LAYOUT + 1) % 3;
    if (n == 8) toggleFullscreen();
};

onkeydown = e => {
    const key = e.keyCode;

    if (key == 27 || key == 80) GAME_PAUSED = !GAME_PAUSED;

    // Back to the character select menu
    if (key == 77) backToMenu();

    // Options menu
    if (key == 79) {
        OPTIONS_OPEN = !OPTIONS_OPEN;
        GAME_PAUSED = !!OPTIONS_OPEN;
    }

    if (OPTIONS_OPEN && key >= 49 && key <= 57) toggleOption(key - 48);

    if (!OPTIONS_OPEN) {
        // Zoom
        if (key == 187 || key == 107) setZoom(1.15);
        if (key == 189 || key == 109) setZoom(1 / 1.15);
        if (key == 48) ZOOM_USER = 1;

        // Rig test moves
        if (key >= 49 && key <= 54) {
            const player = firstItem(level.scene.category('player'));
            if (player) player.testMove(key - 48);
        }
    }

    DOWN[key] = true;
};

onwheel = e => {
    if (OPTIONS_OPEN) return;
    const dy = e.deltaY * (e.deltaMode == 1 ? 16 : e.deltaMode == 2 ? 100 : 1);
    setZoom(exp(-dy * 0.0015));
};

onkeyup = e => DOWN[e.keyCode] = false;

// Reset inputs when window loses focus
onblur = onfocus = () => {
    DOWN = {};
    MOUSE_RIGHT_DOWN = MOUSE_DOWN = false;
};
