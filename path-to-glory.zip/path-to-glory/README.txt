PATH TO GLORY - Gangster Arena
play/  -> open index.html on a local server (python3 -m http.server) then visit /play/
         ?hero=0 knight, 1 ninja, 2 swordsman 3D, 3 fighter 3D
         (heroes 2 and 3 need the 3D models from the Lovable app build)
src/   -> game source (js/, css/, index.html) + build-game.mjs
         rebuild: node build-game.mjs  (writes public/game/game.js)
